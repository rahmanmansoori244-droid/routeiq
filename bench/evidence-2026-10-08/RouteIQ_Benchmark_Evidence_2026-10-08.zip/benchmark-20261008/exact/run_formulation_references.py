"""Raw-invoice counterexamples, distinct from fixed-stop routing optimality.

The partition encodings below reproduce known web-builder choices; this harness
does not call the TypeScript builder. It independently proves better allowed
packing/allocation choices and executes the real solver on both encodings.
"""
import argparse
import itertools
import math
import os
from pathlib import Path
import time
import run_exact_suite as suite

BASE=Path(__file__).resolve().parent/'formulation'

def partitions(items):
    if not items:
        yield []
        return
    first,*rest=items
    for p in partitions(rest):
        yield [[first]]+[x[:] for x in p]
        for j in range(len(p)):
            q=[x[:] for x in p];q[j]=[first]+q[j];yield q

def case(name,parts,trucks,kg=False):
    c=suite.make_case('cases',0);r=c['request'];c['id']=name;c['family']='raw-formulation'
    r['run_id']=name;r['trucks']=trucks
    r['config'].update(time_limit_sec=1,shift_start_min=480,shift_max_min=600,
        latest_return_min=1080,reload_min=0,loading_min_per_case=0,window_rule='FINISH')
    r['depot'].update(open_min=480,close_min=1080)
    r['stops']=[dict(stop_id=f'C#{j}',customer_id='SAME_CUSTOMER',order_ids=[f'INVOICE_PART_{j}'],
        lat=r['depot']['lat'],lng=r['depot']['lng'],demand_cases=p[0],demand_kg=p[1],
        demand_pallet_units=None,service_min=10,priority=3,hard_start_min=480,
        hard_end_min=491 if kg else 1080) for j,p in enumerate(parts)]
    n=len(parts)+1;c['matrix']=dict(distance_m=[[0]*n for _ in range(n)],duration_s=[[0]*n for _ in range(n)],
        node_ids=['D']+[s['stop_id'] for s in r['stops']],provenance='co-located synthetic depot/customer; no travel cost')
    return c

def truck(tid,cap,kg=0,cost=0,hire=False):
    return dict(id=tid,code=tid,capacity_cases=cap,capacity_kg=kg,fixed_cost=cost,
        trip_cost=0,cost_per_km=0,max_trips=1,hire_candidate=hire,
        driver_day_cost=10 if hire else None)

def run(c):
    folder=BASE/c['id'];suite.write(folder/'request.json',c['request']);suite.write(folder/'matrix.json',c['matrix'])
    ref=suite.oracle(c);suite.write(folder/'oracle.json',ref)
    response,sec=suite.run_model(c);suite.write(folder/'response.json',response)
    out=suite.evaluate(c,response,ref);out['model_wall_sec']=sec;suite.write(folder/'result.json',out)
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path);p.add_argument('--cpu',type=int,default=4)
    a=p.parse_args();os.sched_setaffinity(0,{a.cpu})
    if a.repo:suite.SOURCE=a.repo.resolve()/'apps/solver'
    weights=[6,5,3,2,2,2];allp=list(partitions(list(range(6))))
    feasible=[p for p in allp if all(sum(weights[j] for j in b)<=10 for b in p)]
    best=min(feasible,key=len)
    # 203 is Bell(6): every partition, not heuristic bin packing.
    assert len(allp)==203 and len(best)==2
    packingproof=dict(original_invoice=dict(case_weights_kg=weights,cases=6),
        all_set_partitions_enumerated=len(allp),feasible_partitions=len(feasible),
        min_loads=len(best),lower_bound=math.ceil(sum(weights)/10),
        optimum_partition_indices=best,optimum_partition_weights=[sum(weights[j] for j in b) for b in best],
        known_FFD_weights=[9,9,2],status='PROVEN_OPTIMAL_BY_ALL_SET_PARTITIONS_AND_MATCHING_WEIGHT_BOUND')
    fleet=[truck('OWN',100),truck('SMALL',100,cost=20,hire=True),truck('BIG',200,cost=100,hire=True)]
    allocations=[]
    for own in range(101):
        for small in range(101):
            big=200-own-small
            if 0<=big<=200:
                allocations.append(dict(own_cases=own,small_cases=small,big_cases=big,
                    hire_cost_omr=30*bool(small)+110*bool(big)))
    winner=min(allocations,key=lambda x:x['hire_cost_omr'])
    assert winner['hire_cost_omr']==30
    hireproof=dict(original_invoice=dict(customer='SAME_CUSTOMER',cases=200),
        distinct_integer_allocations_evaluated=len(allocations),best=winner,
        lower_bound_omr=30,reason='Own truck holds only 100; any complete allocation needs a rental; cheapest rental including driver is 30, and own100+small100 attains it.',
        status='PROVEN_OPTIMAL_IF_TWO_VISITS_ALLOWED',
        policy_caveat='If the product intentionally requires a single visit whenever any truck can hold the whole order, 110 is optimal under that restriction; 30 is a different permitted-splitting policy.')
    packingfleet=[truck('T1',6,kg=10),truck('T2',6,kg=10)]
    cases=[case('packing-ffd',[(2,9),(3,9),(1,2)],packingfleet,True),
           case('packing-optimal',[(len(b),sum(weights[j] for j in b)) for b in best],packingfleet,True),
           case('rental-whole',[(200,0)],fleet),case('rental-split',[(100,0),(100,0)],fleet)]
    results=[run(c) for c in cases]
    suite.write(BASE/'summary.json',dict(packing_proof=packingproof,hire_proof=hireproof,results=results,
        limitation='Known splitter output encodings are supplied directly; TypeScript builder and database are not executed. Actual production Python optimize_dispatch is executed on every encoding. These are structural counterexamples, not prevalence estimates.'))
    suite.write(BASE/'manifest.json',dict(cases=[dict(case_id=c['id'],request=str(BASE/c['id']/'request.json'),matrix=str(BASE/c['id']/'matrix.json'),response=str(BASE/c['id']/'response.json'),
        request_relative=f"{c['id']}/request.json",matrix_relative=f"{c['id']}/matrix.json",response_relative=f"{c['id']}/response.json") for c in cases]))
    print({'packing_min_loads':len(best),'best_rental_omr':winner['hire_cost_omr'],'results':results})

if __name__=='__main__':main()
