"""Independent exhaustive reference for tiny RouteIQ dispatch instances.

Only distance-provider injection and CPU-worker count are adapted. optimize_dispatch,
route search, load repair, rental reduction and its internal validation all execute.
The oracle does NOT import RouteIQ helpers. It enumerates every capacity-feasible
ordered load, every ordered truck day (up to two loads), then every disjoint fleet
assignment. No time limits or heuristic pruning are used in the oracle.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import random
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = Path(os.environ.get('ROUTEIQ_SOURCE', str(ROOT / 'routeiq-20261008'))) / 'apps/solver'
SHA = '5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b'

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def make_case(family, k):
    seed = 802610 + 100 * k + ['cases', 'pallets', 'weights', 'windows', 'priority', 'multitrip', 'rentals'].index(family)
    rng = random.Random(seed)
    n = 6 if family != 'cases' else (6 if k < 2 else 7)
    pts = [(0, 0)]
    while len(pts) < n + 1:
        p = (rng.randint(-12, 12), rng.randint(-12, 12))
        if p not in pts:
            pts.append(p)
    # ceil Euclidean kilometres, one minute per kilometre. Synthetic, NOT Oman road data.
    dm = [[0 if i == j else math.ceil(math.dist(a, b)) * 1000 for j, b in enumerate(pts)] for i, a in enumerate(pts)]
    ts = [[d // 1000 * 60 for d in row] for row in dm]
    stops = []
    for j in range(n):
        stops.append(dict(stop_id=f'S{j+1}', customer_id=f'C{j+1}', order_ids=[f'INV{j+1}'],
            lat=23.50 + pts[j+1][0] * .001, lng=58.30 + pts[j+1][1] * .001,
            demand_cases=rng.randint(10, 25), demand_kg=0, demand_pallet_units=None,
            service_min=rng.choice([5, 8, 10]), priority=3, hard_start_min=420,
            hard_end_min=840))
    def truck(tid, cap, fixed, **kw):
        return dict(id=tid, code=tid, capacity_cases=cap, capacity_kg=0,
                    fixed_cost=fixed, trip_cost=2, cost_per_km=.25,
                    max_trips=1, **kw)
    trucks = [truck('OWN1', 65, 12), truck('OWN2', 65, 15)]
    cfg = dict(shift_start_min=420, shift_max_min=420, latest_return_min=840,
        overtime_after_min=None, overtime_cost_per_hour=0, reload_min=15,
        loading_min_per_case=0, window_rule='FINISH', break_min=0,
        max_trips_per_truck=2, driver_cost_per_hour=0, fuel_price_per_litre=0,
        strict_priorities=True, pref_window_penalty_per_min=0,
        early_preference_per_min={str(p): 0 for p in range(1,6)}, use_margin=False,
        change_penalty_per_stop=0, distance_provider='HAVERSINE', road_time_factor=1,
        time_limit_sec=2, scenarios=['RECOMMENDED'], pallet_fill_pct=100)
    if family == 'pallets':
        trucks = [truck('OWN1', 1, 12, bays=2), truck('OWN2', 1, 15, bays=2)]
        cfg['pallet_fill_pct'] = [100, 95, 90, 100][k]
        for s in stops:
            s['demand_pallet_units'] = rng.choice([350, 450, 550, 700, 900, 1050])
    if family == 'weights':
        for t in trucks:
            t['capacity_cases'] = 1000
            t['capacity_kg'] = [60, 70, 65, 55][k]
        for s in stops:
            s['demand_kg'] = rng.choice([12.1, 18.4, 21.5, 25.0, 29.3])
    if family == 'windows':
        for j, s in enumerate(stops):
            s['hard_start_min'] = 420 + rng.choice([0, 30, 60, 120])
            s['hard_end_min'] = s['hard_start_min'] + rng.choice([25, 40, 60])
            s['priority'] = rng.choice([1, 2, 3, 4, 5])
        cfg['window_rule'] = 'FINISH' if k != 3 else 'START'
    if family == 'priority':
        for t in trucks:
            t['capacity_cases'] = [25, 30, 35, 40][k]
        for j, s in enumerate(stops):
            s['priority'] = [1, 2, 3, 4, 5, rng.randint(1,5)][j]
    if family == 'multitrip':
        for t in trucks:
            t['max_trips'] = 2
            t['capacity_cases'] = 40
        cfg['loading_min_per_case'] = .25
        cfg['latest_return_min'] = 600 + 20*k
        for s in stops:
            s['demand_cases'] = rng.choice([12, 16, 20, 24])
            s['hard_end_min'] = 580 + 20*k
            s['hard_start_min'] = rng.choice([420, 440, 480])
    if family == 'rentals':
        trucks = [truck('OWN1', [35, 40, 45, 50][k], 0),
            truck('HIRE_SMALL', 40, 20, hire_candidate=True, driver_day_cost=10),
            truck('HIRE_LARGE', 70, [35, 40, 30, 45][k], hire_candidate=True, driver_day_cost=10)]
        for t in trucks[1:]:
            t['cost_per_km'] = 0
            t['trip_cost'] = 0
    name = f'{family}-{k+1:02d}'
    return dict(id=name, family=family, seed=seed,
        request=dict(run_id=name, tenant_id='synthetic-benchmark',
            depot=dict(id='D',lat=23.50,lng=58.30,open_min=420,close_min=840),
            trucks=trucks,stops=stops,config=cfg),
        matrix=dict(distance_m=dm,duration_s=ts, node_ids=['D']+[s['stop_id'] for s in stops],
                    provenance='fixed synthetic metric; ceil Euclidean kilometres; 60 km/h'),
        points=pts)

def money_milli(x):
    return int(round(x * 1000))

def oracle(case):
    began=time.perf_counter()
    req=case['request']; cfg=req['config']; stops=req['stops']; n=len(stops)
    D=case['matrix']['distance_m']; T=case['matrix']['duration_s']
    allmask=(1<<n)-1
    # Assertion establishes the simplified exact-model scope (nothing silently ignored).
    assert cfg['break_min']==0 and cfg['driver_cost_per_hour']==0
    assert cfg['overtime_cost_per_hour']==0 and not cfg['use_margin']
    assert cfg['pref_window_penalty_per_min']==0 and not any(cfg['early_preference_per_min'].values())
    assert all(not s.get('previous_truck_id') and not s.get('margin') for s in stops)
    start=cfg['shift_start_min']*60
    end=min(cfg['latest_return_min'], req['depot']['close_min'])*60
    bytruck=[]; certificates=[]
    for truck in req['trucks']:
        assert not truck.get('frozen_trips') and not truck.get('km_per_litre')
        maxtrips=truck.get('max_trips',cfg['max_trips_per_truck'])
        routes=[]
        for size in range(1,n+1):
            for subset in itertools.combinations(range(n),size):
                cases=sum(stops[j]['demand_cases'] for j in subset)
                if truck.get('bays'):
                    if sum(stops[j]['demand_pallet_units'] for j in subset)>truck['bays']*cfg['pallet_fill_pct']*10:
                        continue
                elif cases>truck['capacity_cases']:
                    continue
                kg=sum(int(math.floor(stops[j]['demand_kg']*10+.5)) for j in subset)
                if truck['capacity_kg']>0 and kg>math.floor(truck['capacity_kg']*10+1e-6):
                    continue
                mask=sum(1<<j for j in subset)
                for order in itertools.permutations(subset):
                    nodes=(0,)+tuple(j+1 for j in order)+(0,)
                    metres=sum(D[a][b] for a,b in zip(nodes,nodes[1:]))
                    routes.append((mask,order,metres,cases))
        feasible_days=0
        best={0:dict(mask=0,hire_milli=0,cost_milli=0,distance_m=0,loads=[])}
        def visit(mask,ready,metres,loads):
            nonlocal feasible_days
            if loads:
                feasible_days+=1
                # Business policy: a rental must carry at least one P1-P3 delivery.
                acceptable=not truck.get('hire_candidate') or any(mask&(1<<j) and s['priority']<=3 for j,s in enumerate(stops))
                if acceptable:
                    money=(money_milli(truck['fixed_cost'])+money_milli(truck.get('driver_day_cost') or 0)
                        +len(loads)*money_milli(truck['trip_cost'])
                        +round(metres*truck['cost_per_km']))
                    hire=(money_milli(truck['fixed_cost'])+money_milli(truck.get('driver_day_cost') or 0)
                          +round(metres*truck['cost_per_km'])) if truck.get('hire_candidate') else 0
                    row=dict(mask=mask,hire_milli=hire,cost_milli=money,distance_m=metres,loads=list(loads))
                    old=best.get(mask)
                    if old is None or (hire,money,metres)<(old['hire_milli'],old['cost_milli'],old['distance_m']):
                        best[mask]=row
            if len(loads)>=maxtrips:
                return
            for rm,order,rd,rc in routes:
                if mask&rm:
                    continue
                depart=ready
                if loads:
                    depart+=cfg['reload_min']*60 + int(round(cfg['loading_min_per_case']*rc*60))
                depart=max(depart,(truck.get('available_from_min') or cfg['shift_start_min'])*60)
                current=depart;prev=0;starts=[]
                for j in order:
                    s=stops[j]
                    current=max(current+T[prev][j+1],s['hard_start_min']*60)
                    closing=current+(s['service_min']*60 if cfg['window_rule']=='FINISH' else 0)
                    if closing>s['hard_end_min']*60:
                        break
                    starts.append(current); current+=s['service_min']*60;prev=j+1
                else:
                    ret=current+T[prev][0]
                    if ret<=end and ret<=(truck.get('available_to_min') or 1440)*60 and ret-start<=cfg['shift_max_min']*60:
                        load=dict(stop_ids=[stops[j]['stop_id'] for j in order],depart_s=depart,
                                  service_start_s=starts,return_s=ret,distance_m=rd,cases=rc)
                        visit(mask|rm,ret,metres+rd,loads+[load])
        visit(0,start,0,[])
        bytruck.append(best)
        certificates.append(dict(truck_id=truck['id'],capacity_feasible_ordered_loads=len(routes),
            feasible_ordered_days=feasible_days,best_day_for_each_subset=list(best.values())))
    # Complete subset dynamic program over every truck, with disjoint service.
    frontier={0:dict(mask=0,hire_milli=0,cost_milli=0,distance_m=0,truck_days=[])}
    transitions=0
    for truck,best in zip(req['trucks'],bytruck):
        nextfront={}
        for m,a in frontier.items():
            for rm,b in best.items():
                if m&rm: continue
                transitions+=1
                z=dict(mask=m|rm,hire_milli=a['hire_milli']+b['hire_milli'],
                    cost_milli=a['cost_milli']+b['cost_milli'],distance_m=a['distance_m']+b['distance_m'],
                    truck_days=a['truck_days']+([dict(truck_id=truck['id'],**b)] if rm else []))
                old=nextfront.get(z['mask'])
                if old is None or (z['hire_milli'],z['cost_milli'],z['distance_m'])<(old['hire_milli'],old['cost_milli'],old['distance_m']):
                    nextfront[z['mask']]=z
        frontier=nextfront
    def rank(row):
        counts=[sum(bool(row['mask']&(1<<j)) for j,s in enumerate(stops) if s['priority']==p) for p in range(1,6)]
        return tuple(-q for q in counts[:3])+(row['hire_milli'],)+tuple(-q for q in counts[3:])+(row['cost_milli'],)
    answer=min(frontier.values(),key=lambda z:rank(z)+(z['distance_m'],))
    return dict(status='OPTIMAL_BY_EXHAUSTIVE_ENUMERATION',objective_bound_equal_to_solution=True,
        answer=answer,rank=rank(answer),truck_certificates=certificates,
        fleet_subset_frontier=[dict(mask=m,rank=rank(z),hire_milli=z['hire_milli'],cost_milli=z['cost_milli']) for m,z in frontier.items()],
        fleet_transitions=transitions,elapsed_sec=time.perf_counter()-began,
        completeness='All ordered capacity-feasible loads, ordered disjoint truck days up to max_trips, and all disjoint fleet subset combinations. Earliest scheduling is sufficient because no departure-dependent costs, preferences, breaks, frozen work, or restrictive moving shift limit are present.')

def evaluate(case,response,reference):
    req=case['request'];cfg=req['config'];stops=req['stops'];D=case['matrix']['distance_m'];T=case['matrix']['duration_s']
    byid={s['stop_id']:(j,s) for j,s in enumerate(stops)}
    truckmap={t['id']:t for t in req['trucks']};sc=response['scenarios'][0]
    seen=[];errors=[];cost=0;hire=0;distance=0
    for t in req['trucks']:
        loads=sorted([l for l in sc['loads'] if l['truck_id']==t['id']],key=lambda l:l['depart_min'])
        if len(loads)>t['max_trips']:errors.append('TRIP_LIMIT '+t['id'])
        tdmetres=0
        previous=None
        for load in loads:
            ss=[byid[z['stop_id']] for z in load['stops']]
            cases=sum(s['demand_cases'] for _,s in ss)
            if load['cases']!=cases:errors.append('LOAD_CASES '+t['id'])
            if t.get('bays'):
                if sum(s['demand_pallet_units'] for _,s in ss)>t['bays']*cfg['pallet_fill_pct']*10:errors.append('PALLET_CAP '+t['id'])
            elif cases>t['capacity_cases']:errors.append('CASE_CAP '+t['id'])
            if t['capacity_kg']>0 and sum(round(s['demand_kg']*10) for _,s in ss)>round(t['capacity_kg']*10):errors.append('KG_CAP '+t['id'])
            depart=load['depart_min']*60
            if depart<cfg['shift_start_min']*60:errors.append('START '+t['id'])
            if previous is not None and depart<previous+cfg['reload_min']*60+cfg['loading_min_per_case']*cases*60:errors.append('RELOAD '+t['id'])
            current=depart;prev=0;metres=0
            for out,(j,s) in zip(load['stops'],ss):
                seen.append(s['stop_id']);metres+=D[prev][j+1]
                st=out['service_start_min']*60
                if st+1e-6<max(current+T[prev][j+1],s['hard_start_min']*60):errors.append('TRAVEL_OR_OPEN '+s['stop_id'])
                if st+(s['service_min']*60 if cfg['window_rule']=='FINISH' else 0)>s['hard_end_min']*60:errors.append('CLOSING '+s['stop_id'])
                if out['departure_min']*60<st+s['service_min']*60:errors.append('SERVICE '+s['stop_id'])
                current=out['departure_min']*60;prev=j+1
            metres+=D[prev][0]
            ret=load['return_min']*60
            if ret<current+T[prev][0]:errors.append('RETURN_TRAVEL '+t['id'])
            if ret>min(cfg['latest_return_min'],req['depot']['close_min'])*60:errors.append('RETURN_CLOSE '+t['id'])
            if ret-loads[0]['depart_min']*60>cfg['shift_max_min']*60:errors.append('SHIFT '+t['id'])
            if abs(load['distance_km']-metres/1000)>0.011:errors.append('DISTANCE '+t['id'])
            tdmetres+=metres;previous=ret
        if loads:
            cost+=money_milli(t['fixed_cost'])+money_milli(t.get('driver_day_cost') or 0)+len(loads)*money_milli(t['trip_cost'])+round(tdmetres*t['cost_per_km'])
            if t.get('hire_candidate'):
                hire+=money_milli(t['fixed_cost'])+money_milli(t.get('driver_day_cost') or 0)+round(tdmetres*t['cost_per_km'])
        distance+=tdmetres
    unserved=[s['stop_id'] for s in sc['unserved']]
    if sorted(seen+unserved)!=sorted(byid):errors.append('RECONCILIATION')
    if abs(sc['operating_cost']-cost/1000)>.011:errors.append('COST')
    counts=[sum(byid[s][1]['priority']==p for s in seen) for p in range(1,6)]
    rank=tuple(-q for q in counts[:3])+(hire,)+tuple(-q for q in counts[3:])+(cost,)
    opt=tuple(reference['rank']);samepolicy=rank[:-1]==opt[:-1]
    return dict(case_id=case['id'],family=case['family'],n_stops=len(stops),n_trucks=len(req['trucks']),
        independently_valid=not errors,independent_errors=errors,
        routeiq_internal_feasibility=sc.get('feasibility'),service_counts_by_priority=counts,
        routeiq_rank=rank,optimal_rank=opt,objective_matches_optimum=rank==opt,
        objective_better_than_oracle=rank<opt,same_service_and_hire_tier=samepolicy,
        cost_omr=cost/1000,optimal_cost_omr=reference['answer']['cost_milli']/1000,
        hire_omr=hire/1000,optimal_hire_omr=reference['answer']['hire_milli']/1000,
        cost_gap_pct=(cost/reference['answer']['cost_milli']-1)*100 if samepolicy and reference['answer']['cost_milli'] else None,
        distance_km=distance/1000,optimal_plan_distance_km=reference['answer']['distance_m']/1000,
        served_stop_ids=seen,unserved_stop_ids=unserved,
        oracle_elapsed_sec=reference['elapsed_sec'])

def run_model(case):
    # Resource controls only; no scoring, feasibility, search, or solution stubbing.
    os.environ['SOLVER_PARALLEL']='0'
    os.environ['SOLVER_PYVRP']='off'
    os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
    os.environ['MKL_NUM_THREADS']='1'
    sys.path.insert(0,str(SOURCE))
    from dispatch_models import DispatchRequest
    from providers import MatrixResult
    import dispatch_solver as ds
    import load_repack as lr
    original_matrix=ds.resolve_matrix; original_repack=lr.repack
    nodes=[case['request']['depot']]+case['request']['stops']
    nodeidx={(n['lat'],n['lng']):j for j,n in enumerate(nodes)}
    def fixed_matrix(coords,**kwargs):
        ids=[nodeidx[tuple(c)] for c in coords]
        return MatrixResult([[case['matrix']['distance_m'][i][j] for j in ids] for i in ids],
            [[case['matrix']['duration_s'][i][j] for j in ids] for i in ids],
            provider_name='FIXED_SYNTHETIC_BENCHMARK',is_estimated=True,all_estimated=True,quality='ESTIMATED')
    def single_worker(*args,**kwargs):
        if len(args)>7:args=args[:7]+(1,)+args[8:]
        else:kwargs['workers']=1
        return original_repack(*args,**kwargs)
    ds.resolve_matrix=fixed_matrix;lr.repack=single_worker
    try:
        start=time.perf_counter()
        response=ds.optimize_dispatch(DispatchRequest.model_validate(case['request']))
        return response.model_dump(mode='json'),time.perf_counter()-start
    finally:
        ds.resolve_matrix=original_matrix;lr.repack=original_repack

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--only');parser.add_argument('--generate-only',action='store_true')
    parser.add_argument('--time',type=int,default=2);parser.add_argument('--cpu',type=int,default=4)
    parser.add_argument('--repo',type=Path,help='RouteIQ repository root; or set ROUTEIQ_SOURCE')
    args=parser.parse_args()
    global SOURCE
    if args.repo: SOURCE=args.repo.resolve()/'apps/solver'
    os.sched_setaffinity(0,{args.cpu})
    families=['cases','pallets','weights','windows','priority','multitrip','rentals']
    cases=[make_case(f,k) for f in families for k in range(4)]
    if args.only:cases=[c for c in cases if args.only in c['id']]
    manifest=[];results=[]
    for case in cases:
        case['request']['config']['time_limit_sec']=args.time
        folder=BASE/case['id'];folder.mkdir(exist_ok=True)
        write(folder/'request.json',case['request']);write(folder/'matrix.json',case['matrix']);write(folder/'input.json',case)
        manifest.append(dict(case_id=case['id'],family=case['family'],request=str(folder/'request.json'),
            matrix=str(folder/'matrix.json'),response=str(folder/'response.json'),oracle=str(folder/'oracle.json'),
            request_relative=f"{case['id']}/request.json",matrix_relative=f"{case['id']}/matrix.json",
            response_relative=f"{case['id']}/response.json",oracle_relative=f"{case['id']}/oracle.json"))
    write(BASE/'manifest.json',dict(source_sha=SHA,cpu_affinity=[args.cpu],model_search_sec=args.time,
        pyvrp='off',parallel='0',repack_workers=1,cases=manifest))
    if args.generate_only:return
    for case in cases:
        folder=BASE/case['id']
        reference=oracle(case);write(folder/'oracle.json',reference)
        response,wall=run_model(case);write(folder/'response.json',response)
        result=evaluate(case,response,reference);result['model_wall_sec']=wall
        write(folder/'result.json',result);results.append(result)
        write(BASE/'summary.json',dict(source_sha=SHA,completed=len(results),results=results,
            valid=sum(r['independently_valid'] for r in results),matches=sum(r['objective_matches_optimum'] for r in results)))
        print(json.dumps({k:result[k] for k in ['case_id','independently_valid','objective_matches_optimum','cost_omr','optimal_cost_omr','cost_gap_pct','routeiq_rank','optimal_rank','model_wall_sec']}),flush=True)

if __name__=='__main__':main()
