# Certified small-instance benchmark

Source: RouteIQ `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b`.
Executed 8 October 2026 (Dubai date), in an isolated local review workspace.

## Result

**28/28 actual solver outputs were independently feasible and matched a proven optimal objective for their explicitly restricted fixed-stop models.** No priority/service shortfall, rental-cost gap, or operating-cost gap was found against the exhaustive reference. These comprise 170 input stops across 28 separate problems, not one 170-stop problem.

| Family | Instances | Destinations each | Result |
|---|---:|---:|---|
| Case capacities | 4 | 6–7 | 4 optimal |
| Pallet bays, including 90%/95% fill | 4 | 6 | 4 optimal |
| Weight capacity at 0.1 kg precision | 4 | 6 | 4 optimal |
| Receiving windows (3 FINISH, 1 START) | 4 | 6 | 4 optimal |
| Strict priorities under fleet shortage | 4 | 6 | 4 optimal |
| Two trips with reload and per-case loading | 4 | 6 | 4 optimal |
| Flat rental selection | 4 | 6 | 4 optimal |

Several optimum answers intentionally leave deliveries unserved because fleet capacity is insufficient. Matching an optimum is evaluated by priority/service, then rental tier, then cost, not by assuming all stops must be served.

The total actual solver wall time was 56.408 seconds; exhaustive references took 0.104 seconds. The search allowance was 2 seconds per primary search; a rental reduction may make another search. These tiny cases do not measure large-day performance. The oracle enumerated 9,938 capacity-feasible ordered loads, 14,404 feasible ordered truck days and 18,631 fleet subset transitions across the suite.

A second independently implemented validator, developed separately from this oracle and without product checker imports, also passed all 28 outputs.

## What is independently proven

`run_exact_suite.py` does not call solver logic to decide the reference answer. It enumerates every ordered subset that fits each truck, every ordered sequence of up to two disjoint loads that fits the truck's day, and every disjoint assignment of service subsets to the fleet. The saved oracle files contain the best witness for every feasible truck subset and the full fleet subset frontier.

Earliest possible timing is sufficient for these cases: there are no departure-dependent costs, hourly driver costs, preferred windows, mandatory breaks, frozen work or tighter moving shift limits. Every time and loading duration is an integer number of seconds; the synthetic travel times are whole minutes. Therefore delaying a route cannot improve feasibility or money here. Fixed and per-trip money plus distance money are evaluated independently. Rental cases have only P3 stops and flat rental rates, making rental-tier comparison unambiguous.

The complete objective is lexicographic: maximize counts of P1, then P2, then P3 deliveries; minimize the actual rental/day-driver bill; maximize P4 then P5 counts; minimize operating cost. Early-arrival preferences, margin and continuity are explicitly disabled in the request. A tie in that objective counts as optimal even when another equally priced plan has different distances or visit order.

This proves these **fixed input problems**, not the entire RouteIQ application, invoice splitting, arbitrary business rules, all random instances, global large-day optimality or live-road performance.

## Actual execution and controls

- Production `optimize_dispatch` runs, including route search, repack, rental reduction and the product's internal feasibility checker.
- PyVRP is disabled for this primary-engine reference benchmark. The hybrid benchmark is a separate experiment.
- CPU affinity: one CPU (4). `SOLVER_PARALLEL=0` selects the development in-process path. The repack worker count is constrained to one at runtime. No source file is changed.
- The only functional injection is a deterministic distance/time provider. It supplies the saved synthetic matrix instead of making a road-network request; routes and answers are not mocked.
- Distances are the ceiling of Euclidean distances between seeded integer grid points, in kilometres. Travel assumes 60 km/h. These are mathematical benchmark instances, not actual Oman road distances.
- No database, production service, real customer records, secrets, deployments or repository writes are involved.
- The generator fixes seeds before solving and retains every generated result; no failed case is filtered out.

See `environment.json` for runtime versions and SHA-256 hashes of core source files.

## Separate raw-invoice formulation examples

`formulation/` contains four more actual solver calls, kept out of the 28-case success count.

1. Six one-case items weighing 6, 5, 3, 2, 2, 2 kg: enumerating all 203 set partitions proves two 10 kg loads suffice. The previously observed FFD output (9, 9, 2 kg in three portions) lets two one-trip trucks deliver 5/6 cases in the tight FINISH window. The two-load encoding delivers 6/6.
2. One 200-case invoice: own capacity 100, small rental capacity 100 at 30 OMR including driver, large rental capacity 200 at 110 OMR including driver. The whole-stop encoding costs 110; the two-visit encoding costs 30. Enumeration of 10,201 allowed integer allocations and a matching 30 OMR lower bound proves that alternative cheapest **if splitting into two visits is permitted**. If a single visit is a hard business rule whenever a truck can take the whole invoice, the 110 OMR answer is optimal under that different rule.

Each solver answer is optimal for the restricted stops it receives. The difference comes from upstream formulation or business policy. The TypeScript request builder is not called in this harness: the known encodings from the prior source review are supplied explicitly. These are structural counterexamples, not measured real-world frequency.

## Reproduce

Install the pinned RouteIQ solver requirements in a local environment. On Linux, choose a CPU permitted by the current environment:

```bash
python run_exact_suite.py --repo /absolute/path/to/routeiq --cpu 4
python run_formulation_references.py --repo /absolute/path/to/routeiq --cpu 4
```

Alternatively set `ROUTEIQ_SOURCE` to the repository root. `--only windows-01` selects one instance; `--time 5` changes the search allowance. Re-execution overwrites result files next to the scripts. Model and oracle code are separate functions in the runner to keep the logic directly inspectable. Request, matrix, response, oracle witness and result JSON are retained in every instance folder. Manifests include paths relative to their location for portability.
