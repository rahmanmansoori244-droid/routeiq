"""Run actual exact-timing/repacking on saved diagnostic PyVRP candidate, no repeated route search."""
import os
os.sched_setaffinity(0,{int(os.environ.get('BENCH_CPU','7'))});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import sys,json,time
from pathlib import Path
from dataclasses import asdict
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1];ROOT=BASE.parent
SOURCE=Path(os.environ.get('ROUTEIQ_SOURCE',str(ROOT/'routeiq-20261008')))
sys.path.insert(0,str(SOURCE/'apps/solver'))
import dispatch_solver as ds
import pyvrp_candidate as pv
import load_repack as lr
from dispatch_models import DispatchRequest
from providers import MatrixResult
req=DispatchRequest.model_validate_json((HERE/'request.json').read_text());mat=json.loads((HERE/'matrix.json').read_text());raw=json.loads((HERE/'raised-candidate.json').read_text())
tds=ds._truck_days(req);stops,drops,notes=ds._prefilter(req,tds);mx=MatrixResult(mat['distance_m'],mat['duration_s'],'HAVERSINE_DIAGNOSTIC_SAME_SAVED_MATRIX',True)
plan,error=pv.plan_of(raw,tds,stops);assert plan is not None and error is None
ctx=ds._stage_ctx(req,stops,tds,mx,drops);carried={k for loads in plan.values() for load in loads for k in load}
job=dict(day=ctx.day,score_pricing=ctx.rec_pricing,plan=plan,gaps={td.idx:ds._approx_gap_s(req.config,td) for td in ctx.day.trucks},
  goals=[('RECOMMENDED',ctx.rec_pricing)],optional=ds._repair_weights(stops,set(range(len(stops)))-carried,req.config,req.trucks,req.depot) or None,
  cap_s=10,budget_s=20,fit_weights=ds._repair_weights(stops,set(range(len(stops))),req.config,req.trucks,req.depot))
original=lr.repack
def one_worker(*a,**kw):
 if len(a)>7:a=a[:7]+(1,)+a[8:]
 else:kw['workers']=1
 return original(*a,**kw)
lr.repack=one_worker
start=time.perf_counter();candidates,notes=pv.stage_in_worker(job);elapsed=time.perf_counter()-start
summary=dict(stage_wall_sec=elapsed,cap_s=10,budget_s=20,resource_override=f'CP-SAT repack workers=1 on CPUs{sorted(os.sched_getaffinity(0))}',candidate_count=len(candidates),notes=notes)
(HERE/'stage-candidates.json').write_text(json.dumps([asdict(c) for c in candidates],indent=2)+'\n')
if candidates:
 best=min(candidates,key=lambda c:ds._GOALS['RECOMMENDED'](c.score))
 sc=ds._build_scenario('RECOMMENDED',req,stops,tds,mx,best.plan,ctx.values,ctx.use_margin,drops,
   solver_status='DIAGNOSTIC_RAISED_PENALTY',elapsed=20+elapsed,time_limit=20,objective_value=best.score.objective,exact_timing=True)
 response=dict(run_id=req.run_id,engine='DIAGNOSTIC: in-memory penalty config change, saved candidate + actual poststage',scenarios=[sc.model_dump(mode='json')],warnings=['Diagnostic output, not stock-product benchmark.'])
 (HERE/'response.json').write_text(json.dumps(response,indent=2)+'\n')
 summary.update(feasibility=sc.feasibility.model_dump(),served=len(stops)-len(sc.unserved),service_vector=[sum(stops[k].priority==p for loads in best.plan.values() for load in loads for k in load.stops) for p in range(1,6)],
    operating_cost=sc.operating_cost,km=sc.total_distance_km,loads=sc.trips,trucks=sc.trucks_used,source=best.source)
(HERE/'stage-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
