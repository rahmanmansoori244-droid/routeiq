# D3 penalty-configuration diagnostic

This is an isolated diagnostic, **not a stock-product result, production fix, or official benchmark ranking**. Product source at `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b` was not edited.

Both trials used the same saved D3 request/matrix, 200 customers / 340 synthetic invoices, seed 17, PyVRP 0.14.0, a 20-second route-search budget and CPU 7. They executed PyVRP with the product's actual problem construction and stopping criterion. The sole model configuration change was applying the existing non-rental shortage-case raised-penalty policy to this time-constrained case even though it has no aggregate capacity shortage. That change also increases PyVRP's initial midpoint penalties; this is not a ceiling-only causal isolation.

| Trial | Max penalty | Route-search result | Search wall |
|---|---:|---|---:|
| Stock | 100,000 | No feasible PyVRP candidate; best raw solution has 5,548 seconds of time warp | 20.015 s |
| Diagnostic raised configuration | 980,515,516,160 | Feasible candidate, 177 served, 23 unserved, zero time warp / overload | 20.002 s |

The integer overflow calculation is recorded in `metadata.json`:

- Base bound: 4,500,503,056,018,736.
- Per-unit-penalty bound: 4,698,738.
- Highest client prize: 409,135,500,000,000.
- Safe ceiling: floor((2^62 - base) / per_unit) = 980,515,516,160.
- Resulting worst-cost bound: 4,611,686,018,426,624,816, strictly below 2^62 = 4,611,686,018,427,387,904.

The feasible diagnostic candidate then passed the actual RouteIQ exact-timing and repacking stage, with a 20-second total stage allowance, a 10-second per-repack limit, and one CP-SAT worker. That stage used 10.387 seconds and found:

- 184 of 200 stops served; P1–P5 counts `[10, 22, 58, 65, 29]`.
- 12 trucks, 19 loads, 732.67 km, operating cost 644.434 OMR.
- Product feasibility `VERIFIED`, timing `EXACT`.
- Separately implemented checker PASS, including 2,649 scenario checks and supplied invoice accounting.

The four controlled stock D3 runs with a reduced 60-second primary limit returned violated routes; this diagnostic shows one concrete way a feasible alternative candidate becomes available. A later stock native-budget replay (150-second primary / 540-second overall cap) recovered all 200 stops / 340 invoices / 8,393 cases in 155.872 seconds through the main engine and exact repair, independently PASS. PyVRP still supplied no feasible candidate. D3 is therefore a reduced-budget robustness and candidate-search limitation, not a reproduced default-budget failure. The diagnostic does not establish that altering this parameter is a complete or regression-safe fix, nor that its 184-stop answer is best: the independent greedy witness serves 185 stops, including one more P4 customer.

A second modeling limitation remains: PyVRP's candidate model treats priced preferred windows as hard bounds when their intersection is nonempty. For D3's first 70 customers, 18 minutes each requires 1,260 minutes of service inside the preferred 09:00–10:30 window, while 12 trucks supply at most 1,080 minutes. Serving all those customers in that restricted candidate model is therefore impossible even before travel. They are optional clients, so a feasible partial candidate can still exist. The true hard receiving window is wider. Increasing penalties does not remove that restriction.

`run_diagnostic.py` reproduces the paired route-search trials. `run_stage.py` reuses the saved raised candidate, invokes actual timing/repacking, and saves the final diagnostic response. The independent check command uses `validation/validate.py` with the saved request, response, matrix and D3 invoice fixture. Stock infeasible output retains raw routes for diagnosis, but those are **not valid served deliveries**.


## Reproduction paths

Use the pinned repository checkout and installed Python environment from the top-level README. `ROUTEIQ_SOURCE` is the repository root (not apps/solver). `BENCH_CPU` must be a CPU ID allowed by the local Linux process. For example, from a copied evidence bundle so saved results are preserved:

```bash
export ROUTEIQ_SOURCE=/absolute/path/to/routeiq
export BENCH_CPU=0
python diagnostics/d3-penalty/run_diagnostic.py
python diagnostics/d3-penalty/run_stage.py
python validation/validate.py diagnostics/d3-penalty/request.json diagnostics/d3-penalty/response.json --matrix diagnostics/d3-penalty/matrix.json --raw-invoices large/D3_tight_receiving/invoices.json --output diagnostics/d3-penalty/independent-check.json
```

The recorded run used CPU7. Path/affinity environment overrides were added after execution for portability; they do not change model construction, search settings, saved results or diagnostic conclusions. These scripts overwrite their own outputs when rerun.
