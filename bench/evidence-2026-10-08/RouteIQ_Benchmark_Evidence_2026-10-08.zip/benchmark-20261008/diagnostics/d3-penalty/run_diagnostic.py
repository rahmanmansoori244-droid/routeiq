"""Isolated diagnostic, not stock-product benchmark. Changes only an in-memory model's penalty configuration.

Paired20s PyVRP solves, identical model/seed/CPU. The RAISED config also raises
PyVRP's midpoint initial penalties, following the existing non-rental shortage rule.
No RouteIQ source files modified. Stock RECOMMENDED formulation otherwise intact.
"""
import os
os.sched_setaffinity(0,{int(os.environ.get('BENCH_CPU','7'))})
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
for key in list(os.environ):
    if key.startswith('ROUTEIQ_TEST_'):os.environ.pop(key,None)
import json,time,sys,warnings,hashlib
from pathlib import Path
from dataclasses import replace
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1];ROOT=BASE.parent
SOURCE=Path(os.environ.get('ROUTEIQ_SOURCE',str(ROOT/'routeiq-20261008')))
sys.path.insert(0,str(SOURCE/'apps/solver'))
import dispatch_solver as ds
import pyvrp_candidate as pv
import pyvrp
from pyvrp.solve import SolveParams
from dispatch_models import DispatchRequest
from providers import MatrixResult

def write(name,value):
    (HERE/name).write_text(json.dumps(value,indent=2,default=str)+'\n')
req=DispatchRequest.model_validate_json((BASE/'large/D3_tight_receiving/request.json').read_text())
tds=ds._truck_days(req);stops,drops,notes=ds._prefilter(req,tds)
mat=json.loads((BASE/'large/D3_tight_receiving/matrix.json').read_text())
assert len(stops)==len(req.stops) and not drops
mx=MatrixResult(mat['distance_m'],mat['duration_s'],'HAVERSINE_DIAGNOSTIC_SAME_SAVED_MATRIX',True)
keep,windowdrops=ds._window_prefilter(stops,tds,mx,req.config)
assert len(keep)==len(stops) and not windowdrops
model=pv.build_model(req,stops,tds,mx)
base,per_unit=pv.worst_case(sum(c['prize'] for c in model.clients),model.vehicle_types,model.dist,model.dur,model.clients,model.depots)
safe=(pv.INT62-base)//max(1,per_unit)
scale=max(max(c['prize'] for c in model.clients),max(v['fixed_cost'] for v in model.vehicle_types))
raised=float(min(10*scale,safe));assert base+int(raised)*per_unit<pv.INT62
meta=dict(source_sha='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b',seed=17,seconds_per_trial=20,cpu_affinity=sorted(os.sched_getaffinity(0)),trials=['stock','raised'],
  default_max_penalty=model.max_penalty,raised_max_penalty=raised,base=base,per_unit=per_unit,int62=pv.INT62,
  safe_cap=safe,scale=scale,bounded_worst_cost=base+int(raised)*per_unit,strict_bound_passed=True,model_summary=model.summary,
  limitation='Only in-memory PyVRP penalty config altered; raising ceiling also changes initial midpoint penalties. Same restrictive soft-window approximation as production. Any feasible PyVRP candidate still requires exact timing/break recheck.',
  request_sha256=hashlib.sha256((BASE/'large/D3_tight_receiving/request.json').read_bytes()).hexdigest())
write('metadata.json',meta);write('request.json',req.model_dump(mode='json'));write('matrix.json',mat)
write('model.json',dict(depots=model.depots,clients=model.clients,vehicle_types=model.vehicle_types,coords=model.coords,type_trucks=model.type_trucks,
    summary=model.summary,max_penalty=model.max_penalty,start_low=model.start_low))
results=[]
for name,m in [('stock',model),('raised',replace(model,max_penalty=raised,penalty_mode='RAISED'))]:
    data=pv.problem_data(m);params=SolveParams() if name=='stock' else SolveParams(penalty=pv.penalty_params(m))
    started=time.perf_counter();stop=pv.Stopper(pv.PvSettings(mode='QUICK',seed=17,max_runtime=20,min_sec=0),started)
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always');res=pyvrp.solve(data,stop=stop,seed=17,collect_stats=False,display=False,params=params)
    elapsed=time.perf_counter()-started;sol=res.best;feasible=bool(sol.is_feasible());rawroutes=pv.routes_of(sol)
    output=dict(mode=name,feasible=feasible,wall_sec=elapsed,iterations=int(res.num_iterations),cost=float(res.cost()) if feasible else None,
      raw_distance=int(sol.distance()),raw_duration=int(sol.duration()),raw_time_warp=int(sol.time_warp()),raw_excess_load=list(sol.excess_load()),
      routes=rawroutes,type_trucks=m.type_trucks,missing=pv.missing_of(rawroutes,len(stops)),stop_reason=stop.reason,
      warnings=[dict(category=w.category.__name__,message=str(w.message)) for w in ws],max_penalty=m.max_penalty,start_low=m.start_low,
      points=stop.report_points())
    if feasible:
        plan,error=pv.plan_of(output,tds,stops);output['mapped_plan']=plan;output['mapping_error']=error
        output['served_by_priority']={p:sum(stops[k].priority==p for loads in plan.values() for load in loads for k in load) for p in range(1,6)}
    write(name+'-candidate.json',output);results.append(output)
    write('summary.json',dict(metadata=meta,results=results));print(json.dumps({k:output[k] for k in ['mode','feasible','wall_sec','iterations','missing','raw_time_warp','raw_excess_load','max_penalty']}),flush=True)
