import pathlib,subprocess,sys,json,time
B=pathlib.Path(__file__).resolve().parent
jobs=[]
for seed in (17,29):
    for name in ('X-n101-k25','X-n125-k30','X-n200-k36'):
        for engine in ('hybrid','pyvrp'):jobs.append((name,engine,seed))
for name in ('R108','RC201'):
    for engine in ('hybrid','pyvrp'):jobs.append((name,engine,17))
for name in ('X-n101-k25','X-n125-k30','X-n200-k36'):jobs.append((name,'ortools',17))
for num,(name,engine,seed) in enumerate(jobs,1):
    print(f'START {num}/{len(jobs)} {name} {engine} seed{seed}',flush=True)
    log=B/'runs'/f'{name}.{engine}.s{seed}.log';log.parent.mkdir(exist_ok=True)
    with log.open('w') as f:
        result=subprocess.run([sys.executable,str(B/'run_public.py'),name,engine,'--seed',str(seed)],stdout=f,stderr=subprocess.STDOUT,timeout=190)
    p=B/'runs'/f'{name}.{engine}.s{seed}.summary.json'
    if p.exists():
        s=json.loads(p.read_text());e=s['evaluation']
        print(json.dumps(dict(job=num,returncode=result.returncode,instance=name,engine=engine,seed=seed,
          distance=e['distance'],bks_gap_pct=e['bks_gap_pct'],valid=e['valid'],served=e['served'],routes=e['routes'],wall_s=s['wall_s'])),flush=True)
    else:print(f'FAILED {log}',flush=True)
