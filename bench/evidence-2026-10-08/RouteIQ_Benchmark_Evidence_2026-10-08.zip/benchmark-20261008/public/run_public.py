"""External benchmark adapter, source unchanged; does not access DB/network."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
if hasattr(os,'sched_setaffinity'):
    available=os.sched_getaffinity(0)
    os.sched_setaffinity(0,{int(os.environ.get('BENCH_CPU','5' if 5 in available else str(min(available))))})
import argparse, json, sys, time, hashlib, pathlib, resource, math
import numpy as np
import vrplib, pyvrp
from pyvrp.stop import MaxRuntime

BASE=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path(os.environ.get('ROUTEIQ_SOURCE','/workspace/scratch/918a93981356/routeiq-20261008/apps/solver'))
SHA='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b'
INSTANCES=['X-n101-k25','X-n125-k30','X-n200-k36','R108','RC201']

def write(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n')

def inputs(name):
    tw=not name.startswith('X-')
    prefix='VRPTW_Solomon_' if tw else 'CVRP_'
    path=BASE/'instances'/f'{prefix}{name}.vrp'
    original=vrplib.read_instance(path)
    data=pyvrp.read(path,round_func='dimacs' if tw else 'round')
    published=np.array(data.distance_matrix(0),dtype=np.int64)
    # One benchmark distance unit is one km. RouteIQ has absolute business-gain
    # thresholds, so scaling published units down to meters changes its policy.
    mat=published*(100 if tw else 1000)
    durations=published*6 if tw else np.zeros_like(mat)
    n=int(original['dimension'])-1
    windows=original.get('time_window')
    horizon=int(windows[0,1]) if tw else 1440
    service=int(original.get('service_time',0))
    coords=original['node_coord']
    # Pins do not set costs/times: the provider uses the published matrix. They
    # do still feed RouteIQ's geometric neighborhood; see README limitation.
    pins=[{'lat':20+float(x)/10000,'lng':50+float(y)/10000} for x,y in coords]
    request=dict(run_id=f'public-{name}',tenant_id='SYNTHETIC-BENCHMARK',
      depot=dict(id='D',**pins[0],open_min=0,close_min=horizon),
      trucks=[dict(id=f'T{i}',code=f'T{i}',capacity_cases=int(original['capacity']),
         capacity_kg=0,fixed_cost=0,trip_cost=0,cost_per_km=1,max_trips=1) for i in range(data.num_vehicles)],
      stops=[dict(stop_id=f'C{i}',order_ids=[f'O{i}'],customer_id=f'C{i}',**pins[i],
         demand_cases=int(original['demand'][i]),demand_kg=0,service_min=service,priority=3,
         hard_start_min=int(windows[i,0]) if tw else 0,hard_end_min=int(windows[i,1]) if tw else 1440)
         for i in range(1,n+1)],
      config=dict(shift_start_min=0,shift_max_min=horizon,latest_return_min=horizon,
         overtime_after_min=None,overtime_cost_per_hour=0,reload_min=0,loading_min_per_case=0,
         window_rule='START',break_min=0,max_trips_per_truck=1,fuel_price_per_litre=0,
         driver_cost_per_hour=0,strict_priorities=False,pref_window_penalty_per_min=0,
         early_preference_per_min={i:0 for i in range(1,6)},use_margin=False,
         change_penalty_per_stop=0,distance_provider='HAVERSINE',haversine_multiplier=1,
         road_time_factor=1,time_limit_sec=60,scenarios=['RECOMMENDED'],search_mode='QUICK'))
    sol=vrplib.read_solution(BASE/'instances'/f'{prefix}{name}.sol')
    scale=1000
    meta=dict(instance=name,n_clients=n,capacity=int(original['capacity']),fleet_limit=data.num_vehicles,
      source_commit='7474b068a8effa7f39448b241314b615c9271525',
      source_url='https://github.com/PyVRP/Instances/blob/7474b068a8effa7f39448b241314b615c9271525/'+prefix.replace('VRPTW_Solomon_','VRPTW/Solomon/').replace('CVRP_','CVRP/')+name+'.vrp',
      local_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rounding='DIMACS floor(distance*10)' if tw else 'nearest integer',
      benchmark_distance_divisor=scale,bks_cost=float(sol['cost']),bks_routes=sol['routes'],
      objective='total distance; no per-vehicle charge; all customers mandatory for valid result',
      physical_mapping='One benchmark distance unit = 1 km. CVRP rounded integer*1000 meters; TW DIMACS integer*100 meters. TW minutes preserved; CVRP travel time unconstrained zero.',
      priority_policy='All clients P3, weighted penalty1e12 objective units per omitted client, above any serving cost. Any result omitting a client is independently invalid.',
      routeiq_sha=SHA)
    write(BASE/'inputs'/f'{name}.request.json',request)
    write(BASE/'inputs'/f'{name}.matrix.json',dict(distance_m=mat.tolist(),duration_s=durations.tolist(),published_distance_integer=published.tolist(),published_integer_divisor=10 if tw else 1,benchmark_distance_divisor=scale,node_ids=['D']+[f'C{i}' for i in range(1,n+1)]))
    write(BASE/'inputs'/f'{name}.meta.json',meta)
    return request,mat,durations,meta,data

def evaluate(routes,request,mat,durations,meta):
    errors=[]; seen=[]; distance=0; detailed=[]
    for j,r in enumerate(routes):
        q=sum(request['stops'][i-1]['demand_cases'] for i in r)
        if q>meta['capacity']:errors.append(f'route{j} capacity {q}>{meta["capacity"]}')
        clock=0;prev=0;length=0
        for i in r:
            seen.append(i); st=request['stops'][i-1]
            clock=max(clock+int(durations[prev,i]),st['hard_start_min']*60)
            if clock>st['hard_end_min']*60:errors.append(f'route{j} node{i} late')
            clock+=st['service_min']*60
            length+=int(mat[prev,i]);prev=i
        clock+=int(durations[prev,0]);length+=int(mat[prev,0]);distance+=length
        if clock>request['depot']['close_min']*60:errors.append(f'route{j} return late')
        detailed.append(dict(nodes=r,demand=q,distance=length/meta['benchmark_distance_divisor'],earliest_return_s=clock))
    if len(routes)>meta['fleet_limit']:errors.append('too many vehicles')
    from collections import Counter
    counts=Counter(seen)
    missing=[i for i in range(1,meta['n_clients']+1) if not counts[i]]
    repeated=[i for i,v in counts.items() if v!=1]
    if missing:errors.append(f'{len(missing)} missing')
    if repeated:errors.append(f'repeated {repeated}')
    return dict(valid=not errors,errors=errors,missing=missing,served=len(counts),distance=distance/meta['benchmark_distance_divisor'],routes=len(routes),route_details=detailed,
      bks_gap_pct=(distance/meta['benchmark_distance_divisor']/meta['bks_cost']-1)*100 if not errors else None)

def main():
    global SOURCE,BASE
    p=argparse.ArgumentParser();p.add_argument('instance',choices=INSTANCES);p.add_argument('engine',choices=['hybrid','ortools','pyvrp','prepare']);p.add_argument('--seed',type=int,default=17);p.add_argument('--seconds',type=int,default=60)
    p.add_argument('--repo',type=pathlib.Path,help='RouteIQ repository root; overrides ROUTEIQ_SOURCE')
    p.add_argument('--output',type=pathlib.Path,help='Output directory containing the instances/ folder; default script directory')
    args=p.parse_args()
    if args.repo:SOURCE=args.repo.resolve()/'apps'/'solver'
    if args.output:BASE=args.output.resolve()
    request,mat,dur,meta,data=inputs(args.instance)
    bks=evaluate(meta['bks_routes'],request,mat,dur,meta)
    assert bks['valid'],bks
    assert abs(bks['distance']-meta['bks_cost'])<1e-6,(bks,meta)
    write(BASE/'inputs'/f'{args.instance}.bks-validation.json',bks)
    if args.engine=='prepare':return
    key=f'{args.instance}.{args.engine}.s{args.seed}'+('' if args.seconds==60 else f'.t{args.seconds}')
    request['config']['time_limit_sec']=args.seconds
    before=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
    if args.engine=='pyvrp':
        model=pyvrp.Model.from_data(data)
        result=model.solve(MaxRuntime(args.seconds),seed=args.seed,collect_stats=False,display=False)
        # PyVRP 0.14 activities index clients from zero; the published files and
        # RouteIQ adapter number depot0 followed by clients1..n.
        routes=[[int(a.idx)+1 for a in r if a.is_client()] for r in result.best.routes()]
        output=dict(feasible=result.is_feasible(),cost=result.cost(),distance=int(result.best.distance()),
          iterations=result.num_iterations,runtime=result.runtime,routes=routes)
    else:
        os.environ.update(SOLVER_PARALLEL='1',SOLVER_PYVRP='on' if args.engine=='hybrid' else 'off',
          SOLVER_PYVRP_MIN_CPUS='1',SOLVER_PYVRP_SEED=str(args.seed),SOLVER_BUDGET_SEC='150')
        os.environ.pop('SOLVER_PYVRP_MAX_ITERS',None)
        sys.path.insert(0,str(SOURCE))
        import dispatch_solver as ds
        from providers import MatrixResult
        from dispatch_models import DispatchRequest
        mx=MatrixResult(mat.tolist(),dur.tolist(),'BENCHMARK_MATRIX',False)
        ds.resolve_matrix=lambda *a,**kw:mx
        response=ds.optimize_dispatch(DispatchRequest.model_validate(request))
        output=response.model_dump(mode='json')
        sc=response.scenarios[0]
        routes=[[int(s.stop_id[1:]) for s in load.stops] for load in sc.loads]
    wall=time.monotonic()-before
    usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    summary=dict(instance=args.instance,engine=args.engine,seed=args.seed,search_budget_s=args.seconds,
      wall_s=wall,children_cpu_s=(usage.ru_utime+usage.ru_stime)-(usage0.ru_utime+usage0.ru_stime),
      self_cpu_s=time.process_time(),affinity=sorted(os.sched_getaffinity(0)),
      routeiq_pyvrp_min_cpus_override=1 if args.engine=='hybrid' else None,
      evaluation=evaluate(routes,request,mat,dur,meta),routes=routes,
      bks_cost=meta['bks_cost'],routeiq_sha=SHA)
    if args.engine!='pyvrp':
        summary['product_feasibility']=output['scenarios'][0]['feasibility']
        summary['product_operating_cost']=output['scenarios'][0]['operating_cost']
        summary['search']=output.get('search')
        summary['warnings']=output.get('warnings')
    write(BASE/'runs'/f'{key}.response.json',output)
    write(BASE/'runs'/f'{key}.summary.json',summary)
    brief={k:v for k,v in summary.items() if k not in ['routes','search','product_feasibility','warnings','evaluation']}
    brief['evaluation']={k:v for k,v in summary['evaluation'].items() if k!='route_details'}
    print(json.dumps(brief),flush=True)

if __name__=='__main__':main()
