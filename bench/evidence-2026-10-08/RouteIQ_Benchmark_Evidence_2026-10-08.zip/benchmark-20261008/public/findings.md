# Findings from the public routing benchmark

All 19 final 60-second benchmark observations returned complete, feasible routes under independent validation. A second reviewer independently parsed the original `.vrp` files, rebuilt the matrices from coordinates and rounding rules, and validated all 19 outputs. The 11 RouteIQ outputs also passed the separate wire-format and cost checker. Initial adapter debugging is excluded.

## Achieved solution quality

| Instance | Published BKS | RouteIQ hybrid mean gap | Standalone PyVRP mean gap | RouteIQ OR-Tools-only gap |
|---|---:|---:|---:|---:|
| X-n101-k25 |27,591|6.466%|0.000%|6.419%|
| X-n125-k30 |55,539|3.399%|0.034%|2.926%|
| X-n200-k36 |58,578|4.855%|0.375%|4.807%|
| R108 |932.1|0.000%|0.494%|Not run|
| RC201 |1,261.8|0.063%|0.000%|Not run|

CVRP hybrid/standalone means contain two seeds each; time-window cases and ablations contain one. The solver version is RouteIQ `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b`, PyVRP 0.14.0 and OR-Tools 9.15.6755. These are distance-only public instances, not real NMWC days, and the Solomon references use DIMACS one-decimal truncation rather than SINTEF's vehicle-first/full-precision convention.

RouteIQ matched R108's published reference exactly and came within 0.064% on RC201. Its PyVRP candidate was chosen in both time-window cases. Conversely, every CVRP hybrid run reported `NO_FEASIBLE_PLAN` for the optional PyVRP candidate; the primary engine provided valid fallback routes, with 3.39–6.47% gaps.

The main search cap was 60 seconds. Actual RouteIQ end-to-end solver calls took 60.82–62.20 seconds; standalone PyVRP took 60.015–60.054 seconds. All processes used one CPU; the hybrid's two searches shared it and explicitly bypassed its normal two-CPU gate. These differences and the geometric-neighborhood mapping disclosed in README prevent a clean general engine-speed ranking. They do not change the independent distance or feasibility of the returned routes.

## Confirmed penalty-scale limitation

`apps/solver/pyvrp_candidate.py:434–454` raises the PyVRP penalty ceiling when rentals exist or aggregate fleet capacity is insufficient. An ample own fleet otherwise retains the default 100,000 ceiling, even when monetary arc coefficients are much larger because of RouteIQ's 100,000-unit money scale.

The controlled X-n101 diagnostic held the same embedded model, matrix, seed 17 and ten-second search limit:

| Setting | Embedded feasible answer | Independently validated distance |
|---|---|---:|
| Stock ceiling 100,000 | None | — |
| Isolated integer-safe ceiling 266,794,577,357 | All 100 customers |27,591, equal to published BKS |

The published reference routes were also directly constructed as a feasible solution of the stock embedded model. Therefore the input has a feasible answer; the stock candidate's failure is not an inconsistency in the public constraints. Changing the ceiling parameter changes the observed outcome. PyVRP initializes penalties at that ceiling's midpoint, so the probe also changes the resulting starting penalties through the same default initialization rule; it does not isolate the ceiling from initialization. The adjusted model retained an explicit worst-case bound below `INT62`.

A separate ordinary-distance case rules out the claim that this exists only at the public benchmark's artificial large distance scale:

- Two owned trucks, each 100-case capacity, one trip, no rentals.
- Two deliveries of 51 and 50 cases at the same location 5 km from the depot.
- Five minutes service each, receiving 08:00–17:00, distance cost 1 OMR/km, no other charges.
- A valid two-truck plan costs 20 OMR. A one-case overload would save one 10-km round trip; the stock maximum overload penalty represents only 1 OMR for that extra case.
- With the same seed 17 and two seconds per run, the stock embedded candidate found no feasible plan; the isolated raised ceiling found the valid 20 OMR plan.

This tiny witness exercises case-capacity mode, not NMWC's pallet mode. It identifies an engine-integration robustness defect, not evidence that the application releases overloaded plans. The primary engine and final feasibility checks protected every official benchmark output. Its practical impact is losing the optional search's improvement opportunities and spending CPU on a search that cannot produce a usable candidate.

Suggested correction: make penalty calibration account for objective magnitudes and capacity/time units on ordinary own-fleet days as well as hire/shortage days, preserve the integer-overflow bound, and benchmark both starting penalties and adaptation behavior. The diagnostic override is not a finished production fix and was never included in the official benchmark scores.

## Files

- `results.json`, `results.md`: all 19 final observations and grouped statistics.
- `inputs/`: requests, matrices, reference metadata and validated reference routes.
- `runs/`: raw answers, complete routes and logs.
- `diagnostics/`: the four isolated stock/raised model probes, including the small ordinary-distance request.
- `run_public.py`, `run_batch.py`, `diagnose_penalty.py`, `diagnose_tiny_case.py`: reproduction code, with no repository or production edits.

The findings support a focused optimization improvement and stronger measured evidence. They do not establish global optimality on 300+ invoice days, a production SLA or superiority over commercial routing services.
