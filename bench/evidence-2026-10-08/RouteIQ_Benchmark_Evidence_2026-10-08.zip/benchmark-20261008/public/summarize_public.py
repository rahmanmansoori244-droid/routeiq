import json,pathlib,statistics,platform,importlib.metadata
B=pathlib.Path(__file__).resolve().parent
records=[]
for p in sorted((B/'runs').glob('*.summary.json')):
    r=json.loads(p.read_text())
    if r['search_budget_s']!=60:continue
    r['file']=str(p.relative_to(B));records.append(r)
grouped=[]
for name in ('X-n101-k25','X-n125-k30','X-n200-k36','R108','RC201'):
    for engine in ('hybrid','pyvrp','ortools'):
        rr=[r for r in records if r['instance']==name and r['engine']==engine]
        if not rr:continue
        valid=[r for r in rr if r['evaluation']['valid']]
        costs=[r['evaluation']['distance'] for r in valid]
        gaps=[r['evaluation']['bks_gap_pct'] for r in valid]
        grouped.append(dict(instance=name,engine=engine,n=len(rr),valid=len(valid),
          seeds=[r['seed'] for r in rr],bks_cost=rr[0]['bks_cost'],
          mean_distance=statistics.mean(costs) if costs else None,
          best_distance=min(costs) if costs else None,worst_distance=max(costs) if costs else None,
          mean_gap_pct=statistics.mean(gaps) if gaps else None,
          best_gap_pct=min(gaps) if gaps else None,worst_gap_pct=max(gaps) if gaps else None,
          min_wall_s=min(r['wall_s'] for r in rr),max_wall_s=max(r['wall_s'] for r in rr),
          routes=[r['evaluation']['routes'] for r in rr]))
summary=dict(expected_runs=19,completed_runs=len(records),valid_runs=sum(r['evaluation']['valid'] for r in records),groups=grouped,
  environment=dict(python=platform.python_version(),platform=platform.platform(),versions={x:importlib.metadata.version(x) for x in ['pyvrp','ortools','numpy','vrplib']}),
  runs=[dict(file=r['file'],instance=r['instance'],engine=r['engine'],seed=r['seed'],wall_s=r['wall_s'],
    distance=r['evaluation']['distance'],gap_pct=r['evaluation']['bks_gap_pct'],valid=r['evaluation']['valid'],
    served=r['evaluation']['served'],routes=r['evaluation']['routes'],
    pyvrp=(r.get('search') or {}).get('pyvrp')) for r in records])
(B/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
out=['# Public benchmark results','',f"Completed {summary['completed_runs']}/{summary['expected_runs']} intended runs; independently valid {summary['valid_runs']}.",'',
 '| Instance | Method | Runs | BKS | Mean distance | Mean gap | Gap range | Routes | Wall seconds |',
 '|---|---|---:|---:|---:|---:|---:|---|---:|']
for g in grouped:
    out.append(f"| {g['instance']} | {g['engine']} | {g['valid']}/{g['n']} | {g['bks_cost']:,.1f} | {g['mean_distance']:,.1f} | {g['mean_gap_pct']:.2f}% | {g['best_gap_pct']:.2f}–{g['worst_gap_pct']:.2f}% | {', '.join(map(str,g['routes']))} | {g['min_wall_s']:.1f}–{g['max_wall_s']:.1f} |")
out+=['','Distance is the standardized benchmark objective. Published references use nearest-integer CVRP distances or DIMACS one-decimal truncated VRPTW distances; Solomon references minimize distance, not vehicles first. See README.md for the controlled adapter and substantial limitations.','',
'The hybrid shares one core between two searches, whereas standalone PyVRP uses that core for one search. RouteIQ postprocessing extends elapsed time beyond the main 60-second search window. This is not a hardware-normalized claim about the fastest algorithm.']
(B/'results.md').write_text('\n'.join(out)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['groups','runs']}))
