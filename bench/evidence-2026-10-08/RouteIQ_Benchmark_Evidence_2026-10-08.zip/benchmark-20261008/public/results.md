# Public benchmark results

Completed 19/19 intended runs; independently valid 19.

| Instance | Method | Runs | BKS | Mean distance | Mean gap | Gap range | Routes | Wall seconds |
|---|---|---:|---:|---:|---:|---:|---|---:|
| X-n101-k25 | hybrid | 2/2 | 27,591.0 | 29,375.0 | 6.47% | 6.47–6.47% | 27, 27 | 61.1–61.3 |
| X-n101-k25 | pyvrp | 2/2 | 27,591.0 | 27,591.0 | 0.00% | 0.00–0.00% | 26, 26 | 60.0–60.0 |
| X-n101-k25 | ortools | 1/1 | 27,591.0 | 29,362.0 | 6.42% | 6.42–6.42% | 27 | 61.9–61.9 |
| X-n125-k30 | hybrid | 2/2 | 55,539.0 | 57,427.0 | 3.40% | 3.39–3.40% | 31, 31 | 62.1–62.2 |
| X-n125-k30 | pyvrp | 2/2 | 55,539.0 | 55,558.0 | 0.03% | 0.02–0.05% | 30, 30 | 60.0–60.0 |
| X-n125-k30 | ortools | 1/1 | 55,539.0 | 57,164.0 | 2.93% | 2.93–2.93% | 31 | 60.8–60.8 |
| X-n200-k36 | hybrid | 2/2 | 58,578.0 | 61,422.0 | 4.86% | 4.86–4.86% | 37, 37 | 61.7–62.2 |
| X-n200-k36 | pyvrp | 2/2 | 58,578.0 | 58,797.5 | 0.37% | 0.11–0.64% | 36, 36 | 60.1–60.1 |
| X-n200-k36 | ortools | 1/1 | 58,578.0 | 61,394.0 | 4.81% | 4.81–4.81% | 37 | 62.1–62.1 |
| R108 | hybrid | 1/1 | 932.1 | 932.1 | 0.00% | 0.00–0.00% | 10 | 61.3–61.3 |
| R108 | pyvrp | 1/1 | 932.1 | 936.7 | 0.49% | 0.49–0.49% | 10 | 60.0–60.0 |
| RC201 | hybrid | 1/1 | 1,261.8 | 1,262.6 | 0.06% | 0.06–0.06% | 9 | 61.2–61.2 |
| RC201 | pyvrp | 1/1 | 1,261.8 | 1,261.8 | 0.00% | 0.00–0.00% | 9 | 60.0–60.0 |

Distance is the standardized benchmark objective. Published references use nearest-integer CVRP distances or DIMACS one-decimal truncated VRPTW distances; Solomon references minimize distance, not vehicles first. See README.md for the controlled adapter and substantial limitations.

The hybrid shares one core between two searches, whereas standalone PyVRP uses that core for one search. RouteIQ postprocessing extends elapsed time beyond the main 60-second search window. This is not a hardware-normalized claim about the fastest algorithm.
