"""Four-second ordinary-distance penalty witness; excluded from benchmark."""
import os,sys,time,pyvrp
from dataclasses import replace
import run_public as bench
sys.path.insert(0,str(bench.SOURCE))
import dispatch_solver as ds
import pyvrp_candidate as pv
from dispatch_models import DispatchRequest
from providers import MatrixResult

def main():
    req=DispatchRequest.model_validate(dict(run_id='TINY-OWN-TRUCK-PENALTY',tenant_id='SYNTHETIC',
      depot=dict(id='D',lat=23.5,lng=58.4,open_min=480,close_min=1020),
      trucks=[dict(id=f'T{i}',capacity_cases=100,cost_per_km=1,max_trips=1) for i in (1,2)],
      stops=[dict(stop_id=f'C{i}',customer_id=f'C{i}',order_ids=[f'O{i}'],lat=23.5,lng=58.45,
         demand_cases=q,service_min=5,priority=3,hard_start_min=480,hard_end_min=1020) for i,q in [(1,51),(2,50)]],
      config=dict(shift_start_min=480,shift_max_min=540,latest_return_min=1020,
         window_rule='FINISH',time_limit_sec=2,max_trips_per_truck=1,reload_min=0,
         overtime_after_min=None,overtime_cost_per_hour=0,driver_cost_per_hour=0,
         pref_window_penalty_per_min=0,early_preference_per_min={p:0 for p in range(1,6)},
         change_penalty_per_stop=0,use_margin=False,scenarios=['RECOMMENDED'])))
    D=[[0,5000,5000],[5000,0,0],[5000,0,0]]
    T=[[0,300,300],[300,0,0],[300,0,0]]
    mx=MatrixResult(D,T,'SYNTHETIC_EXACT',False);tds=ds._truck_days(req)
    bench.write(bench.BASE/'diagnostics/tiny-own-case.request.json',req.model_dump(mode='json'))
    bench.write(bench.BASE/'diagnostics/tiny-own-case.matrix.json',dict(distance_m=D,duration_s=T))
    original=pv.build_model
    for mode in ('stock','raised_ceiling_diagnostic'):
        def build(*args):
            m=original(*args)
            if mode=='stock':return m
            base,per_unit=pv.worst_case(sum(c['prize'] for c in m.clients),m.vehicle_types,m.dist,m.dur,m.clients,m.depots)
            cap=min(10*max(c['prize'] for c in m.clients),(pv.INT62-base-1)//max(1,per_unit))
            return replace(m,max_penalty=float(cap),penalty_mode='RAISED')
        pv.build_model=build
        model=build(req,req.stops,tds,mx)
        base,per_unit=pv.worst_case(sum(c['prize'] for c in model.clients),model.vehicle_types,model.dist,model.dur,model.clients,model.depots)
        guard=base+int(model.max_penalty)*per_unit
        assert guard<pv.INT62
        witness=pyvrp.Solution(pv.problem_data(model),[[0],[1]])
        assert witness.is_feasible()
        settings=pv.PvSettings(mode='QUICK',seed=17,max_runtime=2,min_sec=2,max_iters=None)
        start=time.monotonic();result=pv.solve_in_worker((req,req.stops,tds,mx,settings))
        routes=[trip for r in result.get('routes',[]) for trip in r['trips']]
        seen=[i for r in routes for i in r]
        valid=(sorted(seen)==[0,1] and len(routes)<=2 and all(sum(req.stops[i].demand_cases for i in r)<=100 for r in routes))
        km=sum(sum(D[a][b] for a,b in zip([0]+[i+1 for i in r],[i+1 for i in r]+[0])) for r in routes)/1000
        # Each singleton finishes at08:10 and returns08:15; both require their
        # own truck. This proves20OMR with no omitted demand or window conflict.
        out=dict(mode=mode,max_penalty=model.max_penalty,int64_guard_ok=guard<pv.INT62,
           max_penalized_upper=guard,known_feasible_witness=dict(routes=[[0],[1]],cost=20,valid_in_embedded_model=True),
           wall_s=time.monotonic()-start,result=result,independent_complete_capacity_check=valid,
           independently_computed_km=km if valid else None,independently_computed_cost=km if valid else None)
        bench.write(bench.BASE/'diagnostics'/f'tiny-own-case-{mode}.json',out)
        print(mode,'feasible=',result.get('feasible'),'missing=',result.get('missing'),'valid=',valid,'cost=',km,flush=True)
    pv.build_model=original

if __name__=='__main__':main()
