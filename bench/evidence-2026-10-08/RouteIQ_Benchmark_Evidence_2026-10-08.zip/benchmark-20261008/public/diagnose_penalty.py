"""Isolated model witness, NOT a benchmark result or source-code fix.

Same public request, seed and time; compare stock vs larger int64-safe penalty
ceiling. No RouteIQ repository files or production settings are modified.
"""
import os,sys,json,time,pyvrp
from dataclasses import replace
import run_public as bench
sys.path.insert(0,str(bench.SOURCE))
import dispatch_solver as ds
import pyvrp_candidate as pv
from dispatch_models import DispatchRequest
from providers import MatrixResult

def main():
    payload,D,T,meta,_=bench.inputs('X-n101-k25')
    req=DispatchRequest.model_validate(payload)
    tds=ds._truck_days(req)
    mx=MatrixResult(D.tolist(),T.tolist(),'BENCHMARK_MATRIX',False)
    original=pv.build_model
    records=[]
    for mode in ('stock','raised_ceiling_diagnostic'):
        def build(*a):
            m=original(*a)
            if mode=='stock':return m
            base,per_unit=pv.worst_case(sum(c['prize'] for c in m.clients),m.vehicle_types,m.dist,m.dur,m.clients,m.depots)
            safe=(pv.INT62-base-1)//max(1,per_unit)
            ceiling=min(10*max(c['prize'] for c in m.clients),safe)
            # Match the product's raised-ceiling behavior, changing only this
            # in-memory diagnostic model, not its original source.
            return replace(m,max_penalty=float(ceiling),penalty_mode='RAISED')
        pv.build_model=build
        model=build(req,req.stops,tds,mx)
        witness=pyvrp.Solution(pv.problem_data(model),[[i-1 for i in route] for route in meta['bks_routes']])
        assert witness.is_feasible()
        base,per_unit=pv.worst_case(sum(c['prize'] for c in model.clients),model.vehicle_types,model.dist,model.dur,model.clients,model.depots)
        guarded_upper=base+int(model.max_penalty)*per_unit
        assert guarded_upper<pv.INT62
        settings=pv.PvSettings(mode='QUICK',seed=17,max_runtime=10,min_sec=10,max_iters=None)
        start=time.monotonic();result=pv.solve_in_worker((req,req.stops,tds,mx,settings))
        routes=[[int(i)+1 for i in trip] for r in result.get('routes',[]) for trip in r['trips']]
        # Candidate worker calls its extracted route representation 'routes'.
        record=dict(mode=mode,wall_s=time.monotonic()-start,max_penalty=model.max_penalty,
          worst_penalized_upper=guarded_upper,int62_bound=pv.INT62,int64_guard_ok=guarded_upper<pv.INT62,
          published_bks_is_feasible_in_embedded_model=bool(witness.is_feasible()),
          published_bks_embedded_distance=int(witness.distance()),
          maximum_arc_cost=max(int(m.max()) for m in model.dist),
          maximum_prize=max(c['prize'] for c in model.clients),affinity=sorted(os.sched_getaffinity(0)),
          result=result,routes=routes)
        if routes:record['evaluation']=bench.evaluate(routes,payload,D,T,meta)
        records.append(record)
        bench.write(bench.BASE/'diagnostics'/f'penalty-{mode}.json',record)
        print(json.dumps({k:record[k] for k in ['mode','wall_s','max_penalty','maximum_arc_cost']}|dict(feasible=result.get('feasible'),missing=result.get('missing'),keys=list(result))),flush=True)
    pv.build_model=original

if __name__=='__main__':main()
