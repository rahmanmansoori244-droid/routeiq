# Public routing benchmark — 8 October 2026

This is a limited, reproducible comparison of RouteIQ at `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b` with the standalone PyVRP 0.14.0 solver on five public routing instances. It does not test production traffic, invoices, loading-bay rules, late-order intake, dispatch persistence or proof of global optimality.

Completed: **19/19 final observations independently valid**, with raw-file/matrix validation by a separate reviewer as well as this harness's checker. See `results.md`/`results.json` for the complete table and `findings.md` for the confirmed penalty-calibration limitation and four isolated diagnostic probes. Actual solver-call wall times were 60.82–62.20 seconds for RouteIQ and 60.015–60.054 seconds for standalone PyVRP.

## Inputs and provenance

The original instances, published best-known routes and README conventions come from [PyVRP/Instances](https://github.com/PyVRP/Instances/tree/7474b068a8effa7f39448b241314b615c9271525), pinned to Git tree `7474b068a8effa7f39448b241314b615c9271525`.

- CVRP: X-n101-k25 (100 clients), X-n125-k30 (124 clients), X-n200-k36 (199 clients). Nearest-integer Euclidean distances.
- VRPTW: Solomon R108 and RC201 (100 clients each). DIMACS convention: distance and travel time truncated to one decimal. Objective: total distance, not a lexicographic minimum-vehicles objective.
- `instances/source-manifest.json` records all source URLs, Git blob IDs and local SHA-256 hashes. Every downloaded file was checked against its Git blob hash, including original line endings.
- Published reference routes are independently checked for full service, capacity and time-window feasibility and their distance recomputed before every solve. These are called **best-known solutions (BKS)**; the bundle makes no blanket assertion that they are proven optima.

## Adapter

RouteIQ's source is unchanged. A local provider-boundary injection supplies the published matrix instead of requesting a road service. Other stages use RouteIQ's actual solver, candidate selection, exact retiming and postprocessing.

Coordinate representation limitation: the adapter encodes published coordinates as latitude/longitude pins near 20°N, 50°E. These pins never determine benchmark distance or travel time, which come exclusively from the exact published matrices. They do feed RouteIQ's local geometric-neighborhood projection; compared with standalone PyVRP's original x/y coordinates this includes approximately 6% axis rescaling. That can change search trajectories. The independently measured solution distances and feasibility remain comparable, but this is another reason to avoid a pure engine-performance ranking. A future experiment should invert the local projection to preserve identical auxiliary geometry; this series preserves its declared mapping throughout.

One benchmark distance unit is mapped to one kilometer. Thus CVRP integer distances become `distance_m = integer * 1000`; VRPTW DIMACS integers become `distance_m = integer * 100`. This preserves RouteIQ's absolute business-improvement thresholds rather than arbitrarily shrinking the public problem to a tiny route. CVRP coordinate units are dimensionless: this mapping is a declared standardized adapter convention, not a claim that these are realistic 27,000-km NMWC days. The original published integer matrix is also saved separately. RouteIQ's monetary integer objective scale can affect its embedded PyVRP penalty behavior even when the mathematical distance objective is equivalent; report such warnings and failures rather than silently retuning them out of the benchmark.

All trucks are identical, single-trip, with the published capacity and no weight or pallet restriction. No fixed truck cost, driver-time cost, overtime cost, preference, margin, continuity or rental cost applies. Distance costs one model money unit per kilometer. All clients have equal P3 priority with a large weighted omission penalty; every output must independently serve **every** client to qualify. This penalty choice is solely the standard all-clients-required benchmark adapter, not NMWC's production priority policy.

CVRP permits the same fleet bound as `pyvrp.read`: one vehicle per client, without a per-vehicle charge. It does not assume the filename's `k` is a hard maximum. Travel duration and service are zero in CVRP because time is unconstrained in these instances.

VRPTW permits the published 25 vehicles, starts service inside the stated window (`START`), preserves service time and depot closing exactly, and uses `duration_s = DIMACS_integer * 6`. No break, reload, loading or other NMWC-specific rule is imposed.

`inputs/` contains the request, matrices, metadata, reference routes and reference validation for every instance. `runs/` contains raw responses, full routes, search diagnostics, independently recomputed summaries and console logs.

## Budget and comparisons

- Every solver receives a 60-second principal search budget.
- Every process and child process is pinned to one CPU (CPU 5 in this execution); common BLAS/OpenMP thread counts are one. This is a shared virtual machine, not a dedicated performance laboratory.
- RouteIQ hybrid runs its OR-Tools search and PyVRP candidate concurrently, sharing this one core. `SOLVER_PYVRP_MIN_CPUS=1` explicitly overrides the usual two-CPU gate for this comparison. Its real postprocessing is included and actual elapsed time is reported.
- Standalone PyVRP has the entire core for its 60-second search. Therefore this compares useful answer quality under a common search-window cap, **not perfectly equal end-to-end or equal-engine CPU budgets**. Do not advertise a general speed ranking from these measurements.
- OR-Tools-only RouteIQ is an ablation of the hybrid, not a separate third-party OR-Tools implementation.
- PyVRP is also the hybrid's second engine. Standalone PyVRP is a specialized same-engine reference, not evidence that RouteIQ beats or loses to an independent competitor implementation.
- CVRP runs use two seeds, 17 and 29, for each hybrid/standalone pair. VRPTW has one seed, 17. OR-Tools-only runs once for each CVRP case; it has no independent seed setting here. This is exploratory coverage, not a statistically powered study.

Quality is independently evaluated from route sequences and original demand/window data. Report full-service feasibility before distance. BKS gaps are `(distance / BKS_distance - 1) * 100`; they are not mathematical optimality gaps unless that particular BKS has separately been proved optimal.

The directories beginning `adapter-debug-` contain discarded adapter development runs, not benchmark observations. Initial distance mapping and an interrupted execution were corrected **before** collecting the final series. An initial standalone extraction failed because PyVRP 0.14 uses zero-based client activities rather than the older `visits()` API; it is an adapter error, not a solver failure, and that run is rerun. Exclude all debug directories and non-60-second runs from results.

## Reproduce

Use a checkout of the pinned RouteIQ revision with its solver dependencies installed, including PyVRP 0.14.0, OR-Tools 9.15.6755, numpy and vrplib. On Linux:

```bash
BENCH_CPU=5 python run_public.py X-n101-k25 hybrid --repo /path/to/routeiq --seed 17
BENCH_CPU=5 python run_public.py X-n101-k25 pyvrp --seed 17
BENCH_CPU=5 python run_public.py X-n101-k25 ortools --repo /path/to/routeiq --seed 17
```

`--seconds` changes the search budget. `--output` changes the output directory, which must contain the supplied `instances/` folder. `ROUTEIQ_SOURCE=/path/to/routeiq/apps/solver` can replace `--repo`. `run_batch.py` executes the recorded 19-run schedule and honors these environment variables. Windows users should use Linux/WSL for the same affinity controls; process start and timing can otherwise differ.
