"""Render the saved benchmark evidence as a paginated PDF and standalone HTML."""
from pathlib import Path
import argparse, html, json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4

HERE=Path(__file__).resolve().parent
NAVY=colors.HexColor('#162C45'); TEAL=colors.HexColor('#087F8C')
INK=colors.HexColor('#24354A'); MUTED=colors.HexColor('#5D6A79'); LIGHT=colors.HexColor('#F1F5F9')

def render(content_path, outdir):
    data=json.loads(Path(content_path).read_text()); outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    base=Path('/usr/share/fonts/truetype/dejavu')
    pdfmetrics.registerFont(TTFont('Body',str(base/'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('BodyBold',str(base/'DejaVuSans-Bold.ttf')))
    pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')
    styles={
      'title':ParagraphStyle('title',fontName='BodyBold',fontSize=24,leading=29,textColor=NAVY,spaceAfter=13),
      'kicker':ParagraphStyle('kicker',fontName='BodyBold',fontSize=8.2,leading=11,textColor=TEAL,spaceAfter=8),
      'body':ParagraphStyle('body',fontName='Body',fontSize=9.2,leading=13.5,textColor=INK,spaceAfter=9),
      'small':ParagraphStyle('small',fontName='Body',fontSize=7.5,leading=10.5,textColor=MUTED,spaceAfter=7),
      'heading':ParagraphStyle('heading',fontName='BodyBold',fontSize=12,leading=16,textColor=NAVY,spaceBefore=9,spaceAfter=6),
      'cell':ParagraphStyle('cell',fontName='Body',fontSize=8.1,leading=11.2,textColor=INK),
      'headcell':ParagraphStyle('headcell',fontName='BodyBold',fontSize=8,leading=10.7,textColor=colors.white),
    }
    width=A4[0]-88
    story=[]; html_pages=[]
    for idx,page in enumerate(data['pages']):
        if idx:story.append(PageBreak())
        story.append(Paragraph(html.escape(page.get('kicker','ROUTEIQ / BENCHMARK EVIDENCE')),styles['kicker']))
        story.append(Paragraph(html.escape(page['title']),styles['title']))
        hp=[f'<section><p class="kicker">{html.escape(page.get("kicker","ROUTEIQ / BENCHMARK EVIDENCE"))}</p><h1>{html.escape(page["title"])}</h1>']
        for block in page['blocks']:
            typ=block.get('type','p')
            if typ in ['p','small','h']:
                sty=styles[{'p':'body','small':'small','h':'heading'}[typ]]
                story.append(Paragraph(block['text'],sty))
                tag='h2' if typ=='h' else 'p';cls=' class="small"' if typ=='small' else ''
                hp.append(f'<{tag}{cls}>{block["text"]}</{tag}>')
            elif typ=='table':
                rows=block['rows']; ratios=block.get('widths',[1]*len(rows[0])); scale=width/sum(ratios)
                rendered=[[Paragraph(str(cell),styles['headcell'] if r==0 else styles['cell']) for cell in row] for r,row in enumerate(rows)]
                tab=Table(rendered,colWidths=[x*scale for x in ratios],repeatRows=1,hAlign='LEFT')
                tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,LIGHT]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.6,TEAL),('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#D8E0E8'))]))
                story.extend([tab,Spacer(1,10)])
                hp.append('<table>'+''.join('<tr>'+''.join(f'<{"th" if r==0 else "td"}>{c}</{"th" if r==0 else "td"}>' for c in row)+'</tr>' for r,row in enumerate(rows))+'</table>')
        hp.append('</section>');html_pages.append(''.join(hp))
    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#D8E0E8'));canvas.line(44,39,A4[0]-44,39)
        canvas.setFont('Body',7);canvas.setFillColor(MUTED)
        canvas.drawString(44,27,'RouteIQ | 8 October 2026 | source 5b2ee06 | isolated synthetic/public tests')
        canvas.drawRightString(A4[0]-44,27,str(doc.page))
    pdf=outdir/'RouteIQ_Benchmark_Report_2026-10-08.pdf'
    SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=43,bottomMargin=52,title='RouteIQ: simulation and optimization benchmark',author='Independent review',pageCompression=1).build(story,onFirstPage=footer,onLaterPages=footer)
    css='body{font:15px/1.6 system-ui,sans-serif;background:#edf2f7;color:#24354a;margin:0}main{max-width:1000px;margin:auto}section{background:white;padding:42px 48px;margin:24px 0;border-radius:10px}h1{font-size:30px;line-height:1.2;color:#162c45}h2{font-size:20px;color:#162c45}.kicker{color:#087f8c;font-size:12px;font-weight:bold;letter-spacing:1px}.small{font-size:12px;color:#5d6a79}table{width:100%;border-collapse:collapse;font-size:13px;margin:18px 0}th{background:#162c45;color:white;text-align:left}th,td{padding:10px;vertical-align:top;border-bottom:1px solid #d8e0e8}tr:nth-child(odd){background:#f1f5f9}a{color:#087f8c}@media(max-width:650px){section{padding:24px 16px}table{font-size:11px}th,td{padding:6px}}'
    (outdir/'RouteIQ_Benchmark_Report_2026-10-08.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RouteIQ benchmark evidence</title><style>'+css+'</style><main>'+''.join(html_pages)+'</main></html>')
    print(json.dumps({'pdf':str(pdf),'html':str(outdir/'RouteIQ_Benchmark_Report_2026-10-08.html'),'planned_pages':len(data['pages'])}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--content',default=str(HERE/'report_content.json'));p.add_argument('--out',default=str(HERE/'output'));a=p.parse_args();render(a.content,a.out)
