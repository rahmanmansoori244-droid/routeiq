"""Twenty serial controlled runs. Alternates mode order to reduce sequence effects."""
import json, subprocess, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    results=[]
    for idx,case in enumerate(json.loads((HERE/'cases.json').read_text())):
        for seed in [17,29]:
            modes=['off','on'] if (idx+(seed==29))%2==0 else ['on','off']
            for mode in modes:
                label=f'{mode}-seed{seed}';out=HERE/case['id']/label;out.mkdir(exist_ok=True)
                print(f'START {case["id"]} {label}',flush=True);start=time.time()
                with (out/'run.log').open('w') as f:
                    try:
                        run=subprocess.run([sys.executable,str(HERE/'run_one.py'),case['id'],mode,str(seed)],stdout=f,stderr=subprocess.STDOUT,timeout=270)
                        result=dict(case=case['id'],mode=mode,seed=seed,returncode=run.returncode,wall_sec=time.time()-start)
                    except subprocess.TimeoutExpired:
                        result=dict(case=case['id'],mode=mode,seed=seed,error='EXTERNAL_TIMEOUT_270',wall_sec=time.time()-start)
                results.append(result);(HERE/'run-status.json').write_text(json.dumps(results,indent=2));print(f'DONE {result}',flush=True)
                if result.get('returncode')!=0:print('Stopped on unexpected failure for investigation.',flush=True);sys.exit(1)
