"""Summarize completed runs; never label unequal service as monetary savings."""
import json, statistics
from pathlib import Path
HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    allruns=[];comparisons=[]
    for definition in json.loads((HERE/'cases.json').read_text()):
        base=HERE/definition['id'];paired={}
        for seed in [17,29]:
            for mode in ['off','on']:
                f=base/f'{mode}-seed{seed}'/'summary.json'
                if not f.exists():continue
                s=json.loads(f.read_text());s['operating_plus_preferences']=s['operating_cost']+sum((s['preference_penalties'] or {}).values())
                s['dispatchable']=(s.get('feasibility') or {}).get('status')=='VERIFIED'
                s['response_path']=str(f.parent.relative_to(HERE)/'response.json');allruns.append(s);paired[seed,mode]=s
            if (seed,'off') in paired and (seed,'on') in paired:
                a,b=paired[seed,'off'],paired[seed,'on'];same=a['service_vector']==b['service_vector']
                valid_a=(a.get('feasibility') or {}).get('status')=='VERIFIED';valid_b=(b.get('feasibility') or {}).get('status')=='VERIFIED'
                comparable=same and valid_a and valid_b
                comparisons.append(dict(case=definition['id'],seed=seed,equal_priority_service=same,off_dispatchable=valid_a,on_dispatchable=valid_b,
                    comparison_status='both_valid' if valid_a and valid_b else 'neither_valid' if not(valid_a or valid_b) else 'on_only_valid' if valid_b else 'off_only_valid',
                    off_service=a['service_vector'],on_service=b['service_vector'],
                    service_lexicographic_comparison=('on_better' if b['service_vector']>a['service_vector'] else 'off_better' if b['service_vector']<a['service_vector'] else 'equal'),
                    off_wall_sec=a['wall_sec'],on_wall_sec=b['wall_sec'],off_operating_cost=a['operating_cost'],on_operating_cost=b['operating_cost'],
                    off_km=a['km'],on_km=b['km'],off_served_cases=a['served_cases'],on_served_cases=b['served_cases'],
                    off_served_invoices=a['served_invoices'],on_served_invoices=b['served_invoices'],
                    cost_change_pct=(100*(b['operating_cost']/a['operating_cost']-1) if comparable else None),
                    distance_change_pct=(100*(b['km']/a['km']-1) if comparable else None),
                    cost_comparison_note='Costs are comparable only conditional on the reported priority service vector; stop identities can differ.',
                    off_cost_plus_preferences=a['operating_plus_preferences'],on_cost_plus_preferences=b['operating_plus_preferences'],
                    cost_plus_preferences_change_pct=100*(b['operating_plus_preferences']/a['operating_plus_preferences']-1) if comparable else None))
    (HERE/'all-run-summaries.json').write_text(json.dumps(allruns,indent=2))
    (HERE/'paired-comparisons.json').write_text(json.dumps(comparisons,indent=2))
    for s in allruns:print(s['case'],s['hybrid'],s['seed'],s['service_vector'],round(s['operating_cost'],2),s['km'],round(s['wall_sec'],2))
