"""Replay the known D3 failure using native QUICK automatic limits and cap.
Must be launched after run_all.py finishes, to retain serialized CPU allocation.
"""
import json, os, signal, subprocess, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    done=json.loads((HERE/'run-status.json').read_text())
    if len(done)!=20 or any(r.get('returncode')!=0 for r in done):
        raise SystemExit('Complete the twenty-run primary batch before native follow-ups.')
    results=[]
    for mode in ['on','off']:
        label=f'{mode}-seed17-auto-budget540';out=HERE/'D3_tight_receiving'/label;out.mkdir(exist_ok=True)
        if (out/'response.json').exists():raise SystemExit(f'Refusing to overwrite {out}')
        print(f'START native D3 {mode}',flush=True);started=time.time()
        with (out/'run.log').open('w') as f:
            proc=subprocess.Popen([sys.executable,str(HERE/'run_one.py'),'D3_tight_receiving',mode,'17','--auto-limit','--budget-sec','540'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=proc.wait(timeout=570)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGTERM)
                try:proc.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                code=-9
        row=dict(case='D3_tight_receiving',mode=mode,seed=17,label=label,returncode=code,wall_sec=time.time()-started)
        if (out/'summary.json').exists():row['feasibility']=json.loads((out/'summary.json').read_text())['feasibility']['status']
        results.append(row);(HERE/'native-followup-status.json').write_text(json.dumps(results,indent=2));print(f'DONE {row}',flush=True)
        if code!=0:raise SystemExit(code)
        if mode=='on' and row.get('feasibility')=='VERIFIED':break
