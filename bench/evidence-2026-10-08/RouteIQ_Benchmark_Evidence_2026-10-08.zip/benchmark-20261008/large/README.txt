RouteIQ large synthetic operating-day benchmark
Pinned source: 5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b

This is actual execution of optimize_dispatch and its subprocess OR-Tools,
CP-SAT and (when ON) PyVRP engines. Nothing touches production. All customer,
invoice and product data are fictional. Coordinates describe plausible Muscat
clusters but are not verified receiving addresses. Distances and travel times
are Haversine estimates; no road network, truck restrictions or traffic were
measured. Stock is assumed available. D2 is deliberately a backlog/stock surge
above the company's reported daily production, not a typical single-depot day.

The benchmark boundary starts at DispatchRequest. Raw invoice lineages are
provided and independently reconciled, but this does not exercise the web
CSV intake, request builder, database, UI or delivery events. No customer order
requires splitting to fit the largest supplied truck. Frozen D5 trips are
earlier work outside the pending invoice file, and count against time and trips.

Five scenarios each contain 320-420 invoices and 180-230 customer destinations.
Each has mixed SKU pallet factors, FINISH receiving windows, multi-trip fleets,
reload and per-case loading, 60-minute driver breaks, 18:00 latest return.
D5 costs are remaining-plan/incremental costs: earlier frozen work and its
already-incurred charges are excluded. Do not label them whole-day costs.
Payload kg is disabled (capacity_kg=0), as in the reviewed owner configuration.

Primary comparison: production multiprocessing ON, 4-core affinity ceiling
(Linux CPUs 0-3), thread env caps 1, recommended scenario only, 60-second primary
search limit, 240-second whole-request cap. These are explicit benchmark limits:
production automatic QUICK gives these 200+ stop sizes 150 seconds and normally
has a 540-second request cap. Runs are serialized inside this suite; other
review processes may run on separate CPUs of the shared host. ON and OFF have
the same limits, not a promise of identical CPU work or elapsed time. Report
actual elapsed with every result. OFF retains OR-Tools and post-solve repacking;
it is an ablation of the hybrid pipeline, not stock OR-Tools vs stock PyVRP.

PyVRP seeds are 17 and 29. OR-Tools does not expose a request seed here, so OFF
labels 17 and 29 are repeat labels; wall-clock searches and CP-SAT can vary.
Two seeds/repeats are a small reproducibility check, not a statistically powered
study. Mode order alternates. No speed or quality claim generalizes beyond the
saved cases and stated limits. Strict service vectors must be compared before
cost; monetary changes are only calculated when that vector is equal. Even then,
partially served days can contain different destinations/cases/invoices, so
compare those alongside the priority counts. Fully served days share all work.

Independent greedy comparator: greedy_baseline.py imports only Python standard
library, reads the same matrix and inputs, and constructs priority-first nearest
feasible routes. It uses conservative whole-minute travel and full-load loading
allowances. It is a simple algorithmic witness/reference, not actual historical
NMWC dispatcher performance. It does not optimize or score soft preferences.
Its independent check uses a conservative-baseline interpretation, rather than
requiring the production engine's nearest-minute wire-format convention.
The baseline response's objective_value/unserved_penalty/window_penalty fields
are unused placeholders, not scores. The separate independent validation report
recomputes its real soft penalties; compare those reports for cost+preferences.

Reproduction (Linux, Python 3.12, dependencies in pinned repo requirements):
Copy this folder's Python scripts into a fresh empty output directory first;
completed production response files are protected from accidental overwrite.
  export ROUTEIQ_SOURCE=/absolute/path/to/routeiq
  python generate_days.py
  python run_all.py
  python greedy_baseline.py
  python summarize.py
For the known D3 failure, run_native_followups.py then reproduces native QUICK
automatic search time with the production 540-second request cap. It runs ON
first and OFF too if ON still lacks a VERIFIED plan, under distinct labels.
Use the same virtual environment as the solver; no development .env is needed.
run_all.py uses sys.executable for children. Scripts default to the review's
snapshot path when ROUTEIQ_SOURCE is absent; the environment override makes
the source location portable. run_one.py currently pins Linux CPUs 0-3, so adapt
that stated setting using --cpus if reproducing on a differently numbered CPU
allocation. A supplementary D5 native-auto run uses CPUs 4,5,6,8 while D3 runs
on 0-3. Each retains four cores but shares the host's eight-CPU quota; these
supplementary timings are not a service-level agreement or isolated speed test.

Artifact map:
  cases.json: scenario dimensions
  capacity-bounds.json: trivial necessary capacity/service bounds (NOT cost gaps)
  manifest.json: planned run file mapping
  run-status.json: completed process outcomes
  CASE/invoices.json: raw products, customers, invoices and SKU line lineage
  CASE/request.json: exact unmodified case input
  CASE/matrix.json: reproducible full Haversine estimate
  CASE/MODE-seedN/request.json: exact run input
  CASE/MODE-seedN/matrix-used.json: actual production provider output captured
  CASE/MODE-seedN/response.json: complete production response
  CASE/MODE-seedN/metadata.json, run.log, summary.json: settings and evidence
  CASE/greedy-baseline/: independent simple comparator where supplied
  all-run-summaries.json, paired-comparisons.json: generated summaries

Feasibility is independently checked elsewhere in this evidence bundle. A valid
route is not an optimality proof. These large cases have no proven cost optimum.

Completed results (all source executions pinned to the SHA above):
  20 paired/repeated primary runs + 2 native QUICK follow-ups = 22 executions.
  5 independent greedy references. 1,800 unique fictional invoices across five
  operating days, aggregated into 1,050 destinations; repeats are not new data.
  Independent physical/accounting checks pass 18 production outputs and reject
  4, all D3 at the deliberately shorter 60-second primary search. Those four
  also carry the product's own VIOLATED flag, so no false VERIFIED escape was
  observed. This count is not a production failure-rate estimate.

  D1 normal: all deliveries in all four runs. Hybrid lowers cash 8.83%-13.75%
  and cash plus preferences 9.45%-11.65% against the paired OFF results.
  D2 wholesale: all deliveries in all four runs. Hybrid lowers cash 6.61%-7.60%
  and cash plus preferences 6.50%-7.93%. Elapsed time is approximately equal
  between ON/OFF in these pairs, about 76 seconds. Two repeats do not establish
  a statistical confidence interval or general savings forecast.
  D3 tight receiving: all four 60-second runs fail exact break/loading checks.
  Native QUICK (automatic 150-second search, 540-second cap) recovers all 200
  destinations and 340 invoices, independently verified, in 155.87 seconds.
  Its cash cost is 623.324 OMR and cash+preferences 656.023. PyVRP still produced
  no feasible candidate; OR-Tools and exact repair supplied the valid plan.
  D4 shortage: all P1-P3 destinations served in all four runs; vector
  [44,44,44,5,2]. Full service is impossible even before considering travel:
  158.761 pallets requested vs a 120-pallet total new-trip capacity ceiling.
  D5 frozen/late replan: the four 60-second outputs serve 175-176 destinations.
  The native QUICK follow-up (automatic 110 seconds, 540-second cap) returns a
  physically valid plan serving only 84 of 180 destinations: [10,16,14,23,21]
  across P1-P5, leaving 96 out, including three P1 and twenty P2 destinations.
  The independently verified greedy witness serves ALL 180 destinations, 320
  invoices and 4,826 cases under the exact same request constraints. This proves
  the native output's lost service is avoidable. Its smaller cash cost is not
  a saving. The witness's remaining-plan cash is 518.1134667 OMR, with 913.107 km;
  its cash+preferences is 963.293 OMR-equivalent. Strict service priority ranks
  that full-service witness above plans missing P1/P2, regardless of the latter's
  cheaper cash/preference subtotal.

The D5 native log shows both raw searches proposing every destination, then
exact timing/repair rejecting the full routes. The main fit repair returns a
FEASIBLE incumbent with a reported 100% gap; the second candidate's fit repair
is UNKNOWN. The final answer keeps six loads and drops 96 stops. This is a
quality/repair failure, not a failure of the physical feasibility checker.
The longer replay performed worse, but shared-host and time-limited search
effects mean the loss cannot be attributed solely to changing search duration.

All original production response files remain immutable. The 17 responses
checkpointed during execution were re-hashed unchanged at completion. See
artifact-sha256.json, manifest.json, result-overview.json and the independent
validation reports. Experimental penalty diagnostics elsewhere in the bundle
are distinct from these stock-source runs and do not represent deployed fixes.
