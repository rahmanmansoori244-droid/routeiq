"""Execute the real current solver, production worker mode, isolated synthetic request."""
import argparse, json, logging, os, platform, sys, time, traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
sys.path.insert(0,str(Path(os.environ.get('ROUTEIQ_SOURCE', ROOT/'routeiq-20261008'))/'apps/solver'))

def main():
    p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('mode',choices=['on','off']);p.add_argument('seed',type=int)
    p.add_argument('--search-sec',type=int,default=60);p.add_argument('--thorough-sec',type=int,default=0)
    p.add_argument('--budget-sec',type=int,default=240);p.add_argument('--auto-limit',action='store_true');p.add_argument('--label')
    p.add_argument('--cpus',default='0,1,2,3');a=p.parse_args()
    os.sched_setaffinity(0,{int(x) for x in a.cpus.split(',')})
    for k in list(os.environ):
        if k.startswith('ROUTEIQ_TEST_') or k in ['SOLVER_ALLOW_INPROCESS_FALLBACK','SOLVER_PYVRP_MAX_ITERS']:os.environ.pop(k,None)
    os.environ.update(SOLVER_PYVRP=a.mode,SOLVER_PYVRP_SEED=str(a.seed),SOLVER_PARALLEL='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',SOLVER_BUDGET_SEC=str(a.budget_sec))
    from dispatch_models import DispatchRequest
    import dispatch_solver as ds
    import pyvrp_candidate as pv
    from importlib.metadata import version
    r=DispatchRequest.model_validate_json((HERE/a.case/'request.json').read_text())
    r.config.time_limit_sec=None if a.auto_limit else a.search_sec
    if a.thorough_sec:r.config.search_mode='THOROUGH';r.config.max_search_sec=a.thorough_sec
    label=a.label or f'{a.mode}-seed{a.seed}'+(f'-thorough{a.thorough_sec}' if a.thorough_sec else '')+(f'-auto-budget{a.budget_sec}' if a.auto_limit else '')
    out=HERE/a.case/label;out.mkdir(exist_ok=True)
    if (out/'response.json').exists():
        raise SystemExit(f'Refusing to overwrite completed evidence: {out}. Use a new --label or a fresh output directory.')
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(name)s %(message)s')
    original=ds.resolve_matrix
    def captured(*args,**kwargs):
        mx=original(*args,**kwargs)
        (out/'matrix-used.json').write_text(json.dumps(dict(coords=args[0],distance_m=mx.distance_m,duration_s=mx.duration_s,quality=mx.quality,provider=mx.provider_name),separators=(',',':')))
        return mx
    ds.resolve_matrix=captured
    (out/'request.json').write_text(r.model_dump_json(indent=2))
    metadata=dict(sha='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b',case=a.case,hybrid=a.mode,pyvrp_seed=a.seed,
        ortools_seed='not exposed; repeat label only',affinity=sorted(os.sched_getaffinity(0)),parallel=True,budget_sec=a.budget_sec,
        primary_search_sec=None if a.auto_limit else a.search_sec,thorough_sec=a.thorough_sec,python=platform.python_version(),ortools=version('ortools'),pyvrp=version('pyvrp'),
        cpu_gate=pv.status(),synthetic=True,request_boundary='DispatchRequest; web intake/request-builder not exercised',matrix='HAVERSINE estimated')
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
    started=time.perf_counter()
    try:
        response=ds.optimize_dispatch(r);elapsed=time.perf_counter()-started
        (out/'response.json').write_text(response.model_dump_json(indent=2))
        sc=next(s for s in response.scenarios if s.name=='RECOMMENDED')
        served={s.stop_id for ld in sc.loads for s in ld.stops};unserved={s.stop_id for s in sc.unserved}
        result=dict(case=a.case,hybrid=a.mode,seed=a.seed,wall_sec=elapsed,search=response.search.model_dump() if response.search else None,
            service_vector=[sum(s.priority==p and s.stop_id in served for s in r.stops) for p in range(1,6)],
            unserved_vector=[sum(s.priority==p and s.stop_id in unserved for s in r.stops) for p in range(1,6)],
            input_stops=len(r.stops),served_stops=len(served),served_invoices=sum(len(s.order_ids) for s in r.stops if s.stop_id in served),
            input_invoices=sum(len(s.order_ids) for s in r.stops),input_cases=sum(s.demand_cases for s in r.stops),served_cases=sc.total_cases,
            operating_cost=sc.operating_cost,km=sc.total_distance_km,trucks=sc.trucks_used,loads=sc.trips,objective=sc.objective.model_dump(),
            preference_penalties=sc.preference_penalties.model_dump() if sc.preference_penalties else None,status=sc.status,solver_status=sc.solver_status,
            feasibility=sc.feasibility.model_dump() if sc.feasibility else None,warnings=response.warnings+sc.warnings,
            stop_reconciliation=sorted(served|unserved)==sorted(s.stop_id for s in r.stops) and not(served&unserved))
        (out/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
    except Exception as exc:
        (out/'error.json').write_text(json.dumps(dict(type=type(exc).__name__,message=str(exc),elapsed_sec=time.perf_counter()-started,traceback=traceback.format_exc()),indent=2));raise

if __name__=='__main__':main()
