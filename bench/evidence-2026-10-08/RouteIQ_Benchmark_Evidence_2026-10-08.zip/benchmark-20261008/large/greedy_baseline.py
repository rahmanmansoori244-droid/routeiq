"""Independent simple priority-first, nearest-next feasible dispatch baseline.

No RouteIQ solver, timing, feasibility or costing helpers are imported. Uses the
same saved matrix/input. Conservative integer-minute travel and full-load
turnaround estimates. This is NOT NMWC's historical dispatcher performance.
"""
import json, math
from pathlib import Path
HERE=Path(__file__).resolve().parent

def build(case='D1_normal'):
    base=HERE/case;r=json.loads((base/'request.json').read_text());m=json.loads((base/'matrix.json').read_text());cfg=r['config']
    byid={s['stop_id']:s for s in r['stops']};idx={s:i for i,s in enumerate(m['node_ids'])};left=set(byid)
    dm=m['distance_m'];tt=[[math.ceil(v/60) for v in row] for row in m['duration_s']]
    loads=[];days=[];depotclose=min(r['depot']['close_min'],cfg['latest_return_min'])
    for truck in r['trucks']:
        frozen=sorted(truck['frozen_trips'],key=lambda f:f['load_no'])
        daystart=min(f['depart_min'] for f in frozen) if frozen else cfg['shift_start_min']
        last_return=max(f['return_min'] for f in frozen) if frozen else None
        paid_origin=last_return;had_break=any(f.get('break_start_min') is not None for f in frozen);truckloads=[]
        for load_no in range(len(frozen)+1,truck['max_trips']+1):
            turn=cfg['reload_min']+math.ceil(cfg['loading_min_per_case']*truck['bays']*120)
            depart=daystart if last_return is None else last_return+turn
            if cfg.get('loading_from_min') is not None:depart=max(depart,cfg['loading_from_min']+turn)
            if not frozen and not truckloads:daystart=depart
            latest=min(depotclose,daystart+cfg['shift_max_min']);room=truck['bays']*cfg['pallet_fill_pct']*10
            now=depart;node=0;stops=[];pu=0;cases=0;kg=0;dist=0;br=None;break_taken=had_break
            while True:
                candidates=[]
                for sid in sorted(left):
                    s=byid[sid];j=idx[sid]
                    if pu+s['demand_pallet_units']>room:continue
                    start=max(now+tt[node][j],s['hard_start_min'] or 0);trialbreak=None
                    if not break_taken and start+s['service_min']>cfg['break_start_from_min']:
                        bstart=max(now,cfg['break_start_from_min'])
                        if bstart>cfg['break_start_to_min']:continue
                        trialbreak={'start_min':bstart,'end_min':bstart+cfg['break_min'],'where':'ROAD','after_sequence':len(stops)}
                        arrival=bstart+cfg['break_min']+tt[node][j]
                        start=max(arrival,s['hard_start_min'] or 0)
                    else:arrival=now+tt[node][j]
                    end=start+s['service_min']
                    if end>s['hard_end_min'] or end+tt[j][0]>latest:continue
                    candidates.append(((s['priority'],dm[node][j],s['hard_end_min'],sid),sid,arrival,start,end,trialbreak))
                if not candidates:break
                _,sid,arrival,start,end,trialbreak=min(candidates);s=byid[sid];j=idx[sid]
                if trialbreak:br=trialbreak;break_taken=True
                leg=dm[node][j]/1000;dist+=leg
                stops.append(dict(sequence=len(stops)+1,stop_id=sid,order_ids=s['order_ids'],customer_id=s['customer_id'],
                    arrival_min=arrival,service_start_min=start,departure_min=end,wait_min=start-arrival,
                    leg_km=leg,cum_km=round(dist,3),leg_min=tt[node][j],cases=s['demand_cases'],kg=s['demand_kg'],
                    hard_window_ok=True,pref_window_ok=start>=s['pref_start_min'] and end<=s['pref_end_min'],leg_estimated=True,pallet_units=s['demand_pallet_units']))
                pu+=s['demand_pallet_units'];cases+=s['demand_cases'];kg+=s['demand_kg'];now=end;node=j;left.remove(sid)
            if not stops:break
            returned=now+tt[node][0];dist+=dm[node][0]/1000;paid_from=depart if last_return is None else last_return
            paid=returned-paid_from;ot=max(0,returned-daystart-cfg['overtime_after_min'])-max(0,paid_from-daystart-cfg['overtime_after_min'])
            fixed=truck['fixed_cost'] if load_no==1 else 0;trip=truck['trip_cost'];distance=dist*truck['cost_per_km'];litres=dist/truck['km_per_litre'];fuel=litres*cfg['fuel_price_per_litre'];driver=paid/60*cfg['driver_cost_per_hour'];overtime=ot/60*cfg['overtime_cost_per_hour']
            load=dict(truck_id=truck['id'],load_no=load_no,depart_min=depart,return_min=returned,distance_km=round(dist,3),duration_min=returned-depart,
                cases=cases,kg=round(kg,1),utilization_pct=100*pu/(truck['bays']*1000),fuel_litres=litres,fuel_cost=fuel,distance_cost=distance,
                time_cost=driver,fixed_cost=fixed,total_cost=fixed+trip+distance+fuel+driver+overtime,return_leg_km=dm[node][0]/1000,stops=stops,
                trip_cost=trip,driver_cost=driver,overtime_cost=overtime,driver_paid_min=paid,paid_from_min=paid_from,overtime_min=ot,
                estimated_legs=len(stops)+1,driver_break=br,pallet_units=pu,pallet_room_units=room)
            loads.append(load);truckloads.append(load);last_return=returned;had_break=break_taken
        if truckloads:
            days.append(dict(truck_id=truck['id'],loads=len(truckloads),frozen_loads=len(frozen),day_start_min=daystart,paid_from_min=paid_origin if frozen else daystart,last_return_min=last_return,
                paid_min=sum(l['driver_paid_min'] for l in truckloads),overtime_min=sum(l['overtime_min'] for l in truckloads),
                **{k:sum(l[k] for l in truckloads) for k in ['fixed_cost','trip_cost','distance_cost','fuel_cost','driver_cost','overtime_cost','total_cost']},
                break_status='PLANNED' if had_break else 'NOT_NEEDED',break_start_min=next((l['driver_break']['start_min'] for l in truckloads if l['driver_break']),None)))
    unserved=[dict(stop_id=sid,order_ids=byid[sid]['order_ids'],reason_code='OPTIMIZER_UNSERVED',reason_message='Simple greedy baseline did not place this stop.') for sid in sorted(left)]
    objective={k:sum(l[k] for l in loads) for k in ['fixed_cost','trip_cost','distance_cost','fuel_cost','time_cost','overtime_cost']};objective.update(unserved_penalty=0,window_penalty=0,margin_served=None)
    sc=dict(name='RECOMMENDED',status='OPTIMIZED',solver_status='INDEPENDENT_GREEDY_BASELINE',solver_time_sec=0,time_limit_sec=0,objective_value=0,
        objective=objective,trucks_used=len({d['truck_id'] for d in days}|{t['id'] for t in r['trucks'] if t['frozen_trips']}),trips=len(loads),total_distance_km=sum(l['distance_km'] for l in loads),total_duration_min=sum(l['duration_min'] for l in loads),
        total_cases=sum(l['cases'] for l in loads),total_kg=sum(l['kg'] for l in loads),avg_utilization_pct=sum(l['utilization_pct'] for l in loads)/len(loads),
        fuel_litres=sum(l['fuel_litres'] for l in loads),fuel_cost=sum(l['fuel_cost'] for l in loads),operating_cost=sum(l['total_cost'] for l in loads),loads=loads,unserved=unserved,
        warnings=['Independent simple greedy comparator, not historical dispatcher baseline. Soft preferences not optimized or scored.'],feasibility=None,cost_policy='TRUCK_DAY_SPAN',cost_version=2,truck_days=days)
    out=base/'greedy-baseline';out.mkdir(exist_ok=True)
    (out/'request.json').write_text(json.dumps(r,indent=2));(out/'matrix-used.json').write_text((base/'matrix.json').read_text())
    (out/'response.json').write_text(json.dumps(dict(run_id=r['run_id'],engine='independent greedy',matrix_provider='HAVERSINE',distance_is_estimated=True,distance_quality='ESTIMATED',scenarios=[sc],warnings=[]),indent=2))
    summary=dict(service_vector=[sum(s['priority']==p and s['stop_id'] not in left for s in r['stops']) for p in range(1,6)],unserved=len(left),operating_cost=sc['operating_cost'],km=sc['total_distance_km'],trucks=len(days),loads=len(loads),
        served_cases=sc['total_cases'],served_invoices=sum(len(s['order_ids']) for s in r['stops'] if s['stop_id'] not in left),
        input_invoices=sum(len(s['order_ids']) for s in r['stops']),runtime_not_benchmarked=True)
    (out/'summary.json').write_text(json.dumps(summary,indent=2));print(summary)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('case',nargs='?',default='all');args=parser.parse_args()
    for case in (['D1_normal','D2_wholesale_surge','D3_tight_receiving','D4_fleet_shortage','D5_late_frozen'] if args.case=='all' else [args.case]):
        print(case);build(case)
