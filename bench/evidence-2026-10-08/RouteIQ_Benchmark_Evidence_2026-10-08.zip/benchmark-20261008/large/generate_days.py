"""Fictional NMWC-like operating days, no customer or production data.

Aggregation follows the DispatchRequest contract. This is deliberately a solver-boundary
benchmark, not execution of the web intake/database/request-builder path.
"""
import json, math, random, sys, os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(Path(os.environ.get('ROUTEIQ_SOURCE', ROOT / 'routeiq-20261008')) / 'apps/solver'))
from dispatch_models import DispatchRequest, DispatchDepot, DispatchTruck, DispatchStop, DispatchConfig, FrozenTrip
from providers import HaversineProvider

PRODUCTS = [dict(sku='WATER_500_24', cases_per_pallet=100, kg_per_case=12.5),
            dict(sku='WATER_1500_6', cases_per_pallet=80, kg_per_case=9.5),
            dict(sku='WATER_330_24', cases_per_pallet=120, kg_per_case=8.4)]
DEFINITIONS = [
    ('D1_normal', 220, 360, 12, 101, 'Normal mixed grocery, horeca and modern-trade day.'),
    ('D2_wholesale_surge', 230, 420, 14, 202, 'Bulk customers and mixed-SKU pallet demand; several loads required.'),
    ('D3_tight_receiving', 200, 340, 12, 303, 'Morning receiving peaks plus afternoon-only customers; FINISH semantics.'),
    ('D4_fleet_shortage', 220, 360, 5, 404, 'Five available trucks; strict P1-to-P5 service priorities under shortage.'),
    ('D5_late_frozen', 180, 320, 12, 505, '10:00 replan around six earlier frozen trips and 25 late/VIP destinations.'),
]

def pieces(total, n, rnd):
    cuts = sorted(rnd.sample(range(1, total), n - 1)) if n > 1 else []
    return [b-a for a,b in zip([0]+cuts, cuts+[total])]

def make_day(name, n, invoice_count, truck_count, seed, description):
    rnd = random.Random(seed)
    counts = [1] * n
    for _ in range(invoice_count-n):
        counts[rnd.randrange(n)] += 1
    centers = [(23.61,58.43),(23.58,58.34),(23.57,58.25),(23.65,58.17),(23.55,58.47)]
    stops, customers, invoices = [], [], []
    seq = 0
    for i in range(n):
        c = centers[i % len(centers)]
        lat,lng=round(c[0]+rnd.uniform(-.035,.035),6),round(c[1]+rnd.uniform(-.04,.04),6)
        kind = 'modern_trade' if i%10==0 else ('horeca' if i%5==0 else 'grocery')
        total = rnd.randint(100,210) if kind=='modern_trade' else rnd.randint(35,80) if kind=='horeca' else rnd.randint(12,45)
        priority = rnd.choice([1,2]) if kind=='modern_trade' else rnd.choice([2,3]) if kind=='horeca' else rnd.choice([3,4,5])
        service = 25 if kind=='modern_trade' else 14 if kind=='horeca' else 8
        start,end=(420,690) if kind=='modern_trade' else (420,780) if kind=='horeca' else (420,1080)
        if name=='D2_wholesale_surge' and i<40:
            total=rnd.randint(300,650); service=25; priority=rnd.choice([1,2,3]); start,end=420,960;kind='wholesale'
        if name=='D3_tight_receiving':
            if i<70: start,end,service=450,630,18
            elif i<110: start,end=840,1020
        if name=='D4_fleet_shortage':
            priority=(i%5)+1; total=rnd.randint(45,100); start,end=420,1080;service=12
        late = name=='D5_late_frozen' and i<25
        if name=='D5_late_frozen':
            start,end=600,1080;service=8 if kind=='grocery' else 15
            total = rnd.randint(10,45)
            if late: priority=1 if i<8 else 2;end=780 if i<8 else 960
        customer=f'{name}-C{i+1:03d}'
        customer_record=dict(customer_id=customer,name=f'Fictional {kind} {i+1:03d}',kind=kind,lat=lat,lng=lng,
                             priority=priority,hard_start_min=start,hard_end_min=end,service_min=service)
        customers.append(customer_record)
        ids=[];total_kg=0.;pallet_units=0
        for q in pieces(total,counts[i],rnd):
            seq+=1;invoice_id=f'{name}-INV{seq:04d}';ids.append(invoice_id)
            skus=rnd.sample(PRODUCTS,min(q,rnd.randint(1,3)))
            lines=[]
            for j,(sku,qty) in enumerate(zip(skus,pieces(q,len(skus),rnd))):
                kg=round(qty*sku['kg_per_case'],1);pu=math.ceil(qty*1000/sku['cases_per_pallet'])
                lines.append(dict(line_id=f'{invoice_id}-L{j+1}',sku=sku['sku'],cases=qty,kg=kg,pallet_units=pu))
                total_kg+=kg;pallet_units+=pu
            invoices.append(dict(invoice_id=invoice_id,customer_id=customer,late=late,priority=priority,lines=lines))
        stops.append(DispatchStop(stop_id=f'{name}-S{i+1:03d}',order_ids=ids,customer_id=customer,lat=lat,lng=lng,
            demand_cases=total,demand_kg=round(total_kg,1),demand_pallet_units=pallet_units,service_min=service,
            priority=priority,hard_start_min=start,hard_end_min=end,pref_start_min=max(start,540),pref_end_min=min(end,1020),late=late,
            previous_truck_id=(f'T{i%truck_count+1:02d}' if name=='D5_late_frozen' and not late else None)))
    trucks=[]
    for i in range(truck_count):
        bays=[6,8,12][i%3]
        frozen=[FrozenTrip(load_no=1,depart_min=420,return_min=570+i*5,cases=240,pallet_units=2700)] if name=='D5_late_frozen' and i<6 else []
        trucks.append(DispatchTruck(id=f'T{i+1:02d}',code=f'T{i+1:02d}',capacity_cases=bays*100,capacity_kg=0,bays=bays,
            fixed_cost=25,trip_cost=2,cost_per_km=.12,km_per_litre=4.5,max_trips=3,frozen_trips=frozen))
    cfg=DispatchConfig(distance_provider='HAVERSINE',haversine_multiplier=1.3,avg_speed_kmh=35,window_rule='FINISH',
        shift_start_min=420,shift_max_min=660,latest_return_min=1080,break_min=60,break_start_from_min=720,break_start_to_min=840,
        reload_min=25,loading_min_per_case=.04,loading_from_min=600 if name=='D5_late_frozen' else None,
        fuel_price_per_litre=.26,driver_cost_per_hour=2.5,time_limit_sec=60,search_mode='QUICK',scenarios=['RECOMMENDED'],
        strict_priorities=True,change_penalty_per_stop=3,use_margin=False)
    req=DispatchRequest(run_id=name,tenant_id='fictional-benchmark',depot=DispatchDepot(id='fictional-ghala',lat=23.585,lng=58.39,open_min=360,close_min=1080),trucks=trucks,stops=stops,config=cfg)
    out=HERE/name;out.mkdir(parents=True,exist_ok=True)
    (out/'request.json').write_text(req.model_dump_json(indent=2))
    raw=dict(synthetic=True,description=description,generator_seed=seed,products=PRODUCTS,customers=customers,invoices=invoices,
             aggregation='One stop per customer. Sum cases, kg and per-invoice-line ceil(cases*1000/cases_per_pallet). No splitting needed: every stop fits at least one truck.',
             frozen_scope='Frozen trip quantities are prior work outside the pending invoice file; preserve these intervals and do not count them as new deliveries.')
    (out/'invoices.json').write_text(json.dumps(raw,indent=2))
    coords=[(req.depot.lat,req.depot.lng)]+[(s.lat,s.lng) for s in stops]
    mx=HaversineProvider(cfg.haversine_multiplier,cfg.avg_speed_kmh).get_matrix(coords)
    matrix=dict(node_ids=['DEPOT']+[s.stop_id for s in stops],coords=coords,distance_m=mx.distance_m,duration_s=mx.duration_s,
                source='HAVERSINE: synthetic distance estimate, no road routing or traffic',multiplier=1.3,avg_speed_kmh=35)
    (out/'matrix.json').write_text(json.dumps(matrix,separators=(',',':')))
    summary=dict(id=name,description=description,invoices=len(invoices),customers=n,solver_stops=len(stops),cases=sum(s.demand_cases for s in stops),
        pallets=sum(s.demand_pallet_units for s in stops)/1000,trucks=len(trucks),priority_counts={p:sum(s.priority==p for s in stops) for p in range(1,6)},
        frozen_trips=sum(len(t.frozen_trips) for t in trucks),late_stops=sum(s.late for s in stops))
    (out/'case-summary.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    summaries=[make_day(*d) for d in DEFINITIONS]
    (HERE/'cases.json').write_text(json.dumps(summaries,indent=2))
    print(json.dumps(summaries,indent=2))
