"""Demonstrate avoidable missed service in saved P02; never modify production.

Keeps every original returned load unchanged. Solves the original unserved
stops on a previously unused truck, then unions the two disjoint truck plans.
The union must be independently validated; no global optimum is claimed.
"""
from pathlib import Path
import argparse, copy, json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(Path(os.environ.get('ROUTEIQ_SOURCE', ROOT.parents[1]/'routeiq-20261008'))/'apps/solver'))
RESULTS = ROOT / 'results'
parser=argparse.ArgumentParser()
parser.add_argument('--base',default='P02-frozen-late-VIP')
parser.add_argument('--output',default='P02-full-service-witness')
parser.add_argument('--reuse-repair',action='store_true')
args=parser.parse_args()
BASE = RESULTS / args.base
REPAIR = RESULTS / 'P02-unused-truck-repair'
UNION = RESULTS / args.output
def read(path): return json.loads(path.read_text())
def write(path, value): path.write_text(json.dumps(value, indent=2)+'\n')

request = read(BASE / 'request.json')
answer = read(BASE / 'response.json')
scenario = next(s for s in answer['scenarios'] if s['name'] == 'RECOMMENDED')
missing = {s['stop_id'] for s in scenario['unserved']}
used = {l['truck_id'] for l in scenario['loads']}
unused = [t for t in request['trucks'] if t['id'] not in used and not t.get('frozen_trips')]
if not missing or not unused:
    raise SystemExit('This saved run has no unserved stops or unused trucks: no claimed counterexample.')

repair = copy.deepcopy(request)
repair['stops'] = [s for s in request['stops'] if s['stop_id'] in missing]
repair['trucks'] = [unused[0]]
repair['config']['time_limit_sec'] = 2
REPAIR.mkdir(exist_ok=True)
python = os.environ.get('ROUTEIQ_PYTHON', sys.executable)
if args.reuse_repair:
    saved=read(REPAIR/'request.json')
    # Only the primary-budget representation may differ; physical constraints
    # and the stop/truck input must remain identical before reusing an answer.
    from dispatch_models import DispatchRequest
    left=DispatchRequest.model_validate(saved).model_dump()
    right=DispatchRequest.model_validate(repair).model_dump()
    assert left==right,'Saved repair input differs from current unused-truck request.'
else:
    write(REPAIR / 'request.json', repair)
    with (REPAIR / 'solver.stdout.txt').open('w') as log:
        subprocess.run([python, str(ROOT / 'run_solver.py'), str(REPAIR / 'request.json'),
                        str(REPAIR / 'response.json')], check=True, stdout=log, stderr=subprocess.STDOUT)
extra = read(REPAIR / 'response.json')['scenarios'][0]
assert not extra['unserved'], 'Unused truck did not serve every missed stop.'
assert used.isdisjoint(l['truck_id'] for l in extra['loads'])
assert {s['stop_id'] for l in extra['loads'] for s in l['stops']} == missing

before = copy.deepcopy(scenario)
scenario['loads'] += extra['loads']
scenario['unserved'] = []
for field in ['trucks_used','trips','total_cases','total_kg','total_duration_min',
              'total_pallet_units','paid_driver_min','estimated_legs']:
    if scenario.get(field) is not None and extra.get(field) is not None:
        scenario[field] += extra[field]
for field in ['total_distance_km','fuel_litres','fuel_cost','operating_cost']:
    scenario[field] = round(scenario[field] + extra[field], 3)
scenario['truck_days'] += extra['truck_days']
scenario['avg_utilization_pct'] = sum(l['utilization_pct'] for l in scenario['loads'])/len(scenario['loads'])
scenario['warnings'] = ['Constructed feasible witness: original returned routes kept unchanged; '
                       'missed stop routed by actual optimizer on a previously unused truck. '
                       'Not a fresh whole-day RouteIQ solve or global optimum.']
answer['engine'] = 'constructed union of independently solved disjoint trucks'
answer['warnings'] = scenario['warnings']
answer['search'] = None
UNION.mkdir(exist_ok=True)
write(UNION / 'request.json', request)
write(UNION / 'response.json', answer)
write(UNION / 'construction.json', {
    'original': BASE.name, 'repair': REPAIR.name,
    'unchangedOriginalLoads': len(before['loads']), 'repairedStopIds': sorted(missing),
    'beforeCases': before['total_cases'], 'afterCases': scenario['total_cases'],
    'beforeOperatingCost': before['operating_cost'], 'afterOperatingCost': scenario['operating_cost'],
    'note': 'Identical original full request. Frozen-load cases remain external reservations.'})
checker = ROOT.parent / 'validation' / 'validate.py'
command=[python,str(checker),str(UNION/'request.json'),str(UNION/'response.json'),
         '--output',str(UNION/'independent-check.json')]
if (BASE/'matrix-used.json').exists():command+=['--matrix',str(BASE/'matrix-used.json')]
subprocess.run(command,check=True)
assert read(UNION/'independent-check.json')['status'] == 'PASS'
print(json.dumps(read(UNION/'construction.json'), indent=2))
