"""Replay saved P02 in normal worker mode, two CPUs, unmodified PyVRP CPU gate.

Run only after reserving/releasing these CPUs with other benchmark lanes.
"""
from pathlib import Path
import json, logging, os, platform, sys, time

HERE=Path(__file__).resolve().parent
REPO=Path(os.environ.get('ROUTEIQ_SOURCE', HERE.parents[1]/'routeiq-20261008'))
sys.path.insert(0,str(REPO/'apps/solver'))

def main():
    cpus={int(x) for x in os.environ.get('ROUTEIQ_TWO_CPUS','0,1').split(',')}
    assert len(cpus)==2
    os.sched_setaffinity(0,cpus)
    for key in list(os.environ):
        if key.startswith('ROUTEIQ_TEST_') or key in {
            'SOLVER_ALLOW_INPROCESS_FALLBACK','SOLVER_PYVRP_MAX_ITERS',
            'SOLVER_PYVRP_MIN_CPUS','SOLVER_BUDGET_SEC',
        }: os.environ.pop(key,None)
    os.environ.update(SOLVER_PARALLEL='1',SOLVER_PYVRP='on',SOLVER_PYVRP_SEED='1',
                      OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    from dispatch_models import DispatchRequest
    import dispatch_solver as ds
    import pyvrp_candidate as pv
    from importlib.metadata import version
    base=HERE/'results'/'P02-frozen-late-VIP'
    out=HERE/'results'/'P02-production-two-cpu'
    out.mkdir(exist_ok=True)
    raw=json.loads((base/'request.json').read_text())
    raw['config'].pop('time_limit_sec',None)
    request=DispatchRequest.model_validate(raw)
    (out/'request.json').write_text(request.model_dump_json(indent=2))
    metadata=dict(source_sha='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b',
        input_source='P02-frozen-late-VIP/request.json; only time_limit_sec removed for native auto',
        affinity=sorted(os.sched_getaffinity(0)),parallel=True,pyvrp_seed=1,
        pyvrp_cpu_gate=pv.status(),pyvrp_min_cpus_override=False,
        python=platform.python_version(),ortools=version('ortools'),pyvrp=version('pyvrp'),
        native_primary_sec=ds.auto_time_limit(len(request.stops)),
        production_access=False,synthetic=True,estimated_haversine=True)
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
    original=ds.resolve_matrix
    def captured(*args,**kwargs):
        mx=original(*args,**kwargs)
        payload=dict(node_ids=['DEPOT']+[s.stop_id for s in request.stops],coords=args[0],
                     distance_m=mx.distance_m,duration_s=mx.duration_s,
                     quality=mx.quality,provider=mx.provider_name)
        (out/'matrix-used.json').write_text(json.dumps(payload,separators=(',',':')))
        return mx
    ds.resolve_matrix=captured
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    start=time.perf_counter()
    response=ds.optimize_dispatch(request)
    elapsed=time.perf_counter()-start
    (out/'response.json').write_text(response.model_dump_json(indent=2))
    sc=next(s for s in response.scenarios if s.name=='RECOMMENDED')
    report=dict(**metadata,wall_sec=elapsed,input_stops=len(request.stops),
        input_cases=sum(s.demand_cases for s in request.stops),
        frozen_cases=sum(t.cases for truck in request.trucks for t in truck.frozen_trips),
        served_cases=sc.total_cases,unserved=[s.model_dump() for s in sc.unserved],
        trucks=sc.trucks_used,loads=sc.trips,operating_cost=sc.operating_cost,
        primary_time_limit_sec=sc.time_limit_sec,
        search=response.search.model_dump() if response.search else None,
        feasibility=sc.feasibility.model_dump() if sc.feasibility else None,
        warnings=response.warnings+sc.warnings)
    (out/'summary.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
