# Actual pipeline simulation findings

Pinned current source: `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b`.
All raw orders and masters are synthetic. No production, historical customer
orders, real database, browser upload or road-network service was accessed.

## Results

| Simulation | Uploaded | Delivered | Outcome |
|---|---:|---:|---|
| P01 normal day | 360 invoices / 720 SKU lines / 6,822 cases | All | 120 stops, 4 trucks, 10 loads; 214.17 km; 178.892 OMR; 49.98 s process wall time |
| P01 repeat upload | Same 720 raw rows | Zero new rows | Every row correctly identified as an already-confirmed duplicate |
| P02 frozen-load + late VIP | 361 invoices / 6,862 cases | 358 invoices / 6,808 cases | VIP served, frozen load unchanged; 3 invoices / 54 cases avoidably left out |
| P03 200-case rental request | 200 cases | All | With small+big hire options: 110 OMR; with small option only: 30 OMR, same raw order |
| P04 six-item SKU packing | 6 cases / 20 kg | 5 cases | Current builder creates 3 visits; valid 2-visit regrouping serves all 6 |
| P05 heavy case + prospective rental | 1 case / 120 kg | Zero | Builder pre-drops against own 100-kg payload, overlooking prospective 200-kg rental; rental available before building serves the case |

P01 and P02 request 20 seconds of primary search, exactly the current automatic
limit for their 120 and 108 open stops. Total process time includes other stages.
The tests use a single CPU, explicit PyVRP enabling below its production CPU gate,
and in-process main search; they are not production latency measurements.

Actual RouteIQ reconciliation passes for P01–P05, including every uploaded case,
SKU, invoice and split order line. A separately implemented checker also passes
raw-to-confirmed, builder portion accounting, solver allocation and persistence
accounting for these five scenarios. P02's frozen load and assignments are equal
to their saved baseline. Good accounting and feasible outputs do not guarantee
that every feasible delivery is found or the cheapest plan is selected.

## P02: new avoidable-service failure

At 11:00 local the normal day's first load is frozen (721 cases). A priority-one
40-case late order is added. The real builder sends 108 remaining stops; the
solver serves the VIP but leaves customer C3, 54 cases across three invoices,
unserved after exact loading-time repair. It leaves trucks T2 and T3 unused.

The original request gives C3 a 08:00–17:00 receiving window, nine minutes of
service, 0.534 pallet demand and no truck restriction. The same actual solver
routes C3 on unused T2, leaving at 11:21 and returning at 12:04, at 26.328 OMR.
Adding that trip to the unchanged nine returned loads produces full service:

- Original new-work cases: 6,087; plus frozen 721 = 6,808 delivered.
- Witness new-work cases: 6,141; plus frozen 721 = all 6,862 delivered.
- Original new-work operating cost: 191.248 OMR.
- Full-service witness new-work operating cost: 217.576 OMR.

This is a service improvement under the configured service-first objective,
despite the additional operating cost. It is not a lower-cost or globally
optimality claim. Frozen work and every existing returned load remain unchanged.

The independent checker passes 1,513 checks for the combined response, including
exact case coverage, pallet capacity, compatible second-level timing, receiving
windows, loading times, breaks, frozen reservations and operating costs.
Its timing proof uses the documented rounded-output contract; see its report's
limitations. The combined output is explicitly marked as a constructed witness,
not falsely attributed to a full-day RouteIQ solve.

An additional run with `time_limit_sec` removed used native automatic 20 seconds
and returned the identical missed C3, quantities, cost and load count; wall time
57.49 seconds. The shortfall is therefore not explained by our supplying a
smaller-than-native primary budget. Source inspection also identifies a repair
gap: singleton candidates are added for raw-unserved stops; a raw-served stop
subsequently removed by exact timing can miss that candidate pool.

**Production worker-mode confirmation:** a further isolated replay used two
reserved CPUs (4 and 6), `SOLVER_PARALLEL=1`, native automatic 20 seconds, default
overall budget and the unchanged default PyVRP minimum-CPU threshold of two.
Telemetry confirms the gate enabled PyVRP without override and PyVRP was chosen.
It reproduced the same C3 shortfall, 6,087 new cases plus 721 frozen cases,
191.248 OMR, six trucks and nine new loads in 30.626 seconds wall time.
The captured actual matrix and complete telemetry are in
`results/P02-production-two-cpu/`.

The native worker output passes 1,493 independent checks. A new full-service
witness preserving that run's nine loads exactly and adding the validated T2
trip passes **1,527 independent checks against the captured actual matrix**.
It serves every case for the same 217.576 OMR new-work operating cost.
This confirmation removes reliance on the one-CPU diagnostic override for the
P02 finding. It does not establish how frequently this occurs in real data.

Suggested fix: bounded reinsertion of newly dropped stops after exact timing,
including unused trucks, then run exact validation and service-first comparison
again. Preserve all mandatory constraints. Add this exact input as a regression
case and verify service does not worsen or frozen work change.

## Test result interpretation

Three small reproduction tests pass because they assert the unresolved P03–P05
behavior. The combined normal-day/replan test reaches its all-delivered P02
acceptance assertion and fails on the observed 54-case shortfall. Its P01,
duplicate-skip, frozen-preservation and reconciliation checks pass before that.
Do not describe this as four successful business scenarios or hide the failure.

The small pathological examples establish existence, not incident frequency.
Only a real historical-data replay and supervised pilot can estimate frequency,
operational timing accuracy and financial impact at NMWC.
