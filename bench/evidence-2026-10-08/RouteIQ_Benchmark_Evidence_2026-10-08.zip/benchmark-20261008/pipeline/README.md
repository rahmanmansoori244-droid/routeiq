# RouteIQ raw-order pipeline simulation

Source under test: `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b` (8 October 2026 review).

These are synthetic service integration simulations. They execute RouteIQ's actual
`validateIntake`, `confirmIntake`, `buildDispatchRequest`, Python `optimize_dispatch`,
`persistDispatchResult`, `applyScenario`, and `refreshPlanFacts` functions. The solver
is not mocked. No source or production data is modified.

The database is the repository's `tests/lib/fake-plan-db.ts`, with two explicit
adapter extensions: expand nested unserved rows and cascade assignment removal
when a load is removed. Order/product relation hydration is supplied in memory.
This is **not PostgreSQL**, does not validate transaction isolation, foreign-key
constraints, tenant-filter semantics, or locking. Raw input starts at parsed ERP
row dictionaries; it does not test the CSV/XLSX parser or browser upload handler.
Audit persistence is mocked. The frozen-load step directly exercises builder and
application services on the same run; it does not exercise creation/supersession
of a new plan version or HTTP authorization.

## Execute

Use a checkout of the pinned source with its web dependencies and Prisma client
generated, and a Python environment matching `apps/solver/requirements.txt`.
Make the checkout's web `node_modules` resolvable from this directory (a symlink
works), then set:

```bash
export ROUTEIQ_SOURCE=/absolute/path/to/routeiq
export ROUTEIQ_PYTHON=/absolute/path/to/solver-venv/bin/python
export ROUTEIQ_CPU=7
node /absolute/path/to/web/node_modules/vitest/vitest.mjs run --config vitest.config.ts
```

Results default to this directory's `results/`. The solver runs in a separate
process per request, with a single CPU where that affinity is available,
`SOLVER_PARALLEL=0`, `SOLVER_PYVRP=on`, and `SOLVER_PYVRP_MIN_CPUS=1`. The last setting
deliberately enables the second engine on the constrained benchmark CPU; it is
not the production default. Search reports record whether PyVRP actually ran.
Small tests request 2 seconds and the 120-customer day requests 20 seconds for
the primary search; wall time includes additional stages and process startup.
These wall times are not production latency benchmarks.

### Production worker-mode follow-up

P02 was also replayed independently after reserving **CPUs 4 and 6**, using
normal process workers, native automatic search time, the default overall
solver budget, and the **unchanged PyVRP minimum-CPU gate of two**. The override
used by the earlier one-CPU diagnostic was explicitly removed. Its metadata
records `effective_cpus=2`, `min_cpus=2`, `enabled=true` and actual PyVRP `CHOSEN`.

```bash
ROUTEIQ_TWO_CPUS=4,6 "$ROUTEIQ_PYTHON" run_production_two_cpu.py
"$ROUTEIQ_PYTHON" build_unused_truck_witness.py \
  --base P02-production-two-cpu \
  --output P02-production-full-service-witness --reuse-repair
```

The replay uses the saved original P02 input with only the explicit primary
time limit removed. Automatic timing selects the same 20 seconds. It again
misses the same 54 cases; its actual road matrix is captured in `matrix-used.json`.
The current-run full-service witness preserves all nine returned loads and adds
the separately solved T2 trip. Both output and witness pass independent checking
against that captured matrix. This resolves the earlier CPU-gate/worker-mode
limitation for the P02 finding; it remains an isolated synthetic simulation.

Every route uses estimated Haversine distances; there is no live OSRM or traffic
input. Coordinates describe a synthetic compact Muscat-area delivery day and
are not real customer locations. Service times, pallet factors and costs are
invented plausible test inputs, not an assertion about current NMWC settings.

## Scenarios and interpretation

- **P01:** 360 invoices, 720 SKU lines, 120 customer branches, 6,822 cases;
  mixed pallet factors, two truck sizes, priority levels, receiving windows,
  reload/handling time and required breaks. Reconciliation is checked by invoice,
  SKU and line after actual persistence-service execution. Repeating those raw
  rows is checked for duplicate rejection.
- **P02:** freeze one load, add a 40-case priority-one late invoice, rebuild from
  11:00 local, run optimizer and apply plan. Frozen load and assignment records
  must remain identical, and all original plus new invoices must reconcile.
  **Observed acceptance failure:** three invoices (one customer / 54 cases)
  remain unserved despite an unused truck that can deliver them. An independent
  full-service witness preserves all returned loads and adds a valid singleton
  trip on that unused truck. The same miss recurs with the native automatic
  search budget. See `RESULTS.md`.
- **P03:** 200-case order with own 100-case truck; cheap 100-case hire and more
  expensive 200-case hire. Both-options builder and small-only builder are
  actually executed. This intentionally reproduces the 110-versus-30 OMR
  avoidable-cost example. A passing test means the limitation reproduced,
  **not** that the current result is optimal.
- **P04:** six one-case SKU lines with weights 6, 5, 3, 2, 2, 2 kg, two 10-kg
  trucks and a tight receiving window. Current actual packing requires three
  visits and leaves a case out. A separately constructed feasible witness groups
  the same items into `[6,2,2]` and `[5,3,2]`, needing two visits. The witness is
  solved but not persisted or claimed to be a request-builder output.
- **P05:** one 120-kg case; own truck payload 100 kg, prospective rental 200 kg.
  The current builder filters the order against the own fleet. Adding that
  capable rental to the available fleet before building supplies a feasible
  witness. This path is relevant only when kg payload constraints are enabled.

The small constructed counterexamples establish existence, not frequency in
real dispatch data. Cases P03–P05 are regression reproductions of unresolved
limitations, so do not report the Vitest pass count as successful acceptance
of their business outcomes.

`pipeline.spec.ts` intentionally retains the P02 all-service acceptance
assertion. It currently fails, because the separately validated witness proves
all service is feasible. The frozen preservation and reconciliation assertions
before that assertion pass. Run `build_unused_truck_witness.py` with the same
Python environment after the pipeline to independently reconstruct the witness.

Saved files include original raw rows, resolved/confirmed order-line lineage,
request-building scope and pre-drops, actual solver request/response, service
persistence output and metrics. `run.log` is the final execution log. The
`initial-harness-run.log` documents a corrected adapter relation-hydration error
and a first run where the production CPU gate skipped PyVRP.
`counterexample-tests-and-harness-correction.log` contains the three completed
counterexample tests plus a corrected test expectation: repeated invoice rows
are benign `duplicates[]`, not `errors[]`. Those initial harness errors are not
product failures. Their overwritten route outputs are not final measurements.
The normal day's aggregates varied between harness-development reruns, although
all invoices were served each time. These are not controlled on/off comparisons;
use the separate large-day suite for those comparisons.
