import { defineConfig } from 'vitest/config';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const source=process.env.ROUTEIQ_SOURCE??'/workspace/scratch/918a93981356/routeiq-20261008';
export default defineConfig({root,esbuild:{jsx:'automatic'},test:{environment:'node',include:['pipeline.spec.ts'],setupFiles:[resolve(source,'apps/web/tests/setup.ts')],pool:'forks',poolOptions:{forks:{singleFork:true}},testTimeout:420000},resolve:{alias:{'@':resolve(source,'apps/web')}}});
