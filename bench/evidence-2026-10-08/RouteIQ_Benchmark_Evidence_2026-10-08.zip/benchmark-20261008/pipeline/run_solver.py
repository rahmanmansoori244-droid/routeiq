"""Actual RouteIQ optimizer process. Single CPU, no HTTP or production services."""
import os, sys, json, time
os.environ.update(SOLVER_PARALLEL='0', SOLVER_PYVRP='on', SOLVER_PYVRP_MIN_CPUS='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
cpu=int(os.environ.get('ROUTEIQ_CPU','7'))
if hasattr(os,'sched_getaffinity') and cpu in os.sched_getaffinity(0): os.sched_setaffinity(0,{cpu})
repo=os.environ.get('ROUTEIQ_SOURCE','/workspace/scratch/918a93981356/routeiq-20261008')
sys.path.insert(0,os.path.join(repo,'apps','solver'))
from dispatch_models import DispatchRequest
from dispatch_solver import optimize_dispatch
source, target = sys.argv[1:3]
request=DispatchRequest.model_validate(json.load(open(source)))
start=time.perf_counter()
answer=optimize_dispatch(request)
elapsed=time.perf_counter()-start
with open(target,'w') as out: json.dump(answer.model_dump(mode='json'),out,indent=2)
print(json.dumps({'wall_sec':elapsed,'scenarios':len(answer.scenarios)}))
