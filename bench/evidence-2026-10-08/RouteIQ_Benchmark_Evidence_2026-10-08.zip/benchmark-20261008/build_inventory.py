"""Catalog preserved experiments without rerunning models or counting checkers.

Run from any directory. Relative paths are rooted at this file's directory.
Regenerate once all runners and report/evidence writers have finished.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
SHA='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b'
EXCLUDE_DIRS={'qa','node_modules','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.git','.venv','venv'}
EXCLUDE_SUFFIXES={'.zip','.pyc','.pyo','.tar','.gz','.tgz','.7z'}

def read(path):
    try:return json.loads(path.read_text())
    except (FileNotFoundError,json.JSONDecodeError,OSError):return None

def rel(path):return path.relative_to(HERE).as_posix()

def existing(path):return rel(path) if path.is_file() else None

def formal_record(group,run_id,folder,*,response='response.json',summary='summary.json',kind='dispatch_invocation',request='request.json',require_summary=False):
    response_path=folder/response;summary_path=folder/summary
    data=read(response_path);metrics=read(summary_path)
    complete=data is not None and (not require_summary or metrics is not None)
    record=dict(group=group,run_id=run_id,kind=kind,formal=True,
        status='completed_artifact' if complete else 'pending_or_incomplete',
        response=existing(response_path),request=existing(folder/request),summary=existing(summary_path),
        metadata=existing(folder/'metadata.json'),matrix=existing(folder/'matrix-used.json') or existing(folder/'matrix.json'))
    if isinstance(data,dict) and 'scenarios' in data:
        search=data.get('search') or {}
        record['routing_search_ran']=search.get('stop_reason')!='NOT_SEARCHED' if search else None
        record['scenario_statuses']=[s.get('status') for s in data['scenarios']]
        record['product_feasibility']=[(s.get('feasibility') or {}).get('status') for s in data['scenarios']]
        record['search_stop_reason']=search.get('stop_reason')
    if isinstance(metrics,dict) and 'evaluation' in metrics:
        record['adapter_evaluation_valid']=metrics['evaluation'].get('valid')
        record['search_budget_sec']=metrics.get('search_budget_s')
        if metrics.get('search_budget_s')!=60:
            record['status']='nonformal_budget_mismatch'
    return record

def inventory():
    records=[]
    days=['D1_normal','D2_wholesale_surge','D3_tight_receiving','D4_fleet_shortage','D5_late_frozen']
    for day in days:
        for seed in (17,29):
            for mode in ('off','on'):
                label=f'{mode}-seed{seed}'
                records.append(formal_record('large_primary',f'{day}/{label}',HERE/'large'/day/label))
    for family in ['cases','pallets','weights','windows','priority','multitrip','rentals']:
        for k in range(1,5):
            label=f'{family}-{k:02d}'
            records.append(formal_record('exact_reference',label,HERE/'exact'/label,summary='result.json'))
    for label in ['packing-ffd','packing-optimal','rental-whole','rental-split']:
        records.append(formal_record('formulation_reference',label,HERE/'exact/formulation'/label,summary='result.json'))
    jobs=[]
    for seed in (17,29):
        for instance in ['X-n101-k25','X-n125-k30','X-n200-k36']:
            for engine in ['hybrid','pyvrp']:jobs.append((instance,engine,seed))
    for instance in ['R108','RC201']:
        for engine in ['hybrid','pyvrp']:jobs.append((instance,engine,17))
    for instance in ['X-n101-k25','X-n125-k30','X-n200-k36']:jobs.append((instance,'ortools',17))
    for instance,engine,seed in jobs:
        label=f'{instance}.{engine}.s{seed}'
        row=formal_record('public_benchmark',label,HERE/'public/runs',response=label+'.response.json',summary=label+'.summary.json',
            request=label+'.request.json',kind='standalone_pyvrp' if engine=='pyvrp' else 'dispatch_invocation',require_summary=True)
        row['instance']=instance;row['engine']=engine;row['seed']=seed
        # Shared adapter input and raw public instance are intentionally separate.
        row['request']=existing(HERE/'public/inputs'/f'{instance}.request.json')
        row['matrix']=existing(HERE/'public/inputs'/f'{instance}.matrix.json')
        row['adapter_metadata']=existing(HERE/'public/inputs'/f'{instance}.meta.json')
        row['reference_validation']=existing(HERE/'public/inputs'/f'{instance}.bks-validation.json')
        row['provenance_manifest']='public/instances/source-manifest.json'
        records.append(row)
    for label in ['quick','thorough']:
        records.append(formal_record('native_search_modes',label,HERE/'search-modes'/label))

    # Nonformal runs are explicit separate groups; no checker count enters here.
    for response in sorted((HERE/'large').glob('*/*/response.json')):
        folder=response.parent;label=folder.name
        if re.fullmatch(r'(on|off)-seed(17|29)',label):continue
        if label=='greedy-baseline':
            group,kind='greedy_baselines','independent_greedy_algorithm'
        else:
            group,kind='large_native_followups','dispatch_invocation'
        row=formal_record(group,f'{folder.parent.name}/{label}',folder,kind=kind)
        row['formal']=False;records.append(row)
    pipeline_core={'P01-360-invoices','P02-frozen-late-VIP','P03-small-and-big-hire','P04-ffd-packing','P05-heavy-rental-filter'}
    constructed={'P02-full-service-witness','P02-production-full-service-witness'}
    for response in sorted((HERE/'pipeline/results').glob('*/response.json')):
        folder=response.parent;label=folder.name
        if label in constructed:
            group,kind='constructed_witness_answers','constructed_composite_answer'
        elif label in pipeline_core:
            group,kind='pipeline_primary','dispatch_invocation'
        elif label in {'P03-small-only-hire','P04-valid-two-visit-witness','P05-rental-in-fleet-witness','P02-unused-truck-repair'}:
            group,kind='pipeline_solved_counterexamples','dispatch_invocation'
        else:
            group,kind='pipeline_native_followups','dispatch_invocation'
        row=formal_record(group,label,folder,kind=kind,summary='metrics.json' if label in pipeline_core else 'summary.json')
        row['formal']=False
        if kind=='constructed_composite_answer':
            row['routing_search_ran']=False
            row['construction']=existing(folder/'construction.json')
        records.append(row)
    diagnostic=HERE/'diagnostics/d3-penalty'
    for label in ['stock','raised']:
        data=read(diagnostic/f'{label}-candidate.json')
        if data is not None:
            records.append(dict(group='penalty_component_trials',run_id=f'D3/{label}',kind='component_pyvrp_trial',formal=False,
                status='completed_artifact',response=rel(diagnostic/f'{label}-candidate.json'),request=existing(diagnostic/'request.json'),
                stock_configuration=label=='stock',note='Direct candidate-engine trial; not a full optimize_dispatch invocation.'))
    if read(diagnostic/'response.json') is not None:
        records.append(dict(group='penalty_stage_diagnostic',run_id='D3/raised-candidate-stage',kind='postprocessing_stage_only',formal=False,
            status='completed_artifact',response=rel(diagnostic/'response.json'),request=existing(diagnostic/'request.json'),
            note='Actual timing/repack stage applied to saved modified-penalty candidate; not a stock full-pipeline run.'))
    public_diagnostic=HERE/'public/diagnostics'
    for case,prefix,request,matrix in [
        ('X-n101-k25','penalty',HERE/'public/inputs/X-n101-k25.request.json',HERE/'public/inputs/X-n101-k25.matrix.json'),
        ('tiny-own-fleet','tiny-own-case',public_diagnostic/'tiny-own-case.request.json',public_diagnostic/'tiny-own-case.matrix.json')
    ]:
        for mode in ['stock','raised_ceiling_diagnostic']:
            path=public_diagnostic/f'{prefix}-{mode}.json';data=read(path)
            if data is not None:
                records.append(dict(group='public_penalty_component_trials',run_id=f'{case}/{mode}',kind='component_pyvrp_trial',formal=False,
                    status='completed_artifact',response=rel(path),request=existing(request),matrix=existing(matrix),
                    stock_configuration=mode=='stock',candidate_feasible=(data.get('result') or {}).get('feasible'),
                    note='Direct embedded PyVRP candidate-engine diagnostic, not a formal public comparison or full dispatch invocation; modified penalty configuration is separately labelled.'))
    groups=defaultdict(Counter)
    for row in records:
        groups[row['group']]['planned_or_observed_records']+=1
        groups[row['group']][row['status']]+=1
    formal=[r for r in records if r['formal']]
    completed=[r for r in formal if r['status']=='completed_artifact']
    invocation_counts=Counter(r['kind'] for r in records if r['status']=='completed_artifact')
    excluded_debug=[rel(p) for p in sorted((HERE/'public').glob('adapter-debug*')) if p.is_dir()]
    source_verification=read(HERE/'source-verification.json')
    return dict(schema_version=1,generated_at_utc=datetime.now(timezone.utc).isoformat(),review_date_local='2026-10-08',
        source_sha=SHA,source_verification='source-verification.json' if source_verification is not None else None,
        source_files_verified=source_verification.get('matched_files') if isinstance(source_verification,dict) else None,
        source_files_tracked=source_verification.get('tracked_files') if isinstance(source_verification,dict) else None,
        source_git_tree=source_verification.get('git_tree_sha') if isinstance(source_verification,dict) else None,
        expected_formal_runs=73,formal_completed=len(completed),formal_pending=[r['run_id'] for r in formal if r['status']!='completed_artifact'],
        formal_schedule=dict(large_primary=20,exact_reference=28,formulation_reference=4,public_benchmark=19,native_search_modes=2),
        formal_completed_by_kind=dict(Counter(r['kind'] for r in completed)),all_captured_records_by_kind=dict(invocation_counts),
        counts_by_group={k:dict(v) for k,v in sorted(groups.items())},runs=records,
        count_rules=[
            'A formal run is one saved top-level experiment at its stated boundary; internal searches/repack phases are not additional formal runs.',
            'Completed means a saved response, not a valid route or a passed acceptance criterion. Read independent validation and lane results.',
            'The primary formal schedule totals73:20large+28exact+4formulation+19public+2native search modes.',
            'Original manifest suite_plan mentioned24exact; actual executed suite expanded to28, all retained.',
            'Pipeline invocations, native failure replays, solved counterexamples, constructed witnesses, greedy baselines and modified diagnostics are separate.',
            'Pipeline P05-heavy-rental-filter invokes optimize_dispatch but returns NOT_SEARCHED; do not describe it as a routing search.',
            'Checker reports, mutation checks, oracle enumerations and constructed composite answers are not solver model invocations.',
            'Adapter-development/debug runs and overwritten initial harness attempts are excluded; no claim to count all exploratory executions.'
        ],excluded_public_debug_directories=excluded_debug,
        checksum_notes='SHA256SUMS covers regular handoff files including this inventory, final report, inputs, results, scripts and notes. Excludes qa directories (including report/qa), archives, transfer folders, dependencies, caches, symlinks and SHA256SUMS itself. Refresh after final writers finish.')

def files_for_hash():
    for root,dirs,files in os.walk(HERE,followlinks=False):
        root=Path(root)
        dirs[:]=sorted(d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.library-transfer') and not (root/d).is_symlink())
        for name in sorted(files):
            p=root/name
            if p.is_symlink() or not p.is_file():continue
            if name=='SHA256SUMS' or p.suffix.lower() in EXCLUDE_SUFFIXES:continue
            if name.startswith('.library-transfer'):continue
            yield p

def main():
    p=argparse.ArgumentParser();p.add_argument('--require-complete',action='store_true');a=p.parse_args()
    result=inventory()
    (HERE/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=[]
    for path in sorted(files_for_hash()):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f'{digest}  {rel(path)}')
    (HERE/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(formal_completed=result['formal_completed'],formal_expected=result['expected_formal_runs'],
        formal_pending=result['formal_pending'],counts_by_group=result['counts_by_group'],checksummed_files=len(lines)),indent=2))
    if a.require_complete and result['formal_completed']!=result['expected_formal_runs']:
        raise SystemExit('Formal series incomplete; preserved partial inventory and checksums. Refresh after runners finish.')

if __name__=='__main__':main()
