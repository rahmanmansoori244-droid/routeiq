"""Package the finalized evidence after inventory/checksum refresh; no model runs."""
from pathlib import Path
import argparse, hashlib, json, zipfile
import build_inventory

HERE=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',default=str(HERE.parent/'RouteIQ_Benchmark_Evidence_2026-10-08.zip'))
    args=parser.parse_args()
    inventory=json.loads((HERE/'inventory.json').read_text())
    if inventory['formal_completed']!=73 or inventory['formal_pending']:
        raise SystemExit('Formal benchmark schedule is incomplete.')
    paths=[]
    for line in (HERE/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        path=HERE/name
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise SystemExit(f'File changed after inventory refresh: {name}')
        paths.append(path)
    paths.append(HERE/'SHA256SUMS')
    out=Path(args.out)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for path in sorted(paths):
            z.write(path,arcname='benchmark-20261008/'+path.relative_to(HERE).as_posix())
    with zipfile.ZipFile(out) as z:
        bad=z.testzip()
        if bad: raise SystemExit(f'Corrupt ZIP member: {bad}')
        names=z.namelist()
        assert not any('/node_modules/' in n or '/.library-transfer' in n or '/report/qa/' in n for n in names)
        assert 'benchmark-20261008/report/output/RouteIQ_Benchmark_Report_2026-10-08.pdf' in names
    print(json.dumps({'zip':str(out),'files':len(paths),'bytes':out.stat().st_size,
                      'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'crc_check':'PASS'}))

if __name__=='__main__':main()
