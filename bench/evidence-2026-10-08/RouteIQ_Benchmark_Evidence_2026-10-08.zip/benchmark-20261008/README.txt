ROUTEIQ — EXECUTED SIMULATION AND BENCHMARK EVIDENCE
Review date: 8 October 2026, Asia/Dubai
Pinned source: 5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b
Repository: https://github.com/rahmanmansoori244-droid/routeiq

PURPOSE AND BOUNDARY

This bundle preserves actual solver executions, raw inputs and outputs,
independently implemented checks, exact tiny-problem references, public routing
comparisons, and simulations of selected web application services. Read the
report and findings register for conclusions; a saved answer or a passing test
that reproduces a defect is not a successful operational acceptance result.

No production service/database was accessed or changed. No real customer data
or production credentials are needed. Business scenarios are fictional and use
estimated Haversine travel; public instances use their prescribed published
distance matrices. This is not validation of live Oman road restrictions,
traffic, real receiving times, warehouse practice or mobile-phone behavior.
The production source remained unchanged. source-verification.json records
verification of all833 tracked Git blobs against the pinned source tree.

The supplied data is ready for the PROGRAMMATIC BENCHMARK HARNESSES. JSON invoice
fixtures and DispatchRequest objects are not necessarily accepted by the app's
CSV/XLSX upload screen. Pipeline intake starts with parsed ERP row dictionaries;
it does not prove parser/browser-upload behavior. A separate conversion to the
current template and an actual upload rehearsal are needed for UI testing.

WHAT WAS COUNTED

The fixed formal schedule has73 top-level experiments:
  large/           20 runs: five320–420-invoice days, hybridON/OFF, two repeats.
  exact/           28 small exhaustive-reference problems, actual solver calls.
  exact/formulation/ 4 paired packing/splitting reference calls.
  public/          19 comparisons on five public instances, including standalone
                      PyVRP and RouteIQ hybrid/OR-Tools-only modes.
  search-modes/     2 native-budget QUICK/THOROUGH runs on a360-invoice day.

inventory.json records the actually completed schedule and any pending files.
The initial manifest's planned24 exact cases expanded to28; none was discarded.
Other preserved evidence is counted separately: raw-order pipeline invocations,
native-budget failure replays, solved counterexamples, direct penalty-diagnostic
component trials, stage-only experiments, greedy baselines and constructed
full-service witnesses. Internal route searches and repacks within one request
are not additional formal runs. Validation/checker outputs, mutations and oracle
enumerations are not model calls. Pipeline P05 invokes the optimizer but returns
NOT_SEARCHED after its builder excludes the order. Composite witness answers
reuse solved loads and are not fresh full optimizer executions.

The inventory intentionally excludes discarded adapter-development and overwritten
initial harness attempts from result counts. Their retained logs are explicitly
labelled in the relevant lane README. Do not total every response/check JSON and
describe that number as independent production tests.

The penalty diagnostics are also separated by origin: two D3 component trials,
four public-lane component trials (stock/raised on X-n101-k25 and a tiny own-fleet
case), and one D3 postprocessing-stage execution. Native D3 and D5 follow-ups are
discovered under large_native_followups as their saved responses become available.

REPRODUCE THE ENVIRONMENT

Use Linux (or WSL) and Python3.12 for the recorded process-affinity behavior.
Choose a writable directory and keep this evidence bundle outside the checkout.
Commands below assume the extracted bundle is named benchmark-20261008:

  git clone https://github.com/rahmanmansoori244-droid/routeiq.git routeiq
  git -C routeiq checkout --detach 5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b
  export ROUTEIQ_REPO="$(pwd)/routeiq"
  export ROUTEIQ_BENCH="$(pwd)/benchmark-20261008"
  python3.12 -m venv routeiq-benchmark-venv
  . routeiq-benchmark-venv/bin/activate
  python -m pip install -r "$ROUTEIQ_REPO/apps/solver/requirements.txt" vrplib==2.2.0 \
    -c "$ROUTEIQ_BENCH/python-packages.txt"

The constraint file records the executed environment (including OR-Tools9.15.6755,
PyVRP0.14.0 and vrplib2.2.0). It pins transitive versions that the repository's
ranged requirements otherwise allow to change. Package availability and CPU
platform can affect installation. The repository requirements remain the primary
dependency specification; python-packages.txt records this benchmark environment.
No .env, API tokens, database URL, server startup or live OSRM endpoint is needed
for the Python evidence lanes.

IMPORTANT SOURCE-PATH DIFFERENCE

Most lanes use ROUTEIQ_SOURCE as the REPOSITORY ROOT:
  export ROUTEIQ_SOURCE="$ROUTEIQ_REPO"

The public lane's environment override instead expects apps/solver:
  ROUTEIQ_SOURCE="$ROUTEIQ_REPO/apps/solver" python public/run_batch.py

For individual public runs, --repo "$ROUTEIQ_REPO" accepts the repository root
and avoids that difference. Exact and native search-mode scripts also accept
--repo. Lane READMEs are authoritative for their arguments and settings.

CPU AFFINITY AND RUNTIME

Recorded allocations were large CPUs0–3, public CPU5, exact CPU4, pipeline CPU7,
and the native QUICK/THOROUGH pair CPUs4,6,8. Follow-up allocations are recorded
with their own metadata. These are permitted CPU IDs on this particular host,
not portable requirements; adjust to the CPUs your environment allows.
Do not launch overlapping CPU-heavy lanes and treat the times as uncontended.
Even separated affinities shared one host and its8CPU quota. Wall times are
observations, not production SLAs. Time-limited stochastic runs can return
different valid answers on another machine despite the same seed.

LANE COMMANDS AND LIMITS

Run lanes separately, reading each README first. Preserve the supplied answers
before rerunning: some scripts overwrite outputs; the large suite instead refuses
to overwrite completed production responses. Use a separate copy/output folder
with the required inputs and scripts for a fresh experiment.

Large operating days (see large/README.txt):
  cd "$ROUTEIQ_BENCH/large"
  python generate_days.py
  python run_all.py
  python greedy_baseline.py
  python summarize.py
  python run_native_followups.py
The primary series uses60s search/240s request budgets, not production defaults.
Native D3 replay uses automatic QUICK and540s. Its controller may run both modes
depending on whether the first provides a verified answer. Never edit the saved
product output to repair an infeasible answer; retain a witness separately.

Exact references (see exact/README.md):
  python "$ROUTEIQ_BENCH/exact/run_exact_suite.py" --repo "$ROUTEIQ_REPO" --cpu 4
  python "$ROUTEIQ_BENCH/exact/run_formulation_references.py" --repo "$ROUTEIQ_REPO" --cpu 4
The proofs apply only to their explicit small fixed-stop models. The formulation
references separately show how changing allowed portions changes what is feasible.

Public comparisons (see public/README.md):
  cd "$ROUTEIQ_BENCH/public"
  BENCH_CPU=5 ROUTEIQ_SOURCE="$ROUTEIQ_REPO/apps/solver" python run_batch.py
  python summarize_public.py
Keep the supplied instances/ directory with the runner. Published files and BKS
routes have their own Git-blob/SHA provenance. BKS gaps are not automatically
optimality gaps. Adapter semantics, geometric projection, CPU sharing and integer
scaling limitations are explicitly documented in this lane.

Native search budgets (see search-modes/README.md):
  python "$ROUTEIQ_BENCH/search-modes/run_pair.py" --repo "$ROUTEIQ_REPO" --cpus 4,6,8
This retains RECOMMENDED-only scenarios, native automatic QUICK timing and the
native1200s THOROUGH cap/stall rules. More time is not a global-optimality proof;
compare service tiers and full cost including preferences, not cash alone.

Pipeline service simulation (see pipeline/README.md):
Use the checkout's documented web dependency installation and Prisma generation
workflow. Make its web node_modules resolvable from the pipeline directory, set
ROUTEIQ_SOURCE to the repository root and ROUTEIQ_PYTHON to the absolute Python
interpreter path, then run its Vitest config as documented. The simulation uses
actual application services with an in-memory test database, not PostgreSQL or
HTTP/browser integration. Its P02 all-service acceptance assertion intentionally
fails to retain the reproduced defect. Counterexample tests can pass by correctly
reproducing a faulty business outcome. Do not equate their pass count with launch
readiness. Production worker-mode follow-ups and witness reconstruction have
separate commands in that README.
If overriding ROUTEIQ_PIPELINE_OUT, copy run_solver.py into that same output
directory as the harness expects; the default pipeline directory already has it.

Diagnostics (see diagnostics/d3-penalty/README.md):
Direct candidate-engine penalty trials and their subsequent exact stage are
diagnostics, including an explicitly modified in-memory configuration. They
are not stock-product fixes or observations in the formal comparison series.

INDEPENDENT VALIDATION WITHOUT RERUNNING OPTIMIZATION

After installing the Python requirements, the saved answers can be checked with:
  python "$ROUTEIQ_BENCH/validation/run_all.py"
  python "$ROUTEIQ_BENCH/validation/public_routes.py"
  python "$ROUTEIQ_BENCH/validation/pipeline_accounting.py"
  python "$ROUTEIQ_BENCH/validation/mutation_checks.py"
  python "$ROUTEIQ_BENCH/validation/aggregate.py"

Read validation/README.md for coverage and minute-rounding semantics. These
checkers import no production feasibility/accounting implementation. A PASS
establishes the stated feasibility and accounting conditions, not best possible
service, optimality, actual road travel or database-concurrency correctness.

INVENTORY AND FILE INTEGRITY

  cd "$ROUTEIQ_BENCH"
  python build_inventory.py --require-complete
  sha256sum -c SHA256SUMS

The inventory builder does not run models. It writes relative-path inventory.json
and SHA256SUMS for preserved handoff inputs, outputs, scripts, notes and the final
report. Checksums exclude qa directories (including report/qa), ZIP/other archives, .library-transfer folders,
node_modules, virtual environments, caches, symlinks and SHA256SUMS itself.
Run it only after final writers finish if preparing a final handoff. Refreshing
the inventory or any result intentionally changes checksums. Source verification
is separate: source-verification.json records the833 tracked repository files.
