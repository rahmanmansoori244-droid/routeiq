# Independent benchmark methodology review

Reviewed source SHA: 5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b. Reviewer is separate from suite authors. No production data or systems accessed. Methodology, exact oracle, public adapter, independent validator, selected witnesses and native Quick/Thorough results have been reviewed. Per-run results remain in their raw artifacts; diagnostic modifications are separate from stock rankings.

## Large-day design reviewed

- Five fictional NMWC-like cases contain 320–420 synthetic invoices and 180–230 distinct customer stops. Invoice counts must not be reported as route-stop counts. A direct stdlib aggregation check found no discrepancies in cases, kg, pallet units or invoice counts; each stop fits the pallet capacity of at least one truck.
- Inputs are generated at the DispatchRequest boundary. The invoice records and their aggregation are synthetic bookkeeping rather than an execution of actual web import, master data, database and request builder. Separate pipeline tests cover selected surrounding functions only.
- Matrices are estimated Haversine distances (multiplier 1.3) and constant average speed 35 km/h. They cannot establish road-network feasibility, traffic accuracy, Oman truck restrictions or field ETA accuracy.
- Capacity_kg=0 follows the test configuration and explicitly disables kg limits. Mixed-SKU pallet demand is enforced; vehicle physical axle, stacking, legal gross weight and product loading practicality remain untested.
- D5 contains six prior frozen-trip intervals and quantities outside the pending invoice workload. Those amounts must not be counted as newly delivered invoices/cases; frozen intervals and shift envelope must be independently checked.
- Cases contain no rental candidates. Rental findings come from separate focused scenarios; large-day quality should not be called a full fleet-hire benchmark.
- The two labels for OR-Tools-only mode are repeated runs, not independently seeded OR-Tools runs. Seeds 17/29 change PyVRP randomness only.
- On/off uses the same primary 60-second request setting, same 4-core CPU affinity and 240-second overall cap. This is an ablation of the actual pipeline. It is not equal total CPU work: second search/post-processing may add resource use. Actual wall times must accompany comparisons; matched-total-time reference runs are helpful when attributing gains.
- Objective comparisons require served-priority vectors first. Lower cost or distance after dropping more/high-priority work is not a quality gain. Equal service vectors may still serve different customers; state this rather than implying identical delivered workload.
- Shared 8-CPU-quota/8GB host uses CPU affinity to separate suites. That reduces but does not eliminate contention from quota, memory and operating system activity. Runtime is illustrative, not a production SLA.

## Public benchmark checks completed

- CVRP supplied README specifies nearest-integer distance convention.
- VRPTW supplied README specifies DIMACS truncation to one decimal, distance-only objective. This differs from other Solomon/SINTEF vehicle-count-first / full-Euclidean reference conventions; references must not be mixed.
- Standalone PyVRP is a specialized same-engine reference, since the RouteIQ hybrid itself embeds PyVRP. Its result is useful but not an independent engine comparison or proof of superiority over commercial products.

## Exact-oracle scope checks completed

- A proof is valid only for the exact supported subproblem and objective. These tiny fixed-stop cases cover selected one-/two-trip, capacity, receiving-window, strict-priority and flat-rental configurations. They do not prove every such configuration, invoice splitting, breaks/frozen work or the overall full problem globally optimal.
- All claimed optima require completeness of enumeration / matching bounds and matching cost arithmetic. A timed feasible result is not proof.

## Evidence strength

A finite synthetic suite can show reproducible correctness/quality for chosen cases and uncover counterexamples. It cannot estimate actual NMWC failure frequency, validate future unseen days, or replace dispatcher/mobile/production operational rehearsal. Preserve raw requests, responses, matrices, versions and runner scripts so another person can reproduce the measurements.

## Exact suite implementation review completed

The oracle enumerates capacity-feasible ordered loads, recursively enumerates disjoint ordered truck days (one or two trips), and combines every truck's subset choices using a complete fleet subset dynamic program. Retaining the lowest hire/cost day for each identical served subset is valid because truck days do not interact through dock, driver, inventory or other shared resources in these fixtures. Earliest departure scheduling is complete for this restricted scope: no departure-dependent prices/preferences, breaks/frozen work, and no tighter moving-shift limit than the absolute end horizon. Integer-km/minute matrices and quarter-minute case loading choices avoid hidden timing rounding mismatches. Flat-price rentals with all-P3 stops avoid the current approximate distance-based rental-tier issue.

The 28 generated tiny cases finished: all 28 independently feasible and all 28 matched the exhaustive oracle objective. Search used OR-Tools-only with 2-second primary allowance, in-process mode, and one repack worker. These are positive exact-reference results for the specified fixed-stop formulation, not a proof for all realistic inputs, the PyVRP hybrid, or the full invoice-to-plan pipeline.

Two separate formulation counterexamples enumerate original SKU partitions / case allocations. They show that a perfectly solved restricted solver request may still exclude a superior original-order plan. The rental example is optimal at 30 OMR only if the business permits two visits instead of requiring a whole order on one truck whenever possible. It is not a bug under an intentional no-split policy.

## Public adapter correction during review

Initial draft mapped published integer distance units directly to meters. That would compress whole-route operating cost and distance, triggering RouteIQ's 1 OMR / 1 km material-improvement threshold and potentially suppressing genuine public-benchmark improvements solely due to unit scaling. Reviewer flagged this before interpreting results; the final series was restarted with CVRP integer units mapped to 1000 meters and DIMACS tenths to 100 meters (one benchmark distance unit = one km). Raw published matrices remain the basis for BKS evaluation. Discard initial unscaled results from final comparisons.

## Pipeline and checker scope reviewed

The pipeline suite executes actual intake validation/confirmation, request building, optimization and persistence/application service functions over the repository's fake database adapter, augmented only for relation/cascade behavior. It is stronger than a solver-boundary test but does not establish real database locking, rollback, migrations or concurrent behavior. Its bug-reproduction tests deliberately assert currently defective behavior; a passing test runner must not be described as every business acceptance case passing.

The separately authored checker does not import product helpers. It recomputes quantities, capacities, identity, matrix distances, costs and timetable constraints using a generic CP-SAT satisfiability model. Due to integer-minute wire output, timing PASS means there exists an integer-second timetable compatible with rounded output and costs, not a reconstruction/proof of every hidden unrounded product timestamp. It reports service by priority, not optimality of priority selection. Separate pipeline-accounting checks subsequently verified raw rows through source lines, portions/pre-drops, solver responses and persisted assignments, including frozen preservation. Unsupported schemas in the generic checker remain explicitly marked and are not silently treated as verified raw data.

The first pipeline replay used an incorrect harness assertion that duplicate invoice rows should appear in errors[]. Product behavior correctly put all 720 duplicate rows into duplicates[] and accepted zero new lines. The harness was corrected; this is not a product defect. PyVRP execution must be established by response telemetry because the default minimum-CPU gate can disable it on the pipeline suite's single-core affinity; subsequent runs explicitly force that gate and disclose it.

The normal-day greedy comparator is a basic priority-first, nearest-next heuristic over the same inputs/matrix. It conservatively rounds travel up and reserves worst-case load turnaround, and its algorithm does not optimize soft preferences. The final independent checker additionally prices the soft-preference terms, allowing objective comparisons where service is equal. Therefore it provides a simple feasible baseline, not measured dispatcher performance or a competitive state-of-the-art baseline. Compare hard-rule feasibility and cash costs explicitly; do not call its losses demonstrated NMWC savings.

## Late-order full-service witness independently reviewed

Pipeline P02 used a real 108-pending-stop request built after freezing a 721-case physical load and adding a late VIP invoice. The returned plan left C3 (54 cases / three original invoices) unserved. Its 20-second primary limit equals the current automatic budget for 108 stops, and a subsequent production-worker-mode repeat on two CPUs with the normal PyVRP gate reproduced the same lost C3 stop. The database/input harness remains synthetic and differs from a live deployment.

I directly compared JSON: P02-full-service-witness/request.json is equal to the original P02 request, all nine returned original loads are unchanged, and the only addition is a real solver-generated singleton C3 route on previously unused T2, departing 11:21 and returning 12:04. The separate checker passes. Remaining-work cases rise from 6,087 to 6,141; including the external frozen 721 cases, total original invoice coverage rises from 6,808 to 6,862. Remaining-plan operating cost rises from 191.248 to 217.576 OMR, but strict service-first policy makes the full-service witness better. This proves avoidable lost service in this particular returned answer, not infeasibility of the answer or the global optimal cost of the witness.

Source review identifies a plausible contributing search limitation: load_repack.fit_pool offers each whole raw load and each raw load minus one stop, plus singleton loads only for the extra/raw-unserved stops. build_candidates supplies opt excluding every stop already served by the raw plan. A stop such as C3 that was served in raw PyVRP output and only dropped during exact timing is consequently absent as a singleton repair option. A bounded insertion/extra-load repair after timing would address this class of avoidable loss. No product source was changed and causal completeness is not claimed.

The checker also rejected all eight deliberately corrupted control outputs (including identity/reconciliation, capacity, closing, distances, cost, frozen overlap and missing break). This improves confidence in its independence; it remains scoped to declared model rules and rounded wire data.

## D3 penalty diagnostic completed

Paired 20-second, same-seed/current-model trials isolated the existing raised-penalty configuration in memory, without editing source or including diagnostic results in rankings. Stock PyVRP's default ceiling found no feasible candidate; the int64-safe raised configuration found a feasible partial candidate. Actual subsequent timing/repacking produced a VERIFIED/EXACT 184-stop answer, independently checked with raw invoice accounting. Full details and safe-bound arithmetic are in diagnostics/d3-penalty/README.md. Raising the ceiling also raises default midpoint initialization, so causality is attributed to the penalty configuration rather than the ceiling alone. The candidate model's hardening of preferred windows remains a separate restriction; it cannot serve every early-window customer in this fixture. The 185-stop independently valid greedy witness still serves one more P4 customer than this diagnostic answer.


## Final public-comparison interpretation

The published BKS route files were independently evaluated using their stated rounding and distance-only objective. Standalone PyVRP shares the engine embedded in the hybrid; it is a specialized reference, not an independent commercial competitor. Public runs use one CPU and explicitly force the hybrid minimum-CPU gate; its two searches share that CPU. Search allowance and full pipeline wall time are different measurements. RouteIQ's geographic adapter preserves published cost/time matrices exactly but its geometric neighborhood coordinates are reflected and slightly rescaled relative to standalone PyVRP, which can alter search trajectory. This does not invalidate achieved solution distances, but it precludes attributing all differences solely to algorithm quality. Initial unit-debug runs and diagnostic penalty overrides are excluded from official rankings.

R108's current 932.1 reference is a DIMACS distance-only best-known answer using ten vehicles. It must not be compared directly with an earlier SINTEF nine-vehicle/full-Euclidean vehicle-first reference. Matching a published BKS is not an optimality certificate.

## Native Quick versus Thorough completed

One additional same-input D1 pair used the automatic 150-second primary search, the actual worker path, and three-CPU affinity. Both independently valid answers serve all 220 stops / 360 invoices / 9,526 cases using the identical matrix. Quick took 164.199 seconds: 438.533 OMR cash  + 9.998 preferences  = 448.531 OMR recommendation objective. Thorough stopped naturally on convergence/stall after 426.352 seconds: 431.370 cash  + 18.274 preferences  = 449.644 objective.

Thorough reduces cash 1.63%, distance 5.15% and loads 12→11, but its true recommendation objective worsens 1.113 OMR (0.248%). This is a heuristic/postprocessing comparison between independent runs, not evidence of global convergence or a proven monotonicity contract violation. An enhancement would preserve and compare an already available feasible Quick incumbent when continuing with a longer search. One paired synthetic day on a shared host is not a general runtime/quality estimate.

## Seven principal findings registered

`findings-register.json` consolidates D3 reduced-budget invalid fallback with penalty/soft-window restrictions, P02 avoidable lost service after timing, P03 rental split-policy trade-off, P04 greedy packing limitation, P05 rental payload prefilter mismatch, F06 convergence-reporting scope and F07 severe native-budget D5 service loss. Every cited source range was read at the pinned SHA and hashed. Each finding separates observed evidence from causal inference and states proposed fixes without claiming they were implemented. D3's four controlled runs use 60-second primary limits, below the native 150-second limit; its successful native replay is distinct evidence. Default dispatch gates block affected invalid truck days, but an explicit operator warn override exists and live settings were not inspected.


## Convergence wording scope confirmed

Native Thorough telemetry records main OR-Tools last improvement at 102.0 s and a 300.0 s stall; selected PyVRP last improved at 299.6 s. The UI/export formatter describes the top-level main-search values as the best plan's history without naming the engine. This is a source-confirmed reporting-scope bug (F06), distinct from stopping correctness. PyVRP's own stall is max(30 s, 10% of elapsed time), so its 102.5 s no-improvement interval at 402.1 s already meets that rule. There is no established premature stop or unmet 300 s PyVRP requirement.


## Additional final diagnostic and frozen-day evidence

The public component-only penalty diagnostic reached X-n101-k25's supplied BKS 27591 with the bounded raised configuration in 10 seconds; stock found no feasible embedded candidate. A separate two-truck fixture (100-case capacities; 51 + 50 case demand at 5 km) showed the same configuration effect in 2 seconds despite having no rentals or aggregate fleet shortage. Its known feasible 20 km / 20 OMR witness is valid in the embedded model. These are neither stock full-pipeline results nor extra official comparisons; both change initial penalty values alongside the ceiling.

D5's four 60-second controlled runs serve 175–176 of 180 pending stops / 310–312 of 320 invoices, while an independently validated greedy witness on the same frozen request serves all 180 stops / 320 invoices / 4,826 cases. Native budget for 180 stops is 110 seconds and follow-up evidence is separate. The ON seed 29 answer improves P2 count 32→34 relative to OFF seed 29 while total stops fall 176→175; priority-first reporting must capture this, and avoid an equal-service cost-saving claim. The full-service greedy witness dominates both service vectors. D5's causal mechanism has not been shown to be identical to P02's limited timing-repair pool.


## Native D3 follow-up changes the failure classification

The default-budget follow-up (150-second primary /540-second overall cap, hybrid seed17) recovered all200 stops /340 invoices /8,393 cases in155.872seconds,623.324 OMR and676.78km. Product reports VERIFIED/EXACT and the independent checker passes. PyVRP still found no feasible candidate after150seconds, but OR-Tools and the exact repair stage produced the complete valid answer. F01 is therefore classified as reduced-budget robustness / candidate-search quality, not a demonstrated default-production-budget failure or unconditional launch blocker. The planned off-mode follow-up was conditionally unnecessary after the hybrid/native recovery. A single successful native replay is positive evidence, not a general success guarantee.

## Native D5 follow-up exposes severe service loss

The native Quick hybrid replay used the automatic 110-second primary allowance and a 540-second request cap, yet finished after 125.771 seconds with only 84 of 180 pending stops, 158 of 320 invoices and 2,250 of 4,826 cases served. The independently checked answer is VERIFIED/EXACT. It omits three P1 and twenty P2 customers while serving twenty-one P5 customers. A separately authored greedy witness serves every pending stop and passes the same independent rules. Direct request comparison found only config.time_limit_sec different (60 versus null); all operational inputs and frozen reservations match. The witness proves severe avoidable service loss, not the minimum cash cost of full service.

The raw PyVRP candidate covers all 180 clients in its approximate model but fails actual timing. Logs show its final fit repack returns UNKNOWN after 10 seconds. The main repair returns a FEASIBLE candidate with a reported 100% bound gap after 8.4 seconds, retaining six of eleven original loads and dropping 96 stops. The overall poststage takes 15.1 seconds. Source inspection confirms Quick caps each repair job at 15 seconds per source and shares this allowance among successive attempts; it does not use the whole remaining 540-second request cap. That allocation, restricted repair alternatives and lack of a independently constructed full-service incumbent are concrete contributing limitations. No source patch or experiment establishes one sufficient fix.

F07 records this as a high operational quality risk at native settings. It is one native run on synthetic data, not a measured real-world failure rate. The separate controlled 60-second runs served 175–176 stops, but different budget/resource contexts preclude an isolated causal claim that more runtime makes the model worse. VERIFIED remains an accurate feasibility label; it does not establish that service selection is good, that only the lowest priorities were omitted, or that adding trucks is necessary. A validated fallback, bounded reinsertion/splitting and adaptive exact-repair time are appropriate next experiments.
