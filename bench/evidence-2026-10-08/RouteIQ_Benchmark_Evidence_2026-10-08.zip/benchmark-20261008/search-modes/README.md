# Native QUICK and THOROUGH search-budget test

Real RouteIQ `optimize_dispatch` at `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b` was run twice on the same synthetic D1 normal day: **360 invoices, 220 aggregated customer stops, 9,526 cases**. Both used production worker processes, PyVRP on with seed17, the same Haversine matrix, and CPU affinity4,6,8.

The request retains D1's **RECOMMENDED-only** option. This experiment uses default search budgets; it does not represent every production setting or run all three UI options.

| Result | QUICK | THOROUGH |
|---|---:|---:|
| Configured primary allowance | Automatic150s | Native extended search within1200s request cap |
| Actual end-to-end time | 164.20s | 426.35s |
| Stops / invoices served | 220 /360 | 220 /360 |
| Cases delivered | 9,526 | 9,526 |
| Trucks / loads | 7 /12 | 7 /11 |
| Estimated kilometres | 482.86 | 457.98 |
| Operating cost (OMR) | 438.533 | 431.370 |
| Customer-time preference penalty (OMR equivalent) | 9.998 | 18.274 |
| Full recommended objective (OMR equivalent) | **448.531** | **449.644** |
| Internal feasibility | VERIFIED | VERIFIED |
| Separate independent validator | PASS | PASS |

THOROUGH reduced operating cost by **7.163 OMR /1.63%**, and distance by **5.15%**, but its greater customer-time preference penalties made the complete recommendation objective **1.113 OMR equivalent /0.248% worse**. It is therefore not an unqualified optimization-quality win. This is one paired observation, not a distribution of performance.

Both modes served the identical complete priority vector: P1=13, P2=16, P3=71, P4=61, P5=59. `comparison.json` confirms byte-identical matrices and the only request changes (`search_mode` and `max_search_sec`).

## Stopping and evidence

- QUICK used the native automatic150s primary search and540s total budget. It stopped at `TIME_LIMIT`; PyVRP last improved its own candidate objective at149.7s and was selected.
- THOROUGH had the native1200s cap,150s minimum and300s primary stall floor, with no shortened iteration or stopping settings. It stopped naturally at `CONVERGED`, after402.1s of search plus postprocessing. The primary search's last improvement was102.0s; PyVRP's was299.6s. PyVRP ran62,150 iterations and was selected.
- `CONVERGED` means the configured no-improvement rule triggered. It is not a proof that no better routing exists.
- The saved `best_over_time` curves are each engine's own pre-postprocessing candidate objective. For example, QUICK PyVRP finishes at424.22, whereas the final complete objective is448.531. These curves must not be labelled final dispatch operating cost.
- Restricted CP-SAT repack bounds in logs are bounds for that candidate-load subproblem. They do not certify the global invoice/routing problem.

A practical enhancement would preserve the best fully evaluated feasible incumbent across extended search, comparing the actual service tiers and complete recommendation objective. More search time alone does not guarantee a monotone improvement after changes in routing and postprocessing.

## Limits and reproduction

This is synthetic data with estimated straight-line-based travel, not live Oman road traffic, actual customer invoices or a production rehearsal. Affinity was identical within this pair, but other benchmark jobs shared the host's8CPU quota; reported wall time is not a deployment SLA. The broader60s experiment used a different4CPU allocation, so its differences from this pair cannot be attributed exclusively to search time.

No repository source, production data, database or service was modified. The capture wrapper observes the normal provider's output rather than substituting the matrix. Full requests, matrices, responses, metadata and search traces are saved under `quick/` and `thorough/`.

On Linux with the project's pinned Python requirements:

```bash
python run_pair.py --repo /absolute/path/to/routeiq --cpus 4,6,8
```

Alternatively run `run_modes.py QUICK` or `run_modes.py THOROUGH`, with the same arguments. Choose CPUs permitted by the runtime. `ROUTEIQ_SOURCE` may specify the repository root. The default input is `../large/D1_normal/request.json`; `run_modes.py --request` can select another saved request. The external watchdog is above each mode's native cap plus shutdown margin, and neither watchdog fired in this experiment.
