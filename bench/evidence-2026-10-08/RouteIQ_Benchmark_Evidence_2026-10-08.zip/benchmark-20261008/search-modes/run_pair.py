"""Run modes serially; caps are external hang backstops above native cap+margin."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo');p.add_argument('--cpus',default='4,6,8');a=p.parse_args()
    rows=[]
    for mode,backstop in [('QUICK',690),('THOROUGH',1350)]:
        out=HERE/mode.lower();out.mkdir(exist_ok=True)
        cmd=[sys.executable,str(HERE/'run_modes.py'),mode,'--cpus',a.cpus]
        if a.repo:cmd+=['--repo',a.repo]
        print('START '+mode,flush=True);start=time.perf_counter()
        with (out/'run.log').open('w') as stream:
            result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=backstop)
        rows.append(dict(mode=mode,returncode=result.returncode,wall_sec=time.perf_counter()-start))
        (HERE/'run-status.json').write_text(json.dumps(rows,indent=2))
        print(json.dumps(rows[-1]),flush=True)
        if result.returncode:sys.exit(result.returncode)
