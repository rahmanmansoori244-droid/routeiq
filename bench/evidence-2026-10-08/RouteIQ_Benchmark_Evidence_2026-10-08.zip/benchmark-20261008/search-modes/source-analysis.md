# Source interpretation of the native search-mode experiment

Reviewed source: `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b`. No further model runs or application edits were made for this analysis.

## 1. More time did not improve the complete final objective

Observed, with identical service and matrix:

- QUICK: operating438.533 + preferences9.998 = **448.531**.
- THOROUGH: operating431.370 + preferences18.274 = **449.644**.
- THOROUGH is cheaper in cash but **1.113 OMR equivalent /0.248% worse** on the complete recommendation objective.

**Classification: confirmed heuristic quality observation and enhancement opportunity, not a demonstrated wrong-comparator bug.** These are separate runs. The retained evidence does not prove that THOROUGH evaluated the exact final QUICK plan and then discarded it, nor identify the particular intermediate route that would have prevented the regression.

The source explains why a longer raw search need not improve final dispatch quality:

1. `apps/solver/pyvrp_candidate.py:39–43` explicitly lists differences between the PyVRP search model and the final rules: preferred hours are approximated, P1/P2 early preference is absent, per-case loading is approximated, and mandatory breaks are added later.
2. `pyvrp_candidate.py:518–528` records improving **scores**, but not their route snapshots. `pyvrp_candidate.py:642–650` retrieves only `res.best` at the end, then extracts its routes. An earlier solution that scores worse under PyVRP's surrogate may have been better after exact timing and full preferences.
3. `pyvrp_candidate.py:735–749` feeds that one final plan to exact timing and candidate construction. There is no previous fully evaluated QUICK incumbent in this input.
4. `load_repack.py:1651–1656,1680–1701` correctly preserves feasible raw and repaired candidates supplied to the current stage. `load_repack.py:840–879` computes actual operating money plus preferences and continuity. `dispatch_solver.py:4903–4914,5207–5220` correctly selects by service, full cost and tie-breakers. Existing safeguards should remain; this is not a reason to remove repacking.
5. `dispatch_solver.py:5246–5278` builds and validates the chosen current-stage candidate, falling back from an invalid PyVRP candidate. `dispatch_solver.py:5092–5100` promises no regression against the engine's candidates from **that same search**, not against an independently executed shorter run. The observed pair does not contradict that stated guarantee.

### Concrete enhancement

Add a **fully evaluated feasible incumbent** to the search lifecycle and preserve it through every later stage:

- Establish an initial feasible plan using the normal QUICK pipeline, or evaluate a bounded number of route snapshots while the extended search runs. Count that work inside the total request budget; do not silently add another150s outside the cap.
- Store the actual timed loads, canonical `LR.Score`, validation result, input/version fingerprint and matrix hash. A plan from a different input, changed live state or matrix must first be revalidated and rescored.
- At the candidate union in `dispatch_solver.py:5199–5201`, add that incumbent as a distinct source. Compare with the exact same `_GOALS` at4903–4914, preserving service and rental tiers before money. Keep a small bounded archive of diverse candidates rather than only surrogate score history.
- After reconstruction at5259–5265 and any final repair/reordering, require independent feasibility and compare again with the retained feasible incumbent before `results[name] = new` at5315. Preserve the incumbent if the new complete objective is worse. Compare full precision, not rounded UI values.
- Record the final chosen source and a trace of **validated final objectives**. Keep raw search traces separately labelled as engine scores.

A useful regression criterion is monotonicity **relative to an actually supplied valid incumbent on identical input**, not an assumption that unrelated random/time-limited runs must be ordered by runtime. Test cancellation, cap exhaustion, failed reconstruction and changes of preference/rental/service tiers against that criterion.

## 2. Top-level convergence describes OR-Tools, but the UI describes the selected plan

The observed values are internally consistent with two different stall policies:

- OR-Tools: last improvement102.0s; stop402.1s after its300s stall.
- PyVRP: last improvement299.6s; stop402.1s. Its own default stall is `max(30s, 10% of elapsed)`, approximately40.2s here. The102.5s since its last improvement exceeds that threshold.

Relevant source:

- `dispatch_solver.py:744–757`: OR-Tools watch and stall termination.
- `dispatch_solver.py:4771–4772`: top-level state takes the OR-Tools recommended search's watch.
- `dispatch_solver.py:822–837`: top-level last-improvement/stall/progress are copied from that watch; PyVRP is a separate nested report.
- `pyvrp_candidate.py:64–71,531–545`: PyVRP's different stall floor/share; it waits until the main searches end, then evaluates its own timed stall.
- `dispatch_solver.py:4650–4673`: main searches end, `search_over` is signalled, and THOROUGH waits for PyVRP's own stopping rule within the budget.

**There is no demonstrated premature-termination bug in these numbers.** A300s OR-Tools stall is not intended to impose a300s PyVRP stall.

There is, however, a **confirmed reporting-scope problem**:

- `apps/web/lib/dispatch/search-mode.ts:277–282` renders the top-level fields as “The best plan was last improved…” and “no better plan for…”, without naming the main engine. For this selected PyVRP plan it uses102s and300s despite a PyVRP improvement at299.6s.
- This text appears on the plan screen (`app/t/[slug]/dispatch/plan-view.tsx:641,726–728`) and exported workbook (`lib/dispatch/workbook.ts:469–473`). The raw API nested report contains the correct PyVRP figures; the problem is how the main-engine figures are presented as describing the final plan.
- `dispatch_models.py:675–707` likewise describes top-level fields as the recommended plan's search, which is ambiguous after the selected plan comes from the second engine.

Suggested immediate wording: “Main search stopped after no improvement for5min. The second search supplied the selected plan; its last raw-search improvement was at5min. Final timing and loading checks followed.” Label every raw curve by engine. For a future unified field, measure improvement of the **fully evaluated final incumbent on a common clock**, rather than simply taking the maximum of two incomparable raw-objective timestamps.

This is a diagnostics/UI clarity issue, not evidence that the returned routes violate constraints or that a global optimum was proved.
