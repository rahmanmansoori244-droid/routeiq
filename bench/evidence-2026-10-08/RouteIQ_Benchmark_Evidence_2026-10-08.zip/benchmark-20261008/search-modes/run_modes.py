"""Production-budget QUICK/THOROUGH pair on one fixed 360-invoice synthetic day.

Does not shorten native stop/stall parameters or change source. It executes the
production worker path, captures its actual provider matrix, and saves raw output.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import logging
import os
from pathlib import Path
import platform
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=['QUICK','THOROUGH'])
    p.add_argument('--repo',type=Path,default=Path(os.environ.get('ROUTEIQ_SOURCE',ROOT/'routeiq-20261008')))
    p.add_argument('--request',type=Path,default=HERE.parent/'large/D1_normal/request.json')
    p.add_argument('--cpus',default='4,6,8')
    a=p.parse_args()
    os.sched_setaffinity(0,{int(v) for v in a.cpus.split(',')})
    # Unmodified default stopping parameters. The supplied cap is the native1200s.
    for key in list(os.environ):
        if key.startswith('ROUTEIQ_TEST_') or key.startswith('THOROUGH_') or key.startswith('SOLVER_PYVRP_') or key=='SOLVER_ALLOW_INPROCESS_FALLBACK':
            os.environ.pop(key,None)
    os.environ.update(SOLVER_PYVRP='on',SOLVER_PYVRP_SEED='17',SOLVER_PARALLEL='1',
        SOLVER_BUDGET_SEC='540',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(a.repo.resolve()/'apps/solver'))
    from dispatch_models import DispatchRequest
    import dispatch_solver as ds
    import pyvrp_candidate as pv
    from importlib.metadata import version
    original_bytes=a.request.read_bytes()
    r=DispatchRequest.model_validate_json(original_bytes)
    r.config.time_limit_sec=None
    r.config.search_mode=a.mode
    r.config.max_search_sec=1200 if a.mode=='THOROUGH' else None
    out=HERE/a.mode.lower();out.mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(name)s %(message)s')
    original=ds.resolve_matrix
    def captured(*args,**kwargs):
        mx=original(*args,**kwargs)
        (out/'matrix-used.json').write_text(json.dumps(dict(coords=args[0],
            distance_m=mx.distance_m,duration_s=mx.duration_s,quality=mx.quality,
            provider=mx.provider_name),separators=(',',':')))
        return mx
    ds.resolve_matrix=captured
    (out/'request.json').write_text(r.model_dump_json(indent=2))
    metadata=dict(source_sha='5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b',
        original_request_sha256=hashlib.sha256(original_bytes).hexdigest(),
        source_request_relative='../large/D1_normal/request.json',
        synthetic=True,input_boundary='DispatchRequest; no web/database or production data',
        input_invoices=sum(len(s.order_ids) for s in r.stops),stops=len(r.stops),
        hybrid='on',pyvrp_seed=17,ortools_seed='not exposed',
        cpu_affinity=sorted(os.sched_getaffinity(0)),production_workers=True,
        quick_request_budget_sec=540,thorough_request_cap_sec=1200,
        time_limit_sec=None,native_auto_search_sec=ds.auto_time_limit(len(r.stops)),
        scenarios_requested=r.config.scenarios,python=platform.python_version(),
        ortools=version('ortools'),pyvrp=version('pyvrp'),pyvrp_status=pv.status(),
        stall_rule=vars(ds.stall_rule(ds.auto_time_limit(len(r.stops)))),
        matrix='actual HAVERSINE estimated provider; not Oman road network',
        note='Default search-time/stall budgets; all other business inputs remain the fixed synthetic benchmark request. No application source edits.')
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
    started=time.perf_counter()
    try:
        response=ds.optimize_dispatch(r);elapsed=time.perf_counter()-started
        (out/'response.json').write_text(response.model_dump_json(indent=2))
        sc=next(s for s in response.scenarios if s.name=='RECOMMENDED')
        served={s.stop_id for ld in sc.loads for s in ld.stops}
        result=dict(mode=a.mode,wall_sec=elapsed,search=response.search.model_dump() if response.search else None,
            input_stops=len(r.stops),served_stops=len(served),unserved_stops=len(sc.unserved),
            input_invoices=sum(len(s.order_ids) for s in r.stops),
            served_invoices=sum(len(s.order_ids) for s in r.stops if s.stop_id in served),
            input_cases=sum(s.demand_cases for s in r.stops),served_cases=sc.total_cases,
            service_vector=[sum(s.priority==p and s.stop_id in served for s in r.stops) for p in range(1,6)],
            operating_cost=sc.operating_cost,distance_km=sc.total_distance_km,
            trucks=sc.trucks_used,loads=sc.trips,objective=sc.objective.model_dump(),
            feasibility=sc.feasibility.model_dump() if sc.feasibility else None,
            solver_status=sc.solver_status,status=sc.status,
            warnings=response.warnings+sc.warnings)
        (out/'summary.json').write_text(json.dumps(result,indent=2))
        print(json.dumps({k:result[k] for k in ['mode','wall_sec','served_stops','served_invoices','served_cases','service_vector','operating_cost','distance_km','trucks','loads']}),flush=True)
    except Exception as exc:
        (out/'error.json').write_text(json.dumps(dict(type=type(exc).__name__,message=str(exc),
            elapsed_sec=time.perf_counter()-started,traceback=traceback.format_exc()),indent=2))
        raise

if __name__=='__main__':main()
