#!/usr/bin/env python3
"""Validate completed artifacts only; rerunnable while suites finish."""
import json
from pathlib import Path
from validate import ROOT, validate

outdir=ROOT/'validation'/'reports'; outdir.mkdir(exist_ok=True)
jobs=[]
for lane in ['large','exact','pipeline','search-modes','diagnostics']:
    for response in (ROOT/lane).rglob('response.json'):
        d=response.parent; req=d/'request.json'
        if not req.exists(): continue
        mx=next((p for p in [d/'matrix-used.json',d/'matrix.json'] if p.exists()),None)
        raw=d.parent/'invoices.json' if lane=='large' else None
        jobs.append((req,response,mx,raw if raw and raw.exists() else None))
for response in (ROOT/'public'/'runs').glob('*.response.json'):
    if '.pyvrp.' in response.name: continue  # Native route list checked by public_routes.py.
    name=response.name.split('.')[0]
    req=ROOT/'public'/'inputs'/f'{name}.request.json'; mx=ROOT/'public'/'inputs'/f'{name}.matrix.json'
    if req.exists() and mx.exists(): jobs.append((req,response,mx,None))
summary=[]; errors=[]
for req,response,mx,raw in jobs:
    try:
        result=validate(req,response,mx,raw)
        label=str(response.relative_to(ROOT)).replace('/','__').replace('.response.json','').replace('response.json','result')
        target=outdir/(label+'.json'); target.write_text(json.dumps(result,indent=2)+'\n')
        row=dict(response=str(response.relative_to(ROOT)),status=result['status'],scenarios=len(result['scenarios']),checks=sum(s['checks'] for s in result['scenarios']),invoice_status=result['invoice_check']['status'],violations=[v for s in result['scenarios'] for v in s['violations']],report=str(target.relative_to(ROOT)))
        summary.append(row); print(row['response'],row['status'],len(row['violations']),flush=True)
    except Exception as e:
        errors.append(dict(response=str(response.relative_to(ROOT)),error=repr(e))); print('ERROR',response,repr(e),flush=True)
result=dict(reports=len(summary),passed=sum(r['status']=='PASS' for r in summary),failed=sum(r['status']=='FAIL' for r in summary),errors=errors,runs=summary)
(ROOT/'validation'/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
