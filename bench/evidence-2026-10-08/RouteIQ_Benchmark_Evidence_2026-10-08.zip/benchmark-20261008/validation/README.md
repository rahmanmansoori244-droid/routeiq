# Independent validation — 8 October 2026

Reviewed RouteIQ commit: `5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b`.

These scripts were implemented separately for this benchmark. They import **no RouteIQ production module, feasibility checker, reconciliation helper, test assertion, or costing function**. Input semantics were read from the documented wire contract and source comments. OR-Tools CP-SAT is used as a generic integer constraint checker, not as a routing optimizer; it checks the fixed returned routes and reported times.

## Scripts and outputs

- `validate.py REQUEST RESPONSE --matrix MATRIX --output REPORT`: check one RouteIQ response. `--raw-invoices FILE` additionally checks the large-day fixture invoice schema.
- `run_all.py`: discover finished large, exact, pipeline, search-mode, and public RouteIQ responses; write `reports/*.json` and `summary.json`. Standalone PyVRP outputs use the route checker below.
- `public_routes.py`: independently parse original public `.vrp` files, reconstruct the prescribed distance/time matrix, and check the returned native routes for every available RouteIQ and standalone PyVRP public run. Writes `public-routes.json`.
- `pipeline_accounting.py`: separately reconcile raw invoice rows through confirmed source lines, request-builder portions/pre-drops, solver output and persisted assignments. Writes `pipeline-accounting.json`.
- `mutation_checks.py`: deliberately corrupt copied answers and check rejection. Writes `mutation-results.json`. Eight mutations cover duplicate/missing stops, capacity, impossible closing, wrong arc distance, balanced-but-false money, frozen overlap and missing required breaks.
- `aggregate.py`: write compact `aggregate-by-lane.json` with separate stock, baseline, native-budget replay, modified-diagnostic and constructed-witness counts; compare product feasibility labels with independent findings. Run after the preceding consolidation scripts.

Use the Python environment with OR-Tools installed, for example the benchmark's `status-20261001/solver-venv/bin/python`. No services, database, production credentials or network calls are needed. The test inputs and returned routes are synthetic/public.

## Covered invariants

1. Every requested stop appears once, either served or unserved. Order and customer identities and served quantities match the request.
2. Load cases/kg/pallets and scenario totals match reconstructed stop quantities. Weight uses documented tenths; pallet factors are summed in 1/1000-pallet units. A bay truck ignores its case capacity; payload zero is unconstrained.
3. Route arc distances and travel times match the supplied matrix. Return legs and full-route distance are recomputed.
4. Service duration, receiving-hour START/FINISH semantics, arrival-before-service, depot opening/closing, truck availability, shift maximum, latest return, loading turnaround, same-day loading readiness, load counts, numbering and frozen reservations are enforced.
5. Required breaks, break windows/duration, no unloading during breaks, depot breaks and road-break positions are independently encoded. Existing frozen breaks count only according to their supplied reservation metadata.
6. Fixed/day-driver charge once, per-trip/per-km/fuel costs, hourly paid-day intervals, overtime increments, fixed-load anchoring and component/total rounding are checked independently.
   Reported preferred-window, priority-arrival and truck-continuity penalties are constrained against the same compatible timetable; baseline preference penalties are computed from its exact-minute schedule. Reports distinguish cash operating cost from cash plus these noncash preferences.
7. Each used prospective rental must carry at least one P1–P3 stop. Priority service counts are recomputed; this is **not a proof of priority-optimal selection**.
8. Raw large-day invoices are checked line by line against product factors and stop grouping. Pipeline fixtures additionally check invoice/customer/SKU conservation, split source-line quantities, pre-dropped cases, exact persisted assignments and source-line-derived reconciliation summaries. Frozen pipeline load and assignment snapshots are checked unchanged.
9. Public CVRP and Solomon benchmark inputs are independently parsed and transformed. Public native routes are checked directly against that reconstruction for coverage, capacity, applicable earliest feasible time windows, fleet limit and distance. Solomon distances use DIMACS truncation, not SINTEF double precision.

## Precision and limits

The application exposes **minute-rounded timestamps**, not the underlying second timestamps. The checker creates integer-second variables in the intervals that round to those outputs and requires all physical/cost constraints to hold simultaneously. PASS establishes existence of a compatible timetable; it cannot prove that an invisible sub-minute product timestamp was identical. Money constraints narrow those intervals where costs are emitted. This limitation is preserved in every report.

The independently coded greedy baseline deliberately rounds each travel duration **up** to whole minutes and uses exact whole-minute clocks. Its explicitly labelled checker mode validates those conservative durations and its pre-drive break waits. This is separate from RouteIQ's nearest-minute wire contract and never weakens the product output check. Because every baseline duration is at least the matrix duration, a valid baseline is a conservative feasible witness; it is not a historical dispatcher plan.

A PASS is **feasibility and accounting evidence, not an optimality certificate**. Raw-request accounting can pass when a model builder excludes a deliverable order: a recorded pre-drop conserves quantity but can still be a planning defect. Exact optimality comparisons belong to the separate exhaustive-oracle suite. Unserved reason explanations, internal search/drop/hire-tier objective penalties, global priority optimality, road-network truth, truck-access restrictions, frozen loads' internal historic feasibility, actual database concurrency, ERP behavior, exported documents and physical/mobile operations are not proved here.

`summary.json` can be refreshed while runners complete. Counts are evidence artifacts/answers, not a claim that each individual assertion is a separate real-world scenario. Do not include files quarantined in `adapter-debug*` or obsolete initial smoke reports in final statistics.
