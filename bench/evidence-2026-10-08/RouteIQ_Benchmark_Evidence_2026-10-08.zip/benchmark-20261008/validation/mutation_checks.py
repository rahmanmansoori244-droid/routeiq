"""Calibrate checker with deliberate corruptions; never alter benchmark evidence."""
import copy,json
from pathlib import Path
from validate import ROOT,read,check_scenario

base=ROOT/'exact'/'cases-01'; req=read(base/'request.json'); sc=read(base/'response.json')['scenarios'][0]; mx=read(base/'matrix.json')
results=[]
def trial(name,fn,r=req,s=sc,m=mx):
    r,s=copy.deepcopy(r),copy.deepcopy(s); fn(r,s)
    out=check_scenario(r,s,m)
    results.append(dict(name=name,rejected=out['status']=='FAIL',violations=[v['code'] for v in out['violations']]))
trial('duplicated served stop',lambda r,s:s['loads'][0]['stops'].append(copy.deepcopy(s['loads'][0]['stops'][0])))
trial('missing stop',lambda r,s:s['loads'][0]['stops'].pop())
trial('overcapacity',lambda r,s:r['trucks'][0].update(capacity_cases=0))
trial('impossible closing time',lambda r,s:r['stops'][0].update(hard_end_min=1))
trial('wrong travelled distance',lambda r,s:s['loads'][0]['stops'][0].update(leg_km=s['loads'][0]['stops'][0]['leg_km']+1))
def badcost(r,s):
    ld=s['loads'][0]; ld['time_cost']+=10; ld['driver_cost']+=10; ld['total_cost']+=10; s['operating_cost']+=10
trial('corrupt cost with balanced totals',badcost)
def overlap(r,s):
    ld=s['loads'][0]; t=next(t for t in r['trucks'] if t['id']==ld['truck_id']); t['frozen_trips']=[dict(load_no=1,depart_min=ld['depart_min'],return_min=ld['return_min'])]
trial('frozen reservation overlap',overlap)
large=ROOT/'large'/'D1_normal'/'on-seed17'
if (large/'response.json').exists():
    lr=read(large/'request.json'); ls=read(large/'response.json')['scenarios'][0]; lm=read(large/'matrix-used.json')
    def removebreak(r,s):
        for ld in s['loads']: ld['driver_break']=None
    trial('required breaks removed',removebreak,lr,ls,lm)
out=dict(passed=all(x['rejected'] for x in results),mutations=len(results),results=results)
(ROOT/'validation'/'mutation-results.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
