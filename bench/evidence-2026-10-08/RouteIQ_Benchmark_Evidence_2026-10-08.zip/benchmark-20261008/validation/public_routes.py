"""Independent public-instance adapter and route validation from raw .vrp text."""
import math,json
from collections import Counter
from validate import ROOT,Checks,read

def parse(path):
    headers={}; sections={}; section=None
    for raw in path.read_text().splitlines():
        line=raw.strip()
        if not line or line=='EOF': continue
        if line.endswith('_SECTION'): section=line;sections[section]=[];continue
        if section: sections[section].append(line.split())
        elif ':' in line:
            k,v=line.split(':',1);headers[k.strip()]=v.strip()
    coords={int(r[0])-1:(float(r[1]),float(r[2])) for r in sections['NODE_COORD_SECTION']}
    demand={int(r[0])-1:int(r[1]) for r in sections['DEMAND_SECTION']}
    windows={int(r[0])-1:(int(r[1]),int(r[2])) for r in sections.get('TIME_WINDOW_SECTION',[])}
    return headers,coords,demand,windows

results=[]
for summarypath in sorted((ROOT/'public'/'runs').glob('*.summary.json')):
    summary=read(summarypath); name=summary['instance']; matrixpath=ROOT/'public'/'inputs'/f'{name}.matrix.json'
    if not matrixpath.exists():continue
    mx=read(matrixpath); req=read(matrixpath.with_name(f'{name}.request.json')); ck=Checks()
    rawpath=next((ROOT/'public'/'instances').glob(f'*_{name}.vrp')); h,coords,demand,windows=parse(rawpath)
    tw=h['TYPE']=='CVRPTW'; n=int(h['DIMENSION']); dist=[];times=[]
    for i in range(n):
        d=[];t=[]
        for j in range(n):
            euclid=math.hypot(coords[i][0]-coords[j][0],coords[i][1]-coords[j][1])
            published=math.floor(euclid*10+1e-9) if tw else math.floor(euclid+0.5)
            d.append(published*(100 if tw else 1000));t.append(published*6 if tw else 0)
        dist.append(d);times.append(t)
    ck.check(mx['distance_m']==dist,'PUBLIC_DISTANCE_MATRIX','Independent parsing and prescribed EUC2D nearest-integer / DIMACS truncation')
    ck.check(mx['duration_s']==times,'PUBLIC_TIME_MATRIX','CVRP time disabled; TW distance in original units per minute')
    for i,st in enumerate(req['stops'],1):
        ck.eq(st['demand_cases'],demand[i],'PUBLIC_DEMAND',i)
        if tw:
            ck.eq(st['hard_start_min'],windows[i][0],'PUBLIC_OPEN',i);ck.eq(st['hard_end_min'],windows[i][1],'PUBLIC_CLOSE',i);ck.eq(st['service_min'],int(h['SERVICE_TIME']),'PUBLIC_SERVICE',i)
    routes=summary['routes']; seen=[i for r in routes for i in r]
    ck.check(Counter(seen)==Counter(range(1,n)),'PUBLIC_COVERAGE','Each required non-depot client exactly once')
    if tw:ck.check(len(routes)<=int(h['VEHICLES']),'PUBLIC_FLEET_LIMIT',len(routes))
    total=0
    for idx,route in enumerate(routes):
        ck.check(sum(demand[i] for i in route)<=int(h['CAPACITY']),'PUBLIC_CAPACITY',idx)
        now=windows.get(0,(0,0))[0]*60; prev=0; dm=0
        for i in route:
            dm+=dist[prev][i];now+=times[prev][i]
            if tw:
                now=max(now,windows[i][0]*60);ck.check(now<=windows[i][1]*60,'PUBLIC_TIME_WINDOW',dict(route=idx,node=i,earliest_seconds=now));now+=int(h['SERVICE_TIME'])*60
            prev=i
        dm+=dist[prev][0];now+=times[prev][0]
        if tw:ck.check(now<=windows[0][1]*60,'PUBLIC_DEPOT_RETURN',idx)
        total+=dm
    ck.eq(summary.get('evaluation',{}).get('distance'),total/1000,'PUBLIC_REPORTED_DISTANCE',name,tol=.000001)
    results.append(dict(summary=str(summarypath.relative_to(ROOT)),instance=name,engine=summary['engine'],status='PASS' if not ck.violations else 'FAIL',checks=ck.count,violations=ck.violations,independent_distance=total/1000,routes=len(routes),clients=len(seen),matrix_verified_against_raw_instance=True))
out=dict(runs=len(results),passed=sum(r['status']=='PASS' for r in results),results=results,limitations=['Public route checks are for the benchmark subproblem, not NMWC multi-trip/rental business rules.','TW timing uses feasible earliest service starts and START windows; distance follows DIMACS truncation, not SINTEF double precision.','Published solution quality is evaluated elsewhere; this checker confirms raw-instance mapping and returned route feasibility/distance.'])
(ROOT/'validation'/'public-routes.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(runs=out['runs'],passed=out['passed'],failures=[r for r in results if r['status']=='FAIL']),indent=2))
