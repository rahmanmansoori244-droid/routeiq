"""Compact evidence counts by purpose; never mix diagnostics into stock pass rates."""
import collections,datetime,json
from validate import ROOT,HEAD,read

primary={'P01-360-invoices','P02-frozen-late-VIP','P03-small-and-big-hire','P04-ffd-packing','P05-heavy-rental-filter'}
def purpose(path):
    parts=path.split('/')
    if parts[0]=='large':
        if parts[2]=='greedy-baseline':return 'large_independent_greedy'
        if 'auto-budget' in parts[2]:return 'native_budget_failure_replays'
        return 'large_stock_60s'
    if parts[0]=='exact':return 'formulation_counterexamples_and_witnesses' if parts[1]=='formulation' else 'tiny_exact_reference'
    if parts[0]=='pipeline':
        tag=parts[2]
        if tag in primary:return 'pipeline_primary'
        if 'witness' in tag or 'repair' in tag:return 'pipeline_constructed_witnesses'
        return 'pipeline_comparison_and_replays'
    if parts[0]=='search-modes':return 'native_search_mode_pair'
    if parts[0]=='diagnostics':return 'modified_search_diagnostics'
    if parts[0]=='public':return 'public_routeiq_wire'
    return 'unclassified'

summary=read(ROOT/'validation'/'summary.json'); groups=collections.defaultdict(list)
for row in summary['runs']:
    report=read(ROOT/row['report']); tag=purpose(row['response'])
    groups[tag].append(dict(response=row['response'],independent=row['status'],invoice_check=report['invoice_check']['status'],scenarios=[dict(name=s['name'],independent=s['status'],product_feasibility=s.get('reported_product_feasibility'),violations=[v['code'] for v in s['violations']],served=s['served_stops'],unserved=s['unserved_stops']) for s in report['scenarios']]))
lanes={}; disagreements=[]
for name,rows in sorted(groups.items()):
    statuses=collections.Counter(r['independent'] for r in rows); product=collections.Counter(str(s['product_feasibility']) for r in rows for s in r['scenarios'])
    for r in rows:
        for s in r['scenarios']:
            if s['product_feasibility']=='VERIFIED' and s['independent']!='PASS':disagreements.append(dict(response=r['response'],scenario=s['name'],problem='Product VERIFIED but independent check failed',codes=s['violations']))
            if s['product_feasibility']=='VIOLATED' and s['independent']=='PASS':disagreements.append(dict(response=r['response'],scenario=s['name'],problem='Product VIOLATED but checker passed; compare coverage'))
    lanes[name]=dict(answers=len(rows),independent_status=dict(statuses),product_feasibility_status=dict(product),failures=[r for r in rows if r['independent']!='PASS'],responses=[r['response'] for r in rows])
public=read(ROOT/'validation'/'public-routes.json')
lanes['public_raw_instance_route_checks']=dict(answers=public['runs'],independent_status=dict(collections.Counter(r['status'] for r in public['results'])),by_engine={e:dict(answers=len(rs),passed=sum(r['status']=='PASS' for r in rs)) for e in sorted({r['engine'] for r in public['results']}) for rs in [[r for r in public['results'] if r['engine']==e]]},failures=[r for r in public['results'] if r['status']!='PASS'],note='Includes the same public RouteIQ answers counted in wire checks plus standalone PyVRP routes; do not add as disjoint experiments.')
accounting=read(ROOT/'validation'/'pipeline-accounting.json'); lanes['pipeline_independent_line_accounting']=dict(cases=len(accounting['cases']),status=dict(collections.Counter(r['status'] for r in accounting['cases'])),details=accounting['cases'])
mutation=read(ROOT/'validation'/'mutation-results.json')
result=dict(head=HEAD,generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),lanes=lanes,product_checker_disagreements=disagreements,artifact_errors=summary['errors'],checker_calibration=dict(mutated_answers=mutation['mutations'],all_deliberate_corruptions_rejected=mutation['passed']),interpretation=[
    'These are artifact counts separated by purpose, not independent statistical estimates of reliability.',
    'large_stock_60s contains four repetitions/comparison modes per synthetic day; four D3 failures are one shared scenario failure repeated, not four unrelated real days.',
    'Modified diagnostics and constructed witnesses are excluded from stock optimizer success counts.',
    'A PASS proves covered feasibility/accounting consistency, not optimality or that every deliverable order was accepted by the request builder.',
    'Tiny exact-reference matching is reported separately by the exhaustive oracle suite.',
    'Integer-second consistency accommodates minute-rounded wire output; hidden original seconds cannot be inspected.',
])
(ROOT/'validation'/'aggregate-by-lane.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{'answers':v.get('answers',v.get('cases')),'status':v.get('independent_status',v.get('status'))} for k,v in lanes.items()},indent=2)); print('Product/checker disagreements:',len(disagreements))
