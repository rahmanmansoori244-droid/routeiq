#!/usr/bin/env python3
"""Independent RouteIQ wire-output checker. Does NOT import any RouteIQ module.

The model below is a separate constraint encoding of the documented contract.
Reported clock times are rounded half-up to minutes. Consequently a successful
timing check proves that the response is consistent with at least one integer-
second timetable, not that the hidden unrounded product timetable was correct.
CP-SAT is used only as a generic satisfiability engine, with no routing objective.
"""
from __future__ import annotations
import argparse, collections, copy, hashlib, json, math, os
from fractions import Fraction
from pathlib import Path
from ortools.sat.python import cp_model

ROOT = Path(__file__).resolve().parents[1]
HEAD = "5b2ee0669c5b39a05b0dbff5c8acf8c2d30f160b"
LIMITATIONS = [
    "A passing check is feasibility/accounting evidence, not global optimality.",
    "Minute-rounded output can hide sub-minute differences. The constraint check establishes existence of a compatible integer-second timetable, including money constraints where emitted.",
    "Raw invoice checks cover the supplied synthetic fixtures, not ERP parsing/database transactions or actual customer master data.",
    "Frozen loads are reservations: their internal stop legality and historical cost are outside this response contract and are not rechecked.",
    "No road-network, truck-access, live-traffic, GPS, photo, mobile/offline or operational validation.",
    "Unserved reason explanations and objective/search penalties are not independently proved; service/priorities and operating costs are recomputed.",
]

def read(path): return json.loads(Path(path).read_text())
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def close(a,b,tol=1e-6): return a is not None and abs(float(a)-float(b)) <= tol
def tenths(x): return max(0, math.floor(float(x)*10+0.5))
def frac(x): return Fraction(str(x))

def haversine_matrix(req):
    coords=[(req['depot']['lat'],req['depot']['lng'])]+[(s['lat'],s['lng']) for s in req['stops']]
    c=req.get('config',{}); mult=c.get('haversine_multiplier',1.3); speed=c.get('avg_speed_kmh',40)
    ds=[]; ts=[]
    for la,lo in coords:
        dd=[]; tt=[]
        for lb,lp in coords:
            a=math.sin(math.radians(lb-la)/2)**2+math.cos(math.radians(la))*math.cos(math.radians(lb))*math.sin(math.radians(lp-lo)/2)**2
            km=2*6371.0088*math.asin(min(1,math.sqrt(a)))*mult
            dd.append(round(km*1000)); tt.append(round(km/speed*3600))
        ds.append(dd); ts.append(tt)
    return dict(node_ids=['DEPOT']+[s['stop_id'] for s in req['stops']],distance_m=ds,duration_s=ts,checker_reconstructed=True)

class Checks:
    def __init__(self): self.violations=[]; self.count=0
    def check(self,ok,code,detail):
        self.count+=1
        if not ok: self.violations.append(dict(code=code,detail=detail))
    def eq(self,a,b,code,detail,tol=1e-6): self.check(close(a,b,tol),code,dict(context=detail,reported=a,expected=b,tolerance=tol))

def check_invoices(req,raw):
    ck=Checks()
    if raw is None: return dict(status='NOT_SUPPLIED',checks=0,violations=[])
    if not isinstance(raw,dict) or not all(k in raw for k in ['invoices','products']):
        return dict(status='UNSUPPORTED_SCHEMA',checks=0,violations=[],note='Expected products[] and invoices[{invoice_id,customer_id,lines[{sku,cases}]}].')
    products={p['sku']:p for p in raw['products']}; invs={x['invoice_id']:x for x in raw['invoices']}
    ck.check(len(invs)==len(raw['invoices']),'RAW_DUP_INVOICE','Raw invoice IDs must be unique')
    used=[]
    for st in req['stops']:
        ids=st['order_ids']; used+=ids; cases=kg=pal=0
        for oid in ids:
            inv=invs.get(oid)
            ck.check(inv is not None,'RAW_UNKNOWN_INVOICE',dict(stop=st['stop_id'],invoice=oid))
            if not inv: continue
            ck.check(inv['customer_id']==st['customer_id'],'RAW_CUSTOMER',dict(stop=st['stop_id'],invoice=oid))
            for line in inv['lines']:
                p=products[line['sku']]; qty=line['cases']; cases+=qty
                line_kg=qty*p['kg_per_case']; units=math.ceil(qty*1000/p['cases_per_pallet'])
                kg+=line_kg; pal+=units
                if 'kg' in line: ck.eq(line['kg'],line_kg,'RAW_LINE_KG',line.get('line_id'),tol=0.051)
                if 'pallet_units' in line: ck.eq(line['pallet_units'],units,'RAW_LINE_PALLETS',line.get('line_id'))
        ck.eq(st['demand_cases'],cases,'RAW_STOP_CASES',st['stop_id'])
        ck.eq(tenths(st.get('demand_kg',0)),tenths(kg),'RAW_STOP_KG',st['stop_id'])
        ck.eq(st.get('demand_pallet_units'),pal,'RAW_STOP_PALLETS',st['stop_id'])
    ck.check(collections.Counter(used)==collections.Counter(invs.keys()),'RAW_INVOICE_PARTITION','Every raw invoice appears exactly once in request stops; no splitting assumed in this fixture schema.')
    return dict(status='PASS' if not ck.violations else 'FAIL',checks=ck.count,violations=ck.violations,invoices=len(invs),cases=sum(l['cases'] for i in invs.values() for l in i['lines']))

def check_scenario(req,sc,matrix,conservative_minutes=False):
    ck=Checks(); config=req.get('config',{}); depot=req['depot']; allstops={s['stop_id']:s for s in req['stops']}; trucks={t['id']:t for t in req['trucks']}
    loads=sc.get('loads',[]); flat=[s for l in loads for s in l['stops']]; un=sc.get('unserved',[])
    servedids=[s['stop_id'] for s in flat]; missingids=[s['stop_id'] for s in un]
    ck.check(collections.Counter(servedids+missingids)==collections.Counter(allstops.keys()),'STOP_PARTITION','Each input stop must be served or unserved exactly once, and output may not invent stops.')
    bytruck=collections.defaultdict(list)
    model=cp_model.CpModel(); variable_count=0; timing_byload={}; timing_assertions=[]; assumption_tags={}
    def rounded(minute,name):
        nonlocal variable_count
        variable_count+=1
        if conservative_minutes: return model.new_int_var(int(minute)*60,int(minute)*60,name)
        return model.new_int_var(max(0,int(minute)*60-30),int(minute)*60+29,name)
    def con(expr,tag):
        ct=model.add(expr); timing_assertions.append(tag)
        if os.environ.get('VALIDATOR_DEBUG')=='1':
            lit=model.new_bool_var('constraint '+str(len(timing_assertions))); ct.only_enforce_if(lit); model.add_assumption(lit); assumption_tags[lit.index]=tag
    def bound(expr,lower,upper,tag):
        con(expr>=lower,tag); con(expr<=upper,tag)
    def rounded_expr(expr,minute,tag): bound(expr,int(minute)*60-30,int(minute)*60+29,tag)
    def money(expr_terms,constant,shown,tag,tolerance=Fraction(1001,1000000)):
        # Each component is allocated to an integer baisa by largest remainder.
        # Total is rounded once, but the 0.001 tolerance safely handles both.
        if shown is None: return
        terms=[(e,frac(v)) for e,v in expr_terms]; d=math.lcm(*([f.denominator for _,f in terms]+[frac(constant).denominator,frac(shown).denominator,tolerance.denominator]))
        if d>10**12: return
        ex=sum(e*int(f*d) for e,f in terms)+int(frac(constant)*d)-int(frac(shown)*d)
        eps=math.ceil(tolerance*d)
        bound(ex,-eps,eps,tag)
    node_ids=matrix.get('node_ids') or ['DEPOT']+[s['stop_id'] for s in req['stops']]
    ix={s:i for i,s in enumerate(node_ids)}; dm=matrix['distance_m']; tm=matrix['duration_s']
    raw_distance=0; cost_sum=0; distance_byload={}; allrawkg=0; allpal=0
    soft_window_terms=[]; soft_early_terms=[]; soft_continuity=Fraction(0)
    baseline_soft_window=Fraction(0); baseline_soft_early=Fraction(0)
    for ui in un:
        si=allstops.get(ui['stop_id'])
        if si: ck.check(ui['order_ids']==si['order_ids'],'UNSERVED_ORDER_IDS',ui['stop_id'])
    for loadindex,ld in enumerate(loads):
        tid=ld['truck_id']; t=trucks.get(tid); label=f'{tid}/{ld["load_no"]}'
        ck.check(t is not None,'UNKNOWN_TRUCK',label)
        if t is None: continue
        bytruck[tid].append(ld)
        ck.check(bool(ld['stops']),'EMPTY_LOAD',label)
        cs=sum(allstops.get(s['stop_id'],{}).get('demand_cases',0) for s in ld['stops'])
        kg=sum(tenths(allstops.get(s['stop_id'],{}).get('demand_kg',0)) for s in ld['stops'])
        pal=sum(allstops.get(s['stop_id'],{}).get('demand_pallet_units') or 0 for s in ld['stops'])
        allrawkg+=kg; ck.eq(ld['cases'],cs,'LOAD_CASES',label); ck.eq(tenths(ld['kg']),kg,'LOAD_KG',label)
        if t.get('bays') is not None:
            room=t['bays']*config.get('pallet_fill_pct',100)*10
            ck.check(pal<=room,'PALLET_CAPACITY',dict(load=label,demand=pal,capacity=room)); ck.eq(ld.get('pallet_units'),pal,'LOAD_PALLETS',label); ck.eq(ld.get('pallet_room_units'),room,'PALLET_ROOM',label)
            util=pal/(t['bays']*1000); allpal+=pal
        else:
            ck.check(cs<=t['capacity_cases'],'CASE_CAPACITY',dict(load=label,demand=cs,capacity=t['capacity_cases'])); util=cs/t['capacity_cases'] if t['capacity_cases'] else 0
        if t.get('capacity_kg',0)>0:
            cap=math.floor(t['capacity_kg']*10+1e-6); ck.check(kg<=cap,'KG_CAPACITY',dict(load=label,demand_tenths=kg,capacity_tenths=cap)); util=max(util,kg/(10*t['capacity_kg']))
        ck.eq(ld.get('utilization_pct'),100*util,'UTILIZATION',label,tol=0.051)
        dep=rounded(ld['depart_min'],label+' depart'); ret=rounded(ld['return_min'],label+' return'); starts=[]
        bound(dep,max(config.get('shift_start_min',360),depot.get('open_min',0),t.get('available_from_min') or 0)*60,172800,'departure window '+label)
        latest=min(depot.get('close_min') or 1440,t.get('available_to_min') or 2880,config.get('latest_return_min') if config.get('latest_return_min') is not None else 2880)
        con(ret<=latest*60,'latest return '+label); con(ret>=dep,'nonnegative trip '+label)
        ck.eq(ld.get('duration_min'),ld['return_min']-ld['depart_min'],'DURATION_DISPLAY',label)
        br=ld.get('driver_break'); bs=be=None; brlen=config.get('break_min',0)*60
        if br:
            bs=rounded(br['start_min'],label+' break'); be=rounded(br['end_min'],label+' break end'); con(be==bs+brlen,'break duration '+label)
            bound(bs,config.get('break_start_from_min',720)*60,config.get('break_start_to_min',840)*60,'break window '+label)
            ck.check(brlen>0,'BREAK_DISABLED',label)
        prevdep=dep; prevnode=0; metres=0
        for j,st in enumerate(ld['stops']):
            sid=st['stop_id']; s=allstops.get(sid)
            ck.eq(st['sequence'],j+1,'STOP_SEQUENCE',dict(load=label,stop=sid))
            if s is None or sid not in ix: continue
            ck.check(st['order_ids']==s['order_ids'],'STOP_ORDER_IDS',sid); ck.check(st['customer_id']==s['customer_id'],'STOP_CUSTOMER',sid)
            ck.eq(st['cases'],s['demand_cases'],'STOP_CASES',sid); ck.eq(tenths(st['kg']),tenths(s.get('demand_kg',0)),'STOP_KG',sid)
            if s.get('demand_pallet_units') is not None: ck.eq(st.get('pallet_units'),s['demand_pallet_units'],'STOP_PALLETS',sid)
            node=ix[sid]; leg=dm[prevnode][node]; travel=tm[prevnode][node]; metres+=leg
            if conservative_minutes: travel=math.ceil(travel/60)*60
            ck.eq(st['leg_km'],leg/1000,'LEG_DISTANCE',sid,tol=.005001); ck.eq(st['cum_km'],metres/1000,'CUM_DISTANCE',sid,tol=.005001)
            ck.eq(st['leg_min'],travel/60,'LEG_TIME',sid,tol=.500001)
            start=rounded(st['service_start_min'],sid+' start'); arrival=rounded(st['arrival_min'],sid+' arrival'); starts.append(start)
            service=s.get('service_min',10)*60
            ck.eq(st['departure_min']-st['service_start_min'],s.get('service_min',10),'SERVICE_DURATION',sid)
            bound(start,(s.get('hard_start_min') or 0)*60,(s.get('hard_end_min') if s.get('hard_end_min') is not None else 1440)*60-(service if config.get('window_rule','START')=='FINISH' else 0),'hard window '+sid)
            pref_start=s.get('pref_start_min'); pref_end=s.get('pref_end_min')
            pref_end_sec=max(0,pref_end*60-(service if config.get('window_rule','START')=='FINISH' else 0)) if pref_end is not None else None
            wrate=frac(config.get('pref_window_penalty_per_min',.05))/60
            for expression,label_soft in ([(pref_start*60-start,'early preference')] if pref_start is not None else [])+([(start-pref_end_sec,'late preference')] if pref_end_sec is not None else []):
                excess=model.new_int_var(0,172800,sid+' '+label_soft); model.add_max_equality(excess,[0,expression]);soft_window_terms.append((excess,wrate))
            ep=config.get('early_preference_per_min',{1:.01,2:.005,3:0,4:0,5:0}); erate=frac(ep.get(str(s.get('priority',3)),ep.get(s.get('priority',3),0)))/60
            early_anchor=pref_end_sec if pref_end_sec is not None and wrate>0 else config.get('shift_start_min',360)*60
            excess=model.new_int_var(0,172800,sid+' priority arrival preference');model.add_max_equality(excess,[0,start-early_anchor]);soft_early_terms.append((excess,erate))
            if s.get('previous_truck_id') and s['previous_truck_id']!=tid:soft_continuity+=frac(config.get('change_penalty_per_stop',3))
            if conservative_minutes:
                secs=st['service_start_min']*60
                baseline_soft_window+=wrate*((max(0,pref_start*60-secs) if pref_start is not None else 0)+(max(0,secs-pref_end_sec) if pref_end_sec is not None else 0))
                baseline_soft_early+=erate*max(0,secs-early_anchor)
            rest=None
            if br and br['where']=='ROAD' and br.get('after_sequence')==j:
                con(bs>=prevdep,'road break after previous stop '+sid); con(be<=start,'road break before unloading '+sid)
                if conservative_minutes:
                    # Baseline deliberately waits for the break window and completes
                    # the break before beginning this drive; idle time is costed.
                    con(arrival==be+travel,'conservative break before drive '+sid)
                else:
                    onway=model.new_bool_var(sid+' break before arrival')
                    model.add(bs<prevdep+travel).only_enforce_if(onway); model.add(bs>=prevdep+travel).only_enforce_if(onway.Not())
                    model.add(arrival==prevdep+travel+brlen).only_enforce_if(onway); model.add(arrival==prevdep+travel).only_enforce_if(onway.Not())
                    rest=onway
            else: con(arrival==prevdep+travel,'arrival '+sid)
            con(start>=arrival,'unload after arrival '+sid)
            expected_wait=max(0,st['service_start_min']-st['arrival_min'])
            if rest is None: ck.eq(st['wait_min'],expected_wait,'WAIT_DISPLAY',sid)
            else: ck.check(st['wait_min'] in [expected_wait,max(0,expected_wait-config.get('break_min',0))],'WAIT_BREAK_DISPLAY',sid)
            ck.check(st.get('hard_window_ok') is True,'HARD_WINDOW_FLAG',sid)
            prevdep=start+service; prevnode=node
        back=dm[prevnode][0]; metres+=back
        returntravel=math.ceil(tm[prevnode][0]/60)*60 if conservative_minutes else tm[prevnode][0]
        totalreturn=prevdep+returntravel
        if br and br['where']=='ROAD' and br.get('after_sequence')==len(ld['stops']):
            con(bs>=prevdep,'return break after last unload '+label); con(be<=ret,'return break before arrival '+label); totalreturn+=brlen
        elif br and br['where']=='ROAD': ck.check(br.get('after_sequence') in range(len(ld['stops'])),'BREAK_POSITION',label)
        if br and br['where']=='DEPOT': con(be<=dep,'depot break before departure '+label)
        con(ret==totalreturn,'depot return '+label)
        ck.eq(ld['return_leg_km'],back/1000,'RETURN_DISTANCE',label,tol=.005001); ck.eq(ld['distance_km'],metres/1000,'LOAD_DISTANCE',label,tol=.005001)
        raw_distance+=metres; distance_byload[id(ld)]=metres
        parts=['fixed_cost','trip_cost','distance_cost','fuel_cost','time_cost','overtime_cost']; ck.eq(ld['total_cost'],sum(ld.get(k) or 0 for k in parts),'COST_SUM',label,tol=.000001)
        if ld.get('driver_cost') is not None: ck.eq(ld['time_cost'],ld['driver_cost'],'DRIVER_ALIAS',label)
        cost_sum+=ld['total_cost']
        timing_byload[id(ld)]=dict(dep=dep,ret=ret,break_start=bs,break_end=be,label=label)
    for tid,ls in bytruck.items():
        t=trucks[tid]; ls.sort(key=lambda l:l['load_no']); frozen=t.get('frozen_trips',[])
        if t.get('hire_candidate'):
            ck.check(any(allstops.get(s['stop_id'],{}).get('priority',5)<=3 for l in ls for s in l['stops']),'RENTAL_HIGH_PRIORITY_USE',tid)
        ck.check(len(ls)+len(frozen)<=(t.get('max_trips') or config.get('max_trips_per_truck',3)),'TRIP_LIMIT',tid)
        ck.check([l['load_no'] for l in ls]==list(range(len(frozen)+1,len(frozen)+len(ls)+1)),'LOAD_NUMBERS',tid)
        ck.check(not ({l['load_no'] for l in ls}&{f['load_no'] for f in frozen}),'FROZEN_LOAD_NUMBER_REUSE',tid)
        first=timing_byload[id(ls[0])]['dep']; last=timing_byload[id(ls[-1])]['ret']
        anchor=min(f['depart_min'] for f in frozen)*60 if frozen else first
        prev=max(f['return_min'] for f in frozen)*60 if frozen else None
        con(last-anchor<=config.get('shift_max_min',660)*60,'shift limit '+tid)
        hasfrozenbreak=any(f.get('break_start_min') is not None and f.get('break_min',0)>=config.get('break_min',0) and config.get('break_start_from_min',720)<=f['break_start_min']<=config.get('break_start_to_min',840) for f in frozen)
        breaks=[timing_byload[id(l)] for l in ls if l.get('driver_break')]
        ck.check(len(breaks)<=1,'MULTIPLE_BREAKS',tid)
        if breaks: con(breaks[0]['break_start']>=anchor,'break within shift '+tid); con(breaks[0]['break_end']<=last,'break within shift '+tid)
        bmin=config.get('break_min',0); bf=config.get('break_start_from_min',720); bt=config.get('break_start_to_min',840)
        validbreak=bmin>0 and bf<=bt and bmin<config.get('shift_max_min',660)
        if validbreak and not breaks and not hasfrozenbreak:
            shown_anchor=min(f['depart_min'] for f in frozen) if frozen else ls[0]['depart_min']
            definitely_due=shown_anchor*60+(0 if frozen or conservative_minutes else 29)<bf*60 and ls[-1]['return_min']*60-(0 if conservative_minutes else 30)>bt*60
            ck.check(not definitely_due,'REQUIRED_BREAK_MISSING',dict(truck=tid,first_departure=shown_anchor,last_return=ls[-1]['return_min'],break_start_window=[bf,bt],required_minutes=bmin))
            late=model.new_bool_var(tid+' starts after break window'); early=model.new_bool_var(tid+' ends before break needed')
            model.add(anchor>=bf*60).only_enforce_if(late); model.add(last<=bt*60).only_enforce_if(early); model.add_bool_or([late,early])
        for index,ld in enumerate(ls):
            vals=timing_byload[id(ld)]; dep=vals['dep']; ret=vals['ret']; label=vals['label']
            turn=round(config.get('reload_min',30)*60+config.get('loading_min_per_case',0)*ld['cases']*60)
            if prev is not None:
                con(dep>=prev+turn,'turnaround '+label)
                previous_shown=max(f['return_min'] for f in frozen) if index==0 else ls[index-1]['return_min']
                maximum_gap=(ld['depart_min']-previous_shown)*60+(0 if conservative_minutes else 29)+(0 if conservative_minutes or index==0 and frozen else 30)
                ck.check(maximum_gap>=turn,'TURNAROUND_TOO_SHORT',dict(load=label,reported_departure=ld['depart_min'],reported_previous_return=previous_shown,required_seconds=turn,maximum_possible_seconds_after_rounding=maximum_gap))
            if config.get('loading_from_min') is not None: con(dep>=config['loading_from_min']*60+turn,'same-day loading '+label)
            if ld.get('driver_break') and ld['driver_break']['where']=='DEPOT' and prev is not None: con(vals['break_start']>=prev,'depot break after prior return '+label)
            paidfrom=dep if prev is None else prev; paid=ret-paidfrom
            if ld.get('paid_from_min') is not None: rounded_expr(paidfrom,ld['paid_from_min'],'paid start '+label)
            if ld.get('driver_paid_min') is not None: rounded_expr(paid,ld['driver_paid_min'],'paid minutes '+label)
            fixed=frac(t.get('fixed_cost',0)) if index==0 and not frozen else Fraction(0)
            trip=frac(t.get('trip_cost',0)); distance=Fraction(distance_byload[id(ld)],1000)*frac(t.get('cost_per_km',0))
            litres=Fraction(distance_byload[id(ld)],1000)/frac(t['km_per_litre']) if t.get('km_per_litre') else Fraction(0)
            fuel=litres*frac(config.get('fuel_price_per_litre',0))
            for key,value in [('fixed_cost',fixed),('trip_cost',trip),('distance_cost',distance),('fuel_cost',fuel)]: ck.eq(ld.get(key) or 0,float(value),'COST_COMPONENT',dict(load=label,component=key),tol=.001001)
            if ld.get('fuel_litres') is not None: ck.eq(ld['fuel_litres'],float(litres),'FUEL_LITRES',label,tol=.050001)
            dayrate=t.get('driver_day_cost'); hourly=frac(config.get('driver_cost_per_hour',0))/3600
            otrate=frac(config.get('overtime_cost_per_hour',4))/3600
            ot=model.new_int_var(0,172800,label+' overtime')
            if dayrate is not None or config.get('overtime_after_min',540) is None or otrate==0: con(ot==0,'no overtime '+label)
            else:
                otbegin=model.new_int_var(0,345600,label+' overtime begins'); model.add_max_equality(otbegin,[paidfrom,anchor+config.get('overtime_after_min',540)*60]); model.add_max_equality(ot,[0,ret-otbegin])
            if ld.get('overtime_min') is not None: rounded_expr(ot,ld['overtime_min'],'overtime display '+label)
            terms=[]; constant=fixed+trip+distance+fuel
            if dayrate is not None:
                day=frac(dayrate) if index==0 and not frozen else Fraction(0); ck.eq(ld.get('time_cost',0),float(day),'DAY_DRIVER_COST',label,tol=.001001); constant+=day
            else:
                money([(paid,hourly)],0,ld.get('time_cost'),'hourly driver '+label); terms.append((paid,hourly))
            money([(ot,otrate)],0,ld.get('overtime_cost'),'overtime cost '+label); terms.append((ot,otrate))
            money(terms,constant,ld['total_cost'],'total money '+label)
            prev=ret
    ck.eq(sc.get('total_cases'),sum(allstops[s]['demand_cases'] for s in servedids if s in allstops),'SCENARIO_CASES',sc.get('name'))
    ck.eq(tenths(sc.get('total_kg',0)),allrawkg,'SCENARIO_KG',sc.get('name'))
    ck.eq(sc.get('trips'),len(loads),'SCENARIO_TRIPS',sc.get('name'))
    ck.eq(sc.get('total_distance_km'),raw_distance/1000,'SCENARIO_DISTANCE',sc.get('name'),tol=.005001*max(1,len(loads)))
    ck.eq(sc.get('operating_cost'),cost_sum,'SCENARIO_COST',sc.get('name'),tol=.000501*max(1,len(loads)))
    ck.eq(sc.get('total_duration_min'),sum(l['duration_min'] for l in loads),'SCENARIO_DURATION',sc.get('name'))
    ck.eq(sc.get('trucks_used'),len(set(bytruck)|{t['id'] for t in req['trucks'] if t.get('frozen_trips')}),'SCENARIO_TRUCKS',sc.get('name'))
    if sc.get('total_pallet_units') is not None: ck.eq(sc['total_pallet_units'],allpal,'SCENARIO_PALLETS',sc.get('name'))
    penalties=sc.get('preference_penalties')
    if penalties:
        money(soft_window_terms,0,penalties.get('window'),'scenario window preference')
        money(soft_early_terms,0,penalties.get('early'),'scenario priority arrival preference')
        ck.eq(penalties.get('continuity'),float(soft_continuity),'CONTINUITY_PREFERENCE','scenario',tol=.000501)
    solver=cp_model.CpSolver(); solver.parameters.max_time_in_seconds=10; solver.parameters.num_search_workers=1
    status=solver.solve(model); timing_status=solver.status_name(status)
    ck.check(status in [cp_model.OPTIMAL,cp_model.FEASIBLE],'TIMETABLE_AND_COST_CONSISTENCY',dict(status=timing_status,description='No compatible integer-second timetable under declared wire rounding, physical rules and reported costs' if status==cp_model.INFEASIBLE else 'Timed out or invalid checker model' if status not in [cp_model.OPTIMAL,cp_model.FEASIBLE] else 'Compatible timetable exists',diagnostic_constraints=[assumption_tags.get(i,str(i)) for i in solver.sufficient_assumptions_for_infeasibility()] if status==cp_model.INFEASIBLE and assumption_tags else []))
    served_priority=collections.Counter(allstops[s].get('priority',3) for s in servedids if s in allstops); unserved_priority=collections.Counter(allstops[s].get('priority',3) for s in missingids if s in allstops)
    soft_result=dict(window=float(baseline_soft_window),early=float(baseline_soft_early),continuity=float(soft_continuity)) if conservative_minutes else dict(window=penalties.get('window'),early=penalties.get('early'),continuity=penalties.get('continuity')) if penalties else None
    return dict(name=sc.get('name'),status='PASS' if not ck.violations else 'FAIL',checks=ck.count,violations=ck.violations,timing_constraints=len(timing_assertions),timing_variables=variable_count,timing_status=timing_status,timing_check_wall_s=solver.wall_time,served_stops=len(servedids),unserved_stops=len(missingids),served_by_priority=dict(served_priority),unserved_by_priority=dict(unserved_priority),distance_from_matrix_km=raw_distance/1000,cost_from_load_components=round(cost_sum,3),soft_preference_penalties=soft_result,cost_plus_soft_preferences=round(cost_sum+sum(soft_result.values()),3) if soft_result else None,reported_product_feasibility=(sc.get('feasibility') or {}).get('status'))

def validate(request_path,response_path,matrix_path=None,invoice_path=None):
    req=read(request_path); resp=read(response_path)
    if not matrix_path and req.get('config',{}).get('distance_provider','OSRM')!='HAVERSINE':
        raise ValueError('A captured matrix is required unless request explicitly selects HAVERSINE.')
    matrix=read(matrix_path) if matrix_path else haversine_matrix(req)
    conservative=resp.get('engine')=='independent greedy'
    scenarios=[check_scenario(req,s,matrix,conservative_minutes=conservative) for s in resp['scenarios']]
    raw=check_invoices(req,read(invoice_path) if invoice_path else None)
    return dict(checker_version=1,head=HEAD,mode='conservative baseline (every matrix duration rounded UP to a whole minute, clocks exact minutes)' if conservative else 'RouteIQ rounded wire contract',request=str(request_path),response=str(response_path),request_sha256=digest(request_path),response_sha256=digest(response_path),matrix=str(matrix_path) if matrix_path else 'independently_reconstructed_haversine',invoice_check=raw,scenarios=scenarios,status='PASS' if all(s['status']=='PASS' for s in scenarios) and raw['status'] in ['PASS','NOT_SUPPLIED','UNSUPPORTED_SCHEMA'] else 'FAIL',limitations=LIMITATIONS)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('request'); p.add_argument('response'); p.add_argument('--matrix'); p.add_argument('--raw-invoices'); p.add_argument('--output'); a=p.parse_args()
    out=validate(a.request,a.response,a.matrix,a.raw_invoices); content=json.dumps(out,indent=2)
    if a.output: Path(a.output).write_text(content+'\n')
    else: print(content)
