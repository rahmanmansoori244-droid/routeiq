"""Separate line accounting for pipeline fixtures; no product reconciliation imports."""
from collections import Counter
from pathlib import Path
import json,math
from validate import ROOT,Checks,read,tenths

def check(folder):
    files={k:folder/f'{k}.json' for k in ['raw-invoices','confirmed-orders','built','request','response','persisted']}
    if (folder/'raw-invoices-all.json').exists(): files['raw-invoices']=folder/'raw-invoices-all.json'
    if not all(p.exists() for p in files.values()): return None
    raw,orders,built,req,resp,persisted=(read(files[k]) for k in files)
    ck=Checks(); om={o['id']:o for o in orders}; lines={l['id']:l for o in orders for l in o['lines']}; owner={l['id']:o for o in orders for l in o['lines']}
    source=Counter(); confirmed=Counter()
    for row in raw: source[(row['sales_order_no'],row['customer_code'],row['product_code'])]+=int(row['cases'])
    for o in orders:
        for l in o['lines']: confirmed[(l['salesOrderNo'],o['customer']['code'],l['product']['code'])]+=l['cases']
        ck.eq(o['totalCases'],sum(l['cases'] for l in o['lines']),'CONFIRMED_TOTAL_CASES',o['id'])
    ck.check(source==confirmed,'RAW_TO_CONFIRMED','Invoice/customer/SKU case quantities must be conserved through intake')
    scope=built['scope']; portions=scope.get('portions',{})
    def expand(ref):
        if ref in portions: return Counter({l['lineId']:l['cases'] for l in portions[ref]['lines']})
        if ref in om: return Counter({l['id']:l['cases'] for l in om[ref]['lines']})
        ck.check(False,'UNKNOWN_ORDER_REF',ref); return Counter()
    def measure(q):
        cases=sum(q.values()); kg=sum(qty*(lines[l]['weightKg']/lines[l]['cases']) for l,qty in q.items())
        haspal=all(lines[l]['product'].get('casesPerPallet') for l in q)
        pal=sum(math.ceil(qty*1000/lines[l]['product']['casesPerPallet']) for l,qty in q.items()) if haspal else None
        return cases,kg,pal
    frozen=Counter(); frozen_file=folder/'frozen-baseline.json'
    if scope.get('frozenOrderIds') or scope.get('frozenLoadIds'):
        if not frozen_file.exists(): return dict(case=folder.name,status='PARTIAL',checks=ck.count,violations=ck.violations,note='Raw-to-confirmed checked; frozen line allocations require original frozen assignment evidence and are deferred here.')
        f=read(frozen_file); savedloads={l['id']:l for l in persisted['loads']}; savedass={a['id']:a for a in persisted['assignments']}
        ck.check(savedloads.get(f['load']['id'])==f['load'],'FROZEN_LOAD_UNCHANGED',f['load']['id'])
        for a in f['assignments']:
            ck.check(savedass.get(a['id'])==a,'FROZEN_ASSIGNMENT_UNCHANGED',a['id'])
            frozen+=Counter({p['lineId']:p['cases'] for p in a['portionLinesJson']}) if a.get('portionLinesJson') else expand(a['orderId'])
    expected=Counter({l['id']:l['cases'] for oid in set(scope['orderIds']+scope.get('frozenOrderIds',[])) for l in om[oid]['lines']})
    tosolver=Counter()
    for st in req['stops']:
        q=Counter()
        for ref in st['order_ids']: q+=expand(ref)
        tosolver+=q; cs,kg,pal=measure(q)
        ck.eq(st['demand_cases'],cs,'BUILDER_CASES',st['stop_id']);ck.eq(tenths(st.get('demand_kg',0)),tenths(kg),'BUILDER_KG',st['stop_id'])
        if st.get('demand_pallet_units') is not None: ck.eq(st['demand_pallet_units'],pal,'BUILDER_PALLETS',st['stop_id'])
        ck.check(all(owner[l]['customerId']==st['customer_id'] for l in q),'BUILDER_CUSTOMER',st['stop_id'])
    predropped=Counter()
    for d in built.get('preDrops',[]): predropped+=expand(d['orderId'])
    ck.check(tosolver+predropped+frozen==expected,'BUILDER_LINE_PARTITION','Every scope line is represented in solver, frozen or pre-dropped exactly in full quantity')
    sc=resp['scenarios'][0]; served=frozen.copy(); unserved=predropped.copy()
    for ld in sc['loads']:
        for st in ld['stops']:
            for ref in st['order_ids']: served+=expand(ref)
    for st in sc['unserved']:
        for ref in st['order_ids']: unserved+=expand(ref)
    ck.check(served+unserved==expected,'RESPONSE_LINE_PARTITION','Every scope case served or unserved exactly once, including pre-drops')
    persisted_served=Counter()
    for a in persisted['assignments']:
        if a.get('portionLinesJson'): q=Counter({p['lineId']:p['cases'] for p in a['portionLinesJson']})
        else: q=expand(a['orderId'])
        persisted_served+=q
        ck.eq(a.get('portionCases') if a.get('portionCases') is not None else om[a['orderId']]['totalCases'],sum(q.values()),'PERSISTED_ASSIGNMENT_CASES',a['id'])
    ck.check(persisted_served==served,'PERSISTED_LINE_ALLOCATION','Persisted served quantities by source line match solver serving exactly')
    recon=persisted['run'].get('reconciliationJson') or {}
    ck.eq(recon.get('uploadedCases'),sum(expected.values()),'RECON_UPLOADED','independently recomputed')
    ck.eq(recon.get('plannedCases'),sum(served.values()),'RECON_PLANNED','independently recomputed')
    ck.eq(recon.get('unservedCases'),sum(unserved.values()),'RECON_UNSERVED','independently recomputed')
    for field,keyfn in [('bySku',lambda l:lines[l]['product']['code']),('bySalesOrder',lambda l:lines[l]['salesOrderNo'])]:
        groups={}
        for lid,qty in expected.items():
            key=keyfn(lid); counts=groups.setdefault(key,[0,0,0]); counts[0]+=qty;counts[1]+=served[lid];counts[2]+=unserved[lid]
        shown={x['key']:x for x in recon.get(field,[])}
        ck.check(set(shown)==set(groups),'RECON_GROUP_IDENTITIES',field)
        for key,c in groups.items():
            for pos,measure_name in enumerate(['uploaded','planned','unserved']):ck.eq(shown.get(key,{}).get(measure_name),c[pos],'RECON_GROUP_QUANTITY',dict(group=field,key=key,measure=measure_name))
    return dict(case=folder.name,status='PASS' if not ck.violations else 'FAIL',checks=ck.count,violations=ck.violations,raw_rows=len(raw),invoices=len(set(r['sales_order_no'] for r in raw)),source_lines=len(lines),uploaded_cases=sum(expected.values()),served_cases=sum(served.values()),unserved_cases=sum(unserved.values()),predropped_cases=sum(predropped.values()),frozen_cases=sum(frozen.values()),limitation='Checks supplied test-double snapshots, not real PostgreSQL transaction behavior or generated exports. Source rounding rules are reconstructed independently.')

results=[]
for folder in sorted((ROOT/'pipeline'/'results').iterdir()):
    if not folder.is_dir(): continue
    try:
        result=check(folder)
        if result: results.append(result); print(folder.name,result['status'],result.get('violations'))
    except Exception as e: results.append(dict(case=folder.name,status='ERROR',error=repr(e)));print(folder.name,repr(e))
(ROOT/'validation'/'pipeline-accounting.json').write_text(json.dumps(dict(cases=results),indent=2)+'\n')
